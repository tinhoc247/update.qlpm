"""Màu sắc, font chữ và icon vẽ bằng Pillow (giống nhau trên Windows / Linux, không cần emoji)."""
from PIL import Image, ImageDraw, ImageTk

# ---- bảng màu ----
BG, CARD, BORDER = "#eef1f7", "#ffffff", "#d5dbe7"
TEXT, MUTED = "#1f2937", "#64748b"
PRIMARY, PRIMARY_BG, SEL_BG = "#2563eb", "#dbe7ff", "#eaf1ff"
STATUS = {                       # khóa: (nền, chữ, nội dung)
    "ready": ("#e3f6ea", "#15803d", "●  Sẵn sàng"),
    "locked": ("#fde7e7", "#b91c1c", "●  Đã khóa"),
    "present": ("#dbe7ff", "#1d4ed8", "●  Đang nhận trình chiếu"),
    "share": ("#efe5ff", "#6d28d9", "●  Đang chia sẻ màn hình"),
}


def pick_font(root):
    import tkinter.font as tkfont
    have = set(tkfont.families(root))
    for f in ("Segoe UI", "Noto Sans", "Ubuntu", "Cantarell", "Open Sans", "DejaVu Sans", "Helvetica", "Arial"):
        if f in have:
            return f
    return "TkDefaultFont"


def scale_of(root):
    try:
        return max(1.0, root.winfo_fpixels("1i") / 96.0)
    except Exception:
        return 1.0


# ---- icon ----
_S = 4


def render(name, size=32, color="#1f2937"):
    n = size * _S; k = n / 100.0
    im = Image.new("RGBA", (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    P = lambda *v: [x * k for x in v]
    HOLE = (0, 0, 0, 0)

    def line(pts, w, fill=color):
        d.line(P(*pts), fill=fill, width=int(w * k))
        for x, y in zip(pts[0::2], pts[1::2]):
            d.ellipse(P(x - w / 2, y - w / 2, x + w / 2, y + w / 2), fill=fill)

    def arc(box, a, b, w): d.arc(P(*box), a, b, fill=color, width=int(w * k))
    def rrect(box, r, fill=None, outline=None, w=0):
        d.rounded_rectangle(P(*box), radius=r * k, fill=fill, outline=outline, width=int(w * k))

    if name in ("lock", "unlock"):
        arc((32, 8, 68, 56), 180, 360, 9)
        d.rectangle(P(32, 32, 41, 50), fill=color)
        if name == "lock": d.rectangle(P(59, 32, 68, 50), fill=color)
        rrect((18, 44, 82, 92), 10, fill=color)
        d.ellipse(P(43, 57, 57, 71), fill=HOLE); d.rectangle(P(47, 65, 53, 79), fill=HOLE)
    elif name == "power":
        arc((16, 20, 84, 88), 300, 240, 9); line((50, 10, 50, 50), 9)
    elif name == "restart":
        arc((18, 18, 82, 82), 40, 330, 9)
        d.polygon(P(89.8, 27, 65.6, 41, 87.7, 51.3), fill=color)
    elif name == "refresh":
        arc((18, 18, 82, 82), 200, 340, 9); d.polygon(P(83.5, 48.5, 88.6, 36.0, 71.6, 42.2), fill=color)
        arc((18, 18, 82, 82), 20, 160, 9); d.polygon(P(16.5, 51.5, 11.4, 64.0, 28.4, 57.8), fill=color)
    elif name == "inbox":
        line((50, 8, 50, 48), 9); d.polygon(P(30, 38, 70, 38, 50, 62), fill=color)
        line((12, 58, 12, 88, 88, 88, 88, 58), 9)
    elif name == "present":
        rrect((6, 12, 94, 70), 9, outline=color, w=7)
        d.rectangle(P(44, 70, 56, 82), fill=color); rrect((26, 80, 74, 90), 4, fill=color)
        d.polygon(P(42, 26, 42, 56, 68, 41), fill=color)
    elif name == "eye":
        d.ellipse(P(6, 26, 94, 74), outline=color, width=int(7 * k))
        d.ellipse(P(34, 34, 66, 66), fill=color)
    elif name == "broadcast":
        d.ellipse(P(40, 50, 60, 70), fill=color)
        arc((28, 38, 72, 82), 215, 325, 8); arc((12, 22, 88, 98), 215, 325, 8)
        line((50, 70, 50, 92), 8)
    elif name == "stop":
        rrect((20, 20, 80, 80), 12, fill=color)
    elif name == "file":
        rrect((6, 16, 44, 40), 7, fill=color); rrect((6, 28, 94, 86), 9, fill=color)
        d.rectangle(P(45, 40, 55, 60), fill=HOLE); d.polygon(P(33, 56, 67, 56, 50, 74), fill=HOLE)
    elif name == "link":
        rrect((3, 34, 60, 66), 16, outline=color, w=8); rrect((40, 34, 97, 66), 16, outline=color, w=8)
    elif name == "check":
        rrect((12, 12, 88, 88), 14, outline=color, w=8); line((30, 52, 44, 67, 72, 33), 10)
    elif name == "update":
        line((50, 62, 50, 14), 9); d.polygon(P(28, 34, 72, 34, 50, 10), fill=color)
        line((12, 58, 12, 88, 88, 88, 88, 58), 9)
    elif name == "folderup":
        rrect((6, 16, 44, 40), 7, fill=color); rrect((6, 28, 94, 86), 9, fill=color)
        d.rectangle(P(45, 54, 55, 76), fill=HOLE); d.polygon(P(32, 56, 68, 56, 50, 36), fill=HOLE)
    elif name == "manage":
        rrect((6, 12, 94, 70), 9, outline=color, w=7)
        d.rectangle(P(44, 70, 56, 82), fill=color); rrect((26, 80, 74, 90), 4, fill=color)
        d.polygon(P(34, 24, 34, 58, 44, 49, 52, 65, 60, 61, 52, 46, 66, 45), fill=color)
    elif name == "info":
        d.ellipse(P(8, 8, 92, 92), fill=color); d.ellipse(P(43, 20, 57, 34), fill=HOLE); rrect((43, 40, 57, 76), 5, fill=HOLE)
    elif name == "user":
        d.ellipse(P(32, 10, 68, 46), fill=color); d.pieslice(P(14, 54, 86, 126), 180, 360, fill=color)
    elif name == "pc":
        rrect((8, 12, 92, 66), 9, outline=color, w=8); line((50, 66, 50, 82), 8); line((28, 88, 72, 88), 8)
    elif name == "app":
        rrect((8, 14, 92, 86), 9, outline=color, w=8); line((8, 36, 92, 36), 8); d.ellipse(P(18, 21, 26, 29), fill=color)
    elif name == "block":
        d.ellipse(P(10, 10, 90, 90), outline=color, width=int(9 * k)); line((24, 76, 76, 24), 9)
    elif name == "noinstall":
        line((50, 8, 50, 46), 9); d.polygon(P(30, 36, 70, 36, 50, 60), fill=color)
        line((12, 56, 12, 88, 88, 88, 88, 56), 9); line((14, 86, 86, 12), 8)
    elif name == "globe":
        d.ellipse(P(10, 10, 90, 90), outline=color, width=int(8 * k)); d.ellipse(P(32, 10, 68, 90), outline=color, width=int(7 * k))
        line((12, 50, 88, 50), 7); line((20, 28, 80, 28), 6); line((20, 72, 80, 72), 6)
    elif name in ("sound", "mute"):
        d.rectangle(P(8, 38, 28, 62), fill=color); d.polygon(P(26, 38, 54, 14, 54, 86, 26, 62), fill=color)
        if name == "sound": arc((34, 34, 70, 66), 305, 55, 8); arc((22, 20, 88, 80), 305, 55, 8)
        else: line((66, 38, 92, 62), 9); line((92, 38, 66, 62), 9)
    elif name == "dot":
        d.ellipse(P(22, 22, 78, 78), fill=color)
    return im.resize((size, size), Image.LANCZOS)


_cache = {}
def tkicon(name, size=32, color="#1f2937"):
    key = (name, size, color)
    if key not in _cache:
        _cache[key] = ImageTk.PhotoImage(render(name, size, color))
    return _cache[key]


def badge(name, size, fg="#ffffff", bg="#1d4ed8"):
    """Huy hiệu tròn có icon, dán lên ảnh thu nhỏ."""
    n = size * _S
    im = Image.new("RGBA", (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im); d.ellipse((0, 0, n - 1, n - 1), fill=bg)
    ic = render(name, int(size * 0.6) * 1, fg).resize((int(n * 0.6), int(n * 0.6)), Image.LANCZOS)
    im.alpha_composite(ic, ((n - ic.width) // 2, (n - ic.height) // 2))
    return im.resize((size, size), Image.LANCZOS)
