"""Phần dùng chung: cấu hình, giao thức, xác thực, chụp màn hình."""
import hashlib, hmac, io, json, os, queue, socket, struct, sys, threading, time

for _st in (sys.stdout, sys.stderr):      # pythonw / chạy nền trên Windows: stdout mặc định cp1252 -> print tiếng Việt báo lỗi "charmap"
    try: _st.reconfigure(encoding="utf-8", errors="replace")
    except Exception: pass

T_JSON, T_FRAME, T_UP, T_CHUNK, T_THUMB = 1, 2, 3, 4, 5   # JSON | ảnh admin->user | ảnh user->admin | mảnh file | ảnh thu nhỏ
EMOJI = os.name == 'nt'   # Tk trên Linux có thể lỗi với emoji màu -> chỉ dùng emoji trên Windows


def emo(s):
    return s if EMOJI else ''
MAX_PAYLOAD = 16 * 1024 * 1024
CHUNK = 256 * 1024

DEFAULTS = {"present_width": 1280, "present_fit": False, "watch_words": ["youtube", "facebook", "tiktok", "game", "steam", "roblox", "minecraft", "league of legends", "valorant", "genshin", "garena", "netflix", "zalo"], "secret": "changeme", "port": 5000, "discovery_port": 5001, "agent_port": 5003, "scan": [], "scan_interval": 5, "server": "auto",
            "save_dir": "~/Desktop", "fps": 3, "width": 1024, "quality": 50, "max_clients": 50,
            "submit_dirs": [], "submit_max_mb": 300, "submit_file_max_mb": 100, "collect_dir": "~/ThuBai",
            "thumb_fps": 0.5, "thumb_width": 320, "thumb_quality": 40}


def load_config():
    cfg = dict(DEFAULTS)
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    try:
        with open(p, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except FileNotFoundError:
        pass
    if cfg["secret"] == "changeme":
        print("[!] Chưa đổi 'secret' trong config.json – hãy đặt cùng một mật khẩu cho admin và mọi máy user.")
    return cfg


def dpi_aware():
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def local_ips():
    """Các IPv4 LAN của máy này. Không phụ thuộc có Internet hay không (local_ip() cần đường ra 8.8.8.8)."""
    found = []
    for tgt in ("8.8.8.8", "192.168.1.1", "10.0.0.1", "172.16.0.1"):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect((tgt, 80)); found.append(s.getsockname()[0]); s.close()
        except Exception:
            pass
    try: found += socket.gethostbyname_ex(socket.gethostname())[2]
    except Exception: pass
    return [i for i in dict.fromkeys(found) if not i.startswith(("127.", "169.254.", "0."))]


# ---------------- khung dữ liệu: [1 byte loại][4 byte độ dài][payload] ----------------
def recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        d = sock.recv(min(1 << 20, n - len(buf)))
        if not d:
            raise ConnectionError("closed")
        buf += d
    return bytes(buf)


def read_msg(sock):
    t, n = struct.unpack("!BI", recv_exact(sock, 5))
    if n > MAX_PAYLOAD:
        raise ConnectionError("payload too big")
    p = recv_exact(sock, n)
    return t, (json.loads(p.decode("utf-8")) if t == T_JSON else p)


def write_msg(sock, t, obj):
    p = json.dumps(obj).encode("utf-8") if t == T_JSON else obj
    sock.sendall(struct.pack("!BI", t, len(p)) + p)


# ---------------- xác thực 2 chiều bằng mật khẩu chung (HMAC) ----------------
def room_secrets(cfg):
    """Danh sách (tên phòng, mã lớp) mà admin chấp nhận. Mã chính + các phòng thêm trong cfg["rooms"] = [{"name":..,"secret":..}]."""
    extra = [(str(r.get("name", "")).strip(), str(r.get("secret", "")).strip()) for r in (cfg.get("rooms") or []) if isinstance(r, dict) and len(str(r.get("secret", "")).strip()) >= 3]
    main = str(cfg["secret"])
    out = [(str(cfg.get("room_name", "") or ("Phòng 1" if extra else "")), main)] + [(n or f"Phòng {i + 2}", s) for i, (n, s) in enumerate(extra) if s != main]
    seen, res = {}, []
    for n, s in out:                                         # tên phòng không được trùng (bộ lọc theo tên)
        k = seen[n] = seen.get(n, 0) + 1
        res.append((n if k == 1 or not n else f"{n} ({k})", s))
    return res


def sign(secret, *parts):
    b = b"|".join(p.encode() if isinstance(p, str) else p for p in parts)
    return hmac.new(secret.encode(), b, hashlib.sha256).hexdigest()


def client_handshake(sock, secret, name, osn, user="", extra=None):
    t, m = read_msg(sock)
    if t != T_JSON or m.get("cmd") != "challenge":
        raise ConnectionError("bad server")
    nonce, cn = str(m["nonce"]), os.urandom(16).hex()
    write_msg(sock, T_JSON, {"cmd": "hello", "name": name, "os": osn, "user": user, "cn": cn,
                             "resp": sign(secret, b"c", nonce, cn), **(extra or {})})
    t, m = read_msg(sock)
    if m.get("cmd") == "reject":
        raise ConnectionError("rejected: " + str(m.get("reason")))
    if m.get("cmd") != "welcome" or not hmac.compare_digest(sign(secret, b"s", nonce, cn), str(m.get("resp"))):
        raise ConnectionError("server auth failed")


class Conn:
    """Kết nối có luồng ghi riêng. Lệnh/file đi theo hàng đợi; ảnh chỉ giữ khung MỚI NHẤT
    (máy chậm không làm nghẽn, ảnh cũ bị bỏ)."""

    def __init__(self, sock):
        self.sock, self.alive = sock, True
        self.q = queue.Queue(maxsize=32)
        self.frames, self.lock, self.ev = {}, threading.Lock(), threading.Event()
        for lvl, opt in ((socket.IPPROTO_TCP, socket.TCP_NODELAY), (socket.SOL_SOCKET, socket.SO_KEEPALIVE)):
            try: sock.setsockopt(lvl, opt, 1)
            except OSError: pass
        threading.Thread(target=self._writer, daemon=True).start()

    def _put(self, t, p):
        while self.alive:
            try:
                self.q.put((t, p), timeout=0.5); self.ev.set(); return True
            except queue.Full:
                pass
        return False

    def send_json(self, obj): return self._put(T_JSON, json.dumps(obj).encode("utf-8"))
    def send_chunk(self, b): return self._put(T_CHUNK, b)

    def try_json(self, obj):
        """Gửi không chờ (bỏ nếu hàng đợi đầy) – dùng cho sự kiện chuột liên tục để giao diện không bị đứng."""
        try:
            self.q.put_nowait((T_JSON, json.dumps(obj).encode("utf-8"))); self.ev.set(); return True
        except queue.Full:
            return False

    def send_frame(self, t, data):
        with self.lock:
            self.frames[t] = data          # mỗi loại ảnh chỉ giữ khung mới nhất
        self.ev.set()

    def _writer(self):
        try:
            while self.alive:
                self.ev.wait(1.0); self.ev.clear()
                while self.alive:
                    with self.lock:
                        item = None
                        if self.frames:
                            k = next(iter(self.frames)); item = (k, self.frames.pop(k))
                    if item is None:
                        try: item = self.q.get_nowait()
                        except queue.Empty: break
                    t, p = item
                    self.sock.sendall(struct.pack("!BI", t, len(p)) + p)
        except OSError:
            pass
        finally:
            self.close()

    def close(self):
        self.alive = False; self.ev.set()
        try: self.sock.shutdown(socket.SHUT_RDWR)
        except OSError: pass
        try: self.sock.close()
        except OSError: pass


# ---------------- chụp màn hình -> JPEG ----------------
def grab_jpeg(sct, width, quality):
    from PIL import Image
    shot = sct.grab(sct.monitors[1])
    img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
    if img.width > width:
        img = img.resize((width, int(img.height * width / img.width)), Image.BILINEAR)
    buf = io.BytesIO(); img.save(buf, "JPEG", quality=quality)
    return buf.getvalue()


def stream_loop(send, stop, fps, width, quality):
    """Chụp liên tục, bỏ qua ảnh không đổi (màn hình tĩnh gần như không tốn mạng)."""
    import mss
    last, lastt = None, 0
    with mss.mss() as sct:           # phải tạo trong chính luồng này
        while not stop.is_set():
            t0 = time.time()
            try:
                data = grab_jpeg(sct, width, quality)
            except Exception as e:
                print("capture error:", e); stop.wait(1); continue
            h = hashlib.md5(data).digest()
            if h != last or t0 - lastt > 1:
                last, lastt = h, t0
                send(data)
            stop.wait(max(0, 1.0 / fps - (time.time() - t0)))


# loại file bài làm được thu (admin chọn loại nào khi bấm Thu bài)
KINDS = {"anh": ("Ảnh", (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tif", ".tiff", ".svg", ".heic")),
         "tailieu": ("Tài liệu", (".doc", ".docx", ".odt", ".rtf", ".txt", ".pdf")),
         "bangtinh": ("Bảng tính", (".xls", ".xlsx", ".xlsm", ".ods", ".csv")),
         "trinhchieu": ("Trình chiếu", (".ppt", ".pptx", ".pps", ".ppsx", ".odp"))}


# thư mục trên máy học sinh mà admin có thể chọn để gửi file / thu bài (mặc định: Desktop)
FOLDERS = {"Desktop": "Desktop (màn hình chính)", "BaiLam": "BaiLam", "Documents": "Documents (Tài liệu)",
           "Pictures": "Pictures (Ảnh)", "Downloads": "Downloads (Tải xuống)"}
DEFAULT_FOLDER = "Desktop"


COPYRIGHT = "© 2026 @teamgv"


def set_window_icon(win, role):
    """Đặt biểu tượng cho cửa sổ Tk (role = 'admin' | 'user')."""
    d = os.path.dirname(os.path.abspath(__file__))
    try:
        if os.name == "nt":
            try:    # nhóm riêng trên thanh tác vụ -> hiện biểu tượng của app thay vì biểu tượng Python
                import ctypes; ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("teamgv.LabManager." + role)
            except Exception: pass
            win.iconbitmap(default=os.path.join(d, f"icon-{role}.ico"))       # default: mọi cửa sổ con (hộp thoại, Nộp bài…) dùng chung
        else:
            import tkinter as tk
            win._icon_img = tk.PhotoImage(file=os.path.join(d, f"icon-{role}.png")); win.iconphoto(True, win._icon_img)
    except Exception:
        pass
