"""Lõi mạng của máy admin (không phụ thuộc giao diện)."""
import collections, hashlib, hmac, ipaddress, itertools, json, os, queue, re, socket, threading, time
from concurrent.futures import ThreadPoolExecutor
from common import *
import updater, webblock


class Client:
    def __init__(self, cid, name, osn, ip, conn, user=""):
        self.id, self.name, self.os, self.ip, self.conn, self.user = cid, name, osn, ip, conn, user
        self.room = ""                          # tên phòng (theo mã lớp máy này dùng)
        self.ver = self.build = ""              # phiên bản / mã bản dựng máy user đang chạy ("" = bản cũ chưa hỗ trợ cập nhật)
        self.upd_note, self.upd_busy = "", False
        self.locked = self.presenting = self.sharing = False
        self.thumb, self.thumb_ts = None, 0
        self.app = self.title = self.url = ""   # chương trình / tiêu đề cửa sổ / link trang học sinh đang mở
        self.pages = collections.deque(maxlen=30)   # các trang web gần đây: (giờ, tiêu đề, link) – để admin sao chép đưa vào danh sách chặn
        self.file_lock = threading.Lock()
        self.sub = None                         # trạng thái đang thu bài: {"dir","cb","fh","got"}
        self.up = None                          # file học sinh đang nộp: {"fh","path","got","size","name"}
        self.web = None                         # (đang chặn web?, chính sách trình duyệt?, hosts?) do máy user báo về
        self.inst = None                        # (đang chặn cài đặt?, số file được phép, máy tắt hẳn?) do máy user báo về
        self.muted = None                       # loa máy user đang tắt tiếng? (True/False; None = chưa biết / máy không điều khiển được)
        self.proc_cb = None                     # nhận danh sách ứng dụng đang chạy (hộp thoại Quản lý máy)
        self.list_cb = None                     # nhận danh sách file của máy này khi admin chọn file để thu
        self.browse_cb = None                   # nhận nội dung 1 thư mục của máy này khi admin duyệt chọn file / thư mục để thu

    def send(self, **kw): return self.conn.send_json(kw)


class Server:
    def __init__(self, cfg):
        self.cfg, self.clients = cfg, {}
        self.lock, self.events, self.ids = threading.Lock(), queue.Queue(), itertools.count(1)
        self.latest = None                      # (id, jpeg) màn hình mới nhất do user gửi lên
        self.relay_src, self.relay_dst = None, []
        self.inbox = None                       # đang nhận bài: {"dir","title","count","machines","owners"}
        self.thumbs_on = True
        self.thumb_w = None                     # độ rộng ảnh thu nhỏ admin yêu cầu (khi phóng to ô máy)
        self.pending = set()                    # IP đang được admin kết nối ra (tránh nối trùng)
        self.open_ports = set()                 # IP mở cổng user trong lần quét gần nhất
        self.bad = {}                           # IP -> (lý do, thời điểm): máy bắt tay thất bại (vd. sai mã lớp)
        self.web = webblock.load(); self.web["on"] = False   # chính sách chặn web (webblock.json: nhóm / trang chặn). Luôn TỰ BẬT khi admin chạy và đã mở khóa (Admin.auto_web); chưa mở khóa thì không bật
        self.inst = webblock.inst_load(); self.inst["on"] = True; webblock.inst_save(self.inst)   # chính sách chặn cài đặt (installblock.json); LUÔN TỰ BẬT mỗi lần admin chạy (giáo viên vẫn tắt được trong "Chặn cài đặt phần mềm…"); mọi máy nối vào đều nhận
        self.inst_log = collections.deque(maxlen=200)    # nhật ký: (giờ, tên máy, tài khoản, file bị chặn, đã đóng?)
        self.upd = None                         # gói cập nhật = ảnh chụp chương trình đang cài trên admin
        self.refresh_update()

    # ---------- cập nhật phần mềm cho máy user ----------
    def refresh_update(self):
        """Chụp lại chương trình đang cài trên admin làm gói cập nhật (gọi lúc khởi động và sau mỗi lần vá / khôi phục)."""
        try:
            z, build, ver = updater.snapshot()
            self.upd = {"zip": z, "build": build, "ver": ver, "sha": hashlib.sha256(z).hexdigest(), "notes": updater.notes()}
        except Exception as e:
            print("snapshot cập nhật:", e); self.upd = None

    def offer_update(self, c):
        """Báo máy user có bản khác bản của admin. Máy bản cũ (không gửi mã bản dựng) không hiểu lệnh này nên bỏ qua."""
        u = self.upd
        if u and c.build and c.build != u["build"]:
            c.send(cmd="update_offer", ver=u["ver"], build=u["build"], size=len(u["zip"]), notes=u.get("notes", "")); return True
        return False

    def offer_all(self, targets=None):
        return sum(1 for c in (targets if targets is not None else self.snapshot()) if self.offer_update(c))

    def update_stats(self):
        """(đã mới nhất, chờ cập nhật, bản cũ chưa hỗ trợ)"""
        u, cl = self.upd, self.snapshot()
        old = sum(1 for c in cl if not c.build)
        cur = sum(1 for c in cl if c.build and u and c.build == u["build"])
        return cur, len(cl) - cur - old, old

    def _upd(self, c, p):
        cmd = p.get("cmd")
        if cmd == "upd_state": c.upd_note = str(p.get("note", ""))[:100]; self.events.put("list")
        elif cmd == "upd_get":
            u = self.upd
            if not u: return c.send(cmd="upd_no", reason="Admin chưa có gói cập nhật")
            if c.upd_busy: return
            c.upd_busy = True
            threading.Thread(target=self._send_update, args=(c, u), daemon=True).start()

    def _send_update(self, c, u):
        try:
            with c.file_lock:
                z = u["zip"]; c.upd_note = "đang gửi gói cập nhật…"
                c.send(cmd="upd_start", size=len(z), sha=u["sha"], build=u["build"], ver=u["ver"])
                for i in range(0, len(z), CHUNK):
                    if not c.conn.send_chunk(z[i:i + CHUNK]): raise ConnectionError
                c.send(cmd="upd_end"); c.upd_note = "đã gửi, máy đang cài…"
        except Exception:
            c.upd_note = "gửi gói bị gián đoạn"
        finally:
            c.upd_busy = False; self.events.put("list")

    def thumb_cmd(self, c):
        if self.thumbs_on:
            c.send(cmd="thumb_start", fps=self.cfg["thumb_fps"], width=max(self.cfg["thumb_width"], self.thumb_w or 0), quality=self.cfg["thumb_quality"])
        else:
            c.send(cmd="thumb_stop")

    def start(self):
        s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("", self.cfg["port"])); s.listen(100)
        for fn, a in ((self._accept, (s,)), (self._beacon, ()), (self._pinger, ()), (self._dialer, ())):
            threading.Thread(target=fn, args=a, daemon=True).start()

    def bad_list(self):
        """IP bị từ chối gần đây (sai mã lớp) và chưa kết nối được."""
        now = time.time(); live = {c.ip for c in self.snapshot()}
        return sorted(ip for ip, (_, t) in list(self.bad.items()) if now - t < 60 and ip not in live)

    def snapshot(self):
        with self.lock: return list(self.clients.values())

    def _accept(self, srv):
        while True:
            try: sock, addr = srv.accept()
            except OSError: return
            threading.Thread(target=self._serve, args=(sock, addr), daemon=True).start()

    def _beacon(self):          # phát tín hiệu để máy user tự tìm thấy admin
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        msg = json.dumps({"magic": "LABMGR", "port": self.cfg["port"]}).encode()
        while True:
            try: s.sendto(msg, ("255.255.255.255", self.cfg["discovery_port"]))
            except OSError: pass
            time.sleep(2)

    # ---------- admin chủ động kết nối ra các máy user (giống NetSupport) ----------
    def _targets(self):
        nets, ips = self.cfg.get("scan") or [], []
        mine = local_ips()
        if not nets:
            nets = [i + "/24" for i in mine]    # mặc định quét dải /24 của MỌI card mạng của máy admin
        for n in nets:
            try:
                net = ipaddress.ip_network(str(n), strict=False)
                ips += [str(h) for h in net.hosts()] if net.num_addresses > 1 else [str(net.network_address)]
            except ValueError:
                pass
        return [i for i in dict.fromkeys(ips) if i not in mine]

    def _dial(self, ip):
        with self.lock:
            if ip in self.pending or any(c.ip == ip for c in self.clients.values()): return
            self.pending.add(ip)
        port = int(self.cfg.get("agent_port", 5003))
        try:
            sock = socket.create_connection((ip, port), timeout=0.5)
            self.open_ports.add(ip)                       # máy này có mở cổng user (dù sau đó có thể sai mã lớp)
        except OSError:
            with self.lock: self.pending.discard(ip)
            return
        # Phiên làm việc kéo dài suốt buổi học: chạy trong luồng daemon riêng, KHÔNG chiếm luồng của pool.
        # (Luồng pool không-daemon mà chưa kết thúc sẽ làm admin không thoát được khi đóng cửa sổ.)
        def serve():
            try: self._serve(sock, (ip, port))
            finally:
                with self.lock: self.pending.discard(ip)
        threading.Thread(target=serve, daemon=True).start()

    def _dialer(self):
        pool = ThreadPoolExecutor(max_workers=64)
        while True:
            try:
                for ip in self._targets(): pool.submit(self._dial, ip)
            except Exception:
                pass
            time.sleep(max(2, float(self.cfg.get("scan_interval", 5))))

    def rescan(self):
        """Nút 'Làm tươi': bỏ kết nối chết, quét lại mạng NGAY (không chờ vòng 5 giây). Trả về số máy mới tìm thấy."""
        for c in self.snapshot():
            if not c.conn.alive: c.conn.close()
        with self.lock:
            live = {c.ip for c in self.clients.values()}
            self.pending &= live                             # IP đang chờ mà chưa có máy = kẹt, cho thử lại
            before = len(self.clients)
        targets = self._targets(); self.open_ports = set()
        pool = ThreadPoolExecutor(max_workers=128)
        for ip in targets: pool.submit(self._dial, ip)
        pool.shutdown(wait=True)                             # quét /24 mất ~1-3 giây
        time.sleep(1.0)                                      # chờ bắt tay xong
        for c in self.snapshot(): c.send(cmd="ping")
        with self.lock: now = len(self.clients)
        self.events.put("list")
        self.last_scan = (len(targets), len(self.open_ports))
        return max(0, now - before), now

    def _pinger(self):
        while True:
            time.sleep(5)
            for c in self.snapshot(): c.send(cmd="ping")

    def _serve(self, sock, addr):
        c, room = None, ""
        try:
            sock.settimeout(10)
            nonce = os.urandom(16).hex()
            write_msg(sock, T_JSON, {"cmd": "challenge", "nonce": nonce})
            t, m = read_msg(sock)
            if t != T_JSON or m.get("cmd") != "hello":
                raise ConnectionError
            cn = str(m.get("cn", ""))
            secret = None
            for rn, sc in room_secrets(self.cfg):          # thử lần lượt mã lớp của từng phòng
                if hmac.compare_digest(sign(sc, b"c", nonce, cn), str(m.get("resp"))): secret, room = sc, rn; break
            if secret is None:
                raise ConnectionError("auth")
            if len(self.snapshot()) >= self.cfg["max_clients"]:
                write_msg(sock, T_JSON, {"cmd": "reject", "reason": "full"}); raise ConnectionError("full")
            write_msg(sock, T_JSON, {"cmd": "welcome", "resp": sign(secret, b"s", nonce, cn)})
            sock.settimeout(30)
            conn = Conn(sock)
            for o in self.snapshot():                       # máy này cài lại / nối lại: bỏ kết nối cũ (đã chết) cùng IP
                if o.ip == addr[0]: o.conn.close()
            c = Client(next(self.ids), str(m.get("name", ""))[:40] or addr[0], str(m.get("os", ""))[:20], addr[0], conn, str(m.get("user", ""))[:40])
            c.room = room
            c.ver, c.build = str(m.get("ver", ""))[:20], str(m.get("build", ""))[:16]
            with self.lock:
                if len(self.clients) >= self.cfg["max_clients"]:
                    conn.close(); return
                self.clients[c.id] = c
            self.bad.pop(addr[0], None); self.events.put("list")
            self.thumb_cmd(c)
            if self.inbox: c.send(cmd="submit_open", title=self.inbox["title"])
            self.offer_update(c)
            if self.web.get("on"): c.send(cmd="webblock", policy=self.web)
            c.send(cmd="installblock", policy=self.inst)
            while True:
                t, p = read_msg(sock)
                if t == T_THUMB:
                    c.thumb, c.thumb_ts = p, time.time()
                elif t == T_JSON and isinstance(p, dict) and p.get("cmd") == "win":
                    c.app, c.title = str(p.get("app", ""))[:40], str(p.get("title", ""))[:200]
                    u = str(p.get("url", ""))[:400]
                    c.url = u if u.lower().startswith(("http://", "https://")) else ""
                    if c.url and (not c.pages or c.pages[-1][2] != c.url): c.pages.append((time.time(), c.title, c.url))
                elif t == T_JSON and isinstance(p, dict) and p.get("cmd") == "web_state":
                    c.web = (bool(p.get("on")), bool(p.get("browser")), bool(p.get("hosts")))
                elif t == T_JSON and isinstance(p, dict) and p.get("cmd") == "inst_state":
                    c.inst = (bool(p.get("on")), int(p.get("allowed") or 0), bool(p.get("disabled")))
                elif t == T_JSON and isinstance(p, dict) and p.get("cmd") == "audio_state":
                    mv = p.get("muted"); c.muted = bool(mv) if mv is not None else None; self.events.put("list")
                elif t == T_JSON and isinstance(p, dict) and p.get("cmd") == "inst_hit":
                    self.inst_log.append((time.time(), c.name, c.user, str(p.get("name", ""))[:80], bool(p.get("closed")))); self.events.put("list")
                elif t == T_JSON and isinstance(p, dict) and p.get("cmd") == "proc_list":
                    cb = c.proc_cb
                    if cb: cb(c, [x for x in (p.get("items") or []) if isinstance(x, dict)][:200])
                elif t == T_JSON and isinstance(p, dict) and p.get("cmd") == "browse_res":
                    cb = c.browse_cb
                    if cb:
                        its = []
                        for f in (p.get("items") or [])[:2000]:
                            if isinstance(f, list) and len(f) == 5 and isinstance(f[0], str) and isinstance(f[4], str):
                                try: its.append((f[0][:260], bool(f[1]), int(f[2]), int(f[3]), f[4][:1000]))
                                except (TypeError, ValueError): pass
                        cb(c, {"rid": p.get("rid"), "path": str(p.get("path", ""))[:1000], "parent": str(p.get("parent", ""))[:1000], "home": str(p.get("home", ""))[:1000],
                               "sep": "/" if p.get("sep") == "/" else "\\", "err": str(p.get("err", ""))[:120], "items": its})
                elif t == T_JSON and isinstance(p, dict) and p.get("cmd") == "sub_list":
                    cb, c.list_cb = c.list_cb, None
                    if cb: cb(c, [f for f in (p.get("files") or []) if isinstance(f, list) and len(f) in (3, 4)][:500])
                elif t == T_JSON and isinstance(p, dict) and str(p.get("cmd", "")).startswith("upd_"):
                    self._upd(c, p)
                elif t == T_JSON and isinstance(p, dict) and str(p.get("cmd", "")).startswith("up_"):
                    self._up(c, p)
                elif t == T_JSON and isinstance(p, dict) and str(p.get("cmd", "")).startswith("sub_"):
                    self._sub(c, p)
                elif t == T_CHUNK:
                    self._up_chunk(c, p) if c.up else self._sub_chunk(c, p)
                elif t == T_UP:
                    self.latest = (c.id, p)
                    if self.relay_src == c.id:
                        for d in list(self.relay_dst):
                            o = self.clients.get(d)
                            if o: o.conn.send_frame(T_FRAME, p)
        except Exception as e:
            if not c and str(e) == "auth": self.bad[addr[0]] = ("sai mã lớp", time.time()); self.events.put("list")
        finally:
            try: sock.close()
            except OSError: pass
            if c and c.sub: self._sub_finish(c, "bad", "mất kết nối")
            if c and c.up: self._up_abort(c)
            if c:
                with self.lock: self.clients.pop(c.id, None)
                if self.relay_src == c.id: self.relay_src, self.relay_dst = None, []
                self.events.put("list")

    # ---------- nhận bài: học sinh tự nộp file vào thư mục admin chọn ----------
    def open_inbox(self, folder, title):
        os.makedirs(folder, exist_ok=True)
        self.inbox = {"dir": folder, "title": title, "count": 0, "machines": set(), "owners": {}}
        for c in self.snapshot(): c.send(cmd="submit_open", title=title)
        self.events.put("list")

    def close_inbox(self):
        info, self.inbox = self.inbox, None
        for c in self.snapshot(): c.send(cmd="submit_close")
        self.events.put("list")
        return info

    @staticmethod
    def _safe(name, limit=100):
        name = os.path.basename(str(name).replace(chr(92), "/"))
        return re.sub(r'[<>:"/|?*\x00-\x1f\\]', "_", name).strip(" .")[:limit]

    def _up(self, c, p):
        cmd, box = p.get("cmd"), self.inbox
        if cmd == "up_start":
            if c.up: self._up_abort(c)
            try: size = int(p.get("size", 0))
            except (TypeError, ValueError): size = -1
            limit = int(self.cfg.get("submit_file_max_mb", 100)) * 1024 * 1024
            name = self._safe(p.get("name", "")) or "bai_nop"
            if not box: return c.send(cmd="up_no", reason="Giáo viên chưa mở / đã đóng nhận bài")
            if size < 0 or size > limit: return c.send(cmd="up_no", reason=f"File quá lớn (tối đa {limit // 1048576} MB)")
            folder = self._safe(c.name, 40) or "may"
            if box["owners"].setdefault(folder, c.ip) != c.ip: folder = f"{folder}_{c.ip}"      # trùng tên máy khác IP
            d = os.path.join(box["dir"], folder); os.makedirs(d, exist_ok=True)
            base, ext = os.path.splitext(name); path, i = os.path.join(d, name), 1
            while os.path.exists(path): path = os.path.join(d, f"{base}({i}){ext}"); i += 1      # không ghi đè bài đã nộp
            try: c.up = {"fh": open(path, "wb"), "path": path, "got": 0, "size": size, "name": os.path.basename(path), "box": box}
            except OSError as e: return c.send(cmd="up_no", reason="Admin không ghi được file: %s" % e)
            c.send(cmd="up_go")
        elif cmd == "up_end" and c.up:
            up, c.up = c.up, None
            try: up["fh"].close()
            except OSError: pass
            if up["got"] != up["size"]:
                try: os.remove(up["path"])
                except OSError: pass
                return c.send(cmd="up_no", reason="File bị thiếu dữ liệu, hãy nộp lại")
            up["box"]["count"] += 1; up["box"]["machines"].add(c.id)
            c.send(cmd="up_ok", name=up["name"]); self.events.put("list")

    def _up_chunk(self, c, b):
        up = c.up
        up["got"] += len(b)
        if up["got"] > up["size"]: return self._up_abort(c, "File lớn hơn khai báo")
        up["fh"].write(b)

    def _up_abort(self, c, reason=None):
        up, c.up = c.up, None
        if not up: return
        try: up["fh"].close(); os.remove(up["path"])
        except OSError: pass
        if reason: c.send(cmd="up_no", reason=reason)

    # ---------- thu bài ----------
    def _sub_finish(self, c, status, info=""):
        sub, c.sub = c.sub, None
        if not sub: return
        fh = sub.get("fh")
        if fh:                                                  # đang nhận dở 1 file: đóng lại; lỗi thì bỏ file dở (các file đã nhận đủ vẫn giữ)
            try: fh.close()
            except OSError: pass
            if status != "ok" or sub.get("zip"):
                try: os.remove(sub["path"])
                except OSError: pass
        sub["cb"](status, c, info)

    @staticmethod
    def _sub_name(s):
        """Làm sạch 1 thành phần đường dẫn: bỏ ký tự cấm của Windows, dấu chấm / khoảng trắng ở hai đầu."""
        return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(s)).strip(" .")[:100]

    def _sub_root(self, c, sub):
        """Thư mục riêng của máy này trong lần thu: <thư mục thu>/<tên máy>. Trùng tên máy khác thì thêm IP."""
        if sub.get("root"): return sub["root"]
        if sub.get("tag"): sub["root"] = sub["dir"]; return sub["root"]          # thu lại bài đã gửi: không tạo thư mục riêng cho máy, tên máy nằm trong tên file / thư mục
        base = self._sub_name(c.name)[:60] or "may"
        for cand in (base, f"{base}_{c.ip}", *(f"{base}_{c.ip}_{k}" for k in range(2, 50))):
            p = os.path.join(sub["dir"], cand)
            try: os.makedirs(p); sub["root"] = p; return p
            except FileExistsError: continue
        raise OSError("không tạo được thư mục máy")

    @staticmethod
    def tag_name(rel, tag):
        """Thêm tên máy vào phần tên gốc: 'Demo' -> 'Demo_PC01' (thư mục), 'bai.docx' -> 'bai_PC01.docx' (file lẻ). Phần bên trong thư mục giữ nguyên."""
        parts = [x for x in str(rel).replace("\\", "/").split("/") if x]
        if not parts: return rel
        if len(parts) > 1: parts[0] = f"{parts[0]}_{tag}"
        else:
            base, ext = os.path.splitext(parts[0]); parts[0] = f"{base}_{tag}{ext}"
        return "/".join(parts)

    def _sub_dest(self, root, rel):
        """Đường dẫn đích an toàn (không thoát khỏi root, không ghi đè: trùng tên thì thêm (1), (2)…)."""
        parts = [x for x in (self._sub_name(q) for q in str(rel).replace("\\", "/").split("/")) if x]
        if not parts: parts = ["file"]
        d = os.path.join(root, *parts)
        if os.path.commonpath([os.path.abspath(d), os.path.abspath(root)]) != os.path.abspath(root): d = os.path.join(root, parts[-1])
        os.makedirs(os.path.dirname(d), exist_ok=True)
        base, ext = os.path.splitext(d); k = 0
        while os.path.exists(d): k += 1; d = f"{base}({k}){ext}"
        return d

    def _sub_unzip(self, c, sub, info):
        """Máy học sinh bản cũ (< 2.6.1) vẫn gửi gói zip: giải nén ngay vào thư mục máy, rồi xóa zip."""
        import zipfile
        try:
            root, n = self._sub_root(c, sub), 0
            with zipfile.ZipFile(sub["path"]) as z:
                for zi in z.infolist():
                    if zi.is_dir(): continue
                    with z.open(zi) as src, open(self._sub_dest(root, zi.filename), "wb") as dst:
                        while True:
                            b = src.read(1 << 20)
                            if not b: break
                            dst.write(b)
                    n += 1
            try: os.remove(sub["path"])
            except OSError: pass
            self._sub_finish(c, "ok", info)
        except Exception as e:
            self._sub_finish(c, "bad", "giải nén: " + str(e)[:80])

    def _sub(self, c, p):
        sub, cmd = c.sub, p.get("cmd")
        if not sub: return
        try:
            if cmd == "sub_file":                               # bản 2.6.1+: từng file gửi riêng, không nén
                root = self._sub_root(c, sub)
                try: size = max(0, int(p.get("size", 0)))
                except (TypeError, ValueError): size = 0
                sub["path"] = self._sub_dest(root, self.tag_name(p.get("name", ""), sub["tag"]) if sub.get("tag") else p.get("name", "")); sub["size"], sub["got"] = size, 0
                sub["fh"] = open(sub["path"], "wb")
            elif cmd == "sub_fend":
                fh, sub["fh"] = sub.get("fh"), None
                if fh: fh.close()
            elif cmd == "sub_start":                            # bản cũ: 1 gói zip
                root = self._sub_root(c, sub)
                sub["zip"] = True; sub["path"] = os.path.join(root, "_goi_thu_bai.zip"); sub["got"] = 0; sub["size"] = None
                sub["fh"] = open(sub["path"], "wb")
            elif cmd == "sub_end":
                info = f"{int(p.get('skipped', 0))}|{int(p.get('files', 0))}"
                if sub.get("zip"):
                    fh, sub["fh"] = sub.get("fh"), None
                    if fh: fh.close()
                    threading.Thread(target=self._sub_unzip, args=(c, sub, info), daemon=True).start()
                else: self._sub_finish(c, "ok", info)
            elif cmd == "sub_empty": self._sub_finish(c, "empty")
            elif cmd == "sub_err": self._sub_finish(c, "bad", str(p.get("reason", ""))[:100])
        except (OSError, ValueError, TypeError) as e:
            self._sub_finish(c, "bad", "ghi file: " + str(e)[:80])

    def _sub_chunk(self, c, b):
        sub = c.sub
        if not sub or not sub.get("fh"): return
        sub["got"] += len(b); sub["total"] = sub.get("total", 0) + len(b)
        if sub.get("size") is not None and sub["got"] > sub["size"]: return self._sub_finish(c, "bad", "file lớn hơn khai báo")
        try: sub["fh"].write(b)
        except OSError as e: return self._sub_finish(c, "bad", "ghi file: " + str(e)[:80])
        if sub["total"] > int(self.cfg.get("submit_max_mb", 300)) * 1024 * 1024 * 2:
            self._sub_finish(c, "bad", "quá lớn")

    SKIP_FILES = ("thumbs.db", "desktop.ini", ".ds_store")

    @staticmethod
    def scan_dir(root):
        """Liệt kê 1 thư mục để gửi: ([(đường dẫn đầy đủ, đường dẫn tương đối)], [thư mục con], tổng byte). Bỏ qua liên kết tắt (symlink) và file tạm."""
        files, dirs, total = [], [], 0
        for dp, dns, fns in os.walk(root):
            dns[:] = sorted(d for d in dns if not os.path.islink(os.path.join(dp, d)))
            rel = os.path.relpath(dp, root).replace(os.sep, "/")
            if rel != ".": dirs.append(rel)
            for n in sorted(fns):
                p = os.path.join(dp, n)
                if os.path.islink(p) or n.startswith("~$") or n.lower() in Server.SKIP_FILES: continue
                try: total += os.path.getsize(p)
                except OSError: continue
                files.append((p, n if rel == "." else rel + "/" + n))
        return files, dirs, total

    @staticmethod
    def _send_one(c, fh, name, dest, rel=None, batch=None):
        with fh:
            c.send(cmd="file_start", name=name, size=os.fstat(fh.fileno()).st_size, dest=dest, rel=rel, batch=batch)
            while True:
                b = fh.read(CHUNK)
                if not b: break
                if not c.conn.send_chunk(b): raise ConnectionError
            c.send(cmd="file_end")

    @staticmethod
    def send_files(c, paths, report, dest=None, scans=None, batch=None):
        """Gửi lần lượt các file / thư mục tới 1 máy (chạy trong luồng riêng). Thư mục gửi nguyên cấu trúc thư mục con.
        Máy user bản cũ (< 2.3) chưa hiểu thư mục: chỉ gửi các file lẻ, bỏ qua thư mục."""
        can_dir = ver_ge(c.ver, "2.3")
        with c.file_lock:
            try:
                for p in paths:
                    if os.path.isdir(p):
                        if not can_dir: continue
                        files, dirs, _ = (scans or {}).get(p) or Server.scan_dir(p)
                        c.send(cmd="dir_start", name=os.path.basename(os.path.normpath(p)), dest=dest, dirs=dirs[:5000], files=len(files), batch=batch)
                        for fp, rel in files:
                            try: fh = open(fp, "rb")
                            except OSError: continue                    # file đang bị khóa / không đọc được: bỏ qua, gửi tiếp
                            Server._send_one(c, fh, os.path.basename(fp), dest, rel, batch)
                        c.send(cmd="dir_end")
                    else:
                        Server._send_one(c, open(p, "rb"), os.path.basename(p), dest, None, batch)
                report(True, c)
            except Exception:
                report(False, c)
