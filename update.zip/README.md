# Quản lý phòng máy (1 admin + tối đa 50 máy user, Windows / Linux)

*© 2026 @teamgv*

## Cài 1 chạm (đơn giản nhất)
Gói đã có sẵn **mã lớp** trong `config.json`, nên không phải nhập gì:
- **Máy giáo viên:** bấm đúp **`CAI-ADMIN.bat`** (Windows) hoặc chạy **`./cai-admin.sh`** (Linux).
- **Máy học sinh:** bấm đúp **`CAI-USER.bat`** (Windows) hoặc chạy **`./cai-user.sh`** (Linux).
Tự cài thư viện, tạo biểu tượng, mở tường lửa (Windows), chạy app ngay. Máy user tự tìm admin và tự chạy khi bật máy.
Mọi máy phải dùng **cùng một bản gói này** (cùng `config.json`) để trùng mã lớp.

### Gặp lỗi khi cài trên Windows
- **"Python thiếu tkinter":** file `.bat` tự tìm bản Python đầy đủ trên máy; nếu không có sẽ tự cài Python 3.12 bằng winget, và nếu winget lỗi thì tự tải bộ cài từ python.org (cần Internet, 1-3 phút, đừng đóng cửa sổ). Nếu vẫn không được: vào Settings > Apps > Python 3.12 > Modify và **tick "tcl/tk and IDLE"**, hoặc cài lại Python từ python.org.
- **"Smart App Control blocked a file":** Windows 11 chặn file tải từ Internet. Trước khi giải nén: chuột phải file zip → Properties → tick **Unblock** → OK. Nếu đã giải nén: mở PowerShell trong thư mục `lab`, chạy `Get-ChildItem -Recurse | Unblock-File`. Hoặc chép gói qua USB / thư mục mạng LAN.

## Icon
- `icon-admin.ico/png`, `icon-user.ico/png`: icon của **ứng dụng** (cửa sổ và thanh taskbar khi đang chạy).
- Biểu tượng **ngoài Desktop của admin** dùng icon cũ (`shortcut-admin.ico/png`), còn taskbar giữ `icon-admin.*`. Máy **user không tạo biểu tượng ngoài Desktop**. Muốn đổi icon ngoài Desktop: đặt file `shortcut-admin.ico` (Linux dùng `.png`) vào cùng thư mục với `setup.py` rồi cài lại. Không có file này thì biểu tượng ngoài Desktop dùng `icon-*`.

## Cài đặt tùy chỉnh (có giao diện 3 bước) (có giao diện, khuyên dùng)
Giải nén thư mục rồi:
- **Windows:** bấm đúp **`setup-windows.bat`**
- **Linux:** mở terminal trong thư mục, chạy **`./setup-linux.sh`** (nếu báo không có quyền: `chmod +x setup-linux.sh`)

Trình cài đặt tự cài Python/tkinter nếu thiếu, rồi hiện cửa sổ 3 bước:
1. Chọn máy này là **Admin** hay **User**.
2. Nhập **mã lớp** (bấm "Tạo ngẫu nhiên" trên máy admin, rồi nhập **đúng mã đó** trên mọi máy user). Máy user chọn "tự tìm admin" hoặc nhập IP.
3. Tùy chọn: biểu tượng Desktop, tự chạy khi bật máy, mở tường lửa. Bấm **CÀI ĐẶT**.

Cài xong sẽ có biểu tượng **LabManager Admin / LabManager User** (Desktop + menu ứng dụng). Muốn gỡ: chạy lại trình cài đặt, bấm **Gỡ cài đặt**.

Cần Internet ở lần cài đầu (tải Pillow, mss). Cài cho cả phòng máy: cài 1 máy user, đổi mã lớp/IP nếu cần rồi lặp lại trên các máy còn lại (mỗi máy chạy trình cài đặt một lần).

## Cài thủ công (tùy chọn)
`pip install -r requirements.txt`, sửa `secret` trong `config.json` (cùng mã trên mọi máy), rồi `python admin.py` / `python client.py`.
Máy user mặc định tự tìm admin; nếu không thấy: `python client.py --server IP_ADMIN`.
Tường lửa: admin mở **TCP 5000**; máy user cho phép **UDP 5001** và **TCP 5003**.

### Máy có phần mềm diệt virus / tường lửa bên thứ ba (ESET, Kaspersky, Bitdefender, Norton, Avast, BKAV…)
Trình cài chỉ mở cổng trong Windows Firewall nên các phần mềm này vẫn có thể chặn. Cách giải quyết chung: (1) tạm tắt tường lửa để xác định nguyên nhân; (2) cho phép `python.exe` / `pythonw.exe` trong `%LOCALAPPDATA%\LabManager` theo ứng dụng; (3) hoặc mở TCP 5003 vào ở máy user (TCP 5000 ở admin, UDP 5001 nếu muốn tự tìm admin); (4) hoặc đặt dải mạng phòng máy là mạng tin cậy; (5) thêm thư mục cài vào danh sách ngoại lệ của phần mềm diệt virus; (6) có quản trị tập trung thì nhờ IT đẩy policy. Chi tiết: bấm **F1** > mục 13.

### Không kết nối được: chạy công cụ chẩn đoán
Máy admin: bấm đúp **`CHAN-DOAN.bat`** (Linux `./chan-doan.sh`) – quét mạng, thử bắt tay với từng máy học sinh, báo máy nào trả lời / sai mã lớp và gợi ý nguyên nhân. Máy học sinh: `CHAN-DOAN.bat --admin IP_ADMIN` để thử nối tới admin. Báo cáo lưu ở `chan-doan.txt`.

### Tắt admin rồi mở lại không thấy máy học sinh
Bản cũ: đóng cửa sổ admin vẫn còn tiến trình ngầm giữ kết nối. Tắt `python.exe` / `pythonw.exe` của LabManager trong Task Manager rồi mở lại (làm một lần). Từ bản mới, admin thoát hẳn khi đóng; máy học sinh tự nhường cho admin mới sau ~15 giây nếu admin cũ biến mất đột ngột; admin quét dải /24 của mọi card mạng.

### Admin tự quét và kết nối ra máy user (khi máy admin có phần mềm chặn kết nối VÀO, ví dụ ESET)
Từ bản này, admin **chủ động quét dải mạng /24 của mình (mỗi 5 giây) và kết nối ra cổng TCP 5003 của máy user** (kết nối đi ra thường không bị chặn). Cách cũ (máy user nối vào admin) vẫn chạy song song.
- Máy user cần cho phép **TCP 5003** vào (trình cài đặt tự mở). Làm tay: `netsh advfirewall firewall add rule name=LabManager dir=in action=allow protocol=TCP localport=5003`
- Mạng không phải /24 hoặc nhiều dải: sửa `config.json` của **admin**, ví dụ `"scan": ["192.168.123.0/24", "192.168.124.0/24"]`
- Đổi tần suất quét: `"scan_interval": 5` (giây). Đổi cổng: `"agent_port": 5003` (cùng giá trị ở admin và user).

Máy user còn được cài thêm **tác vụ tự chạy lại**: nếu học sinh tắt app thì Windows bật lại trong ≤ 1 phút (Task Scheduler), Linux sau 3 giây (systemd). Gỡ cài đặt sẽ xóa tác vụ này.

## Gỡ cài đặt (khi không dùng nữa)
Làm trên **từng máy** (admin và mọi máy user):
- **Windows:** bấm đúp **`GO-CAI-DAT.bat`** (nếu hiện hộp thoại UAC để đóng cổng tường lửa thì bấm Yes).
- **Linux:** chạy `./go-cai-dat.sh` (nếu báo không có quyền: `chmod +x go-cai-dat.sh`).
- Hoặc mở trình cài đặt có giao diện (`setup-windows.bat` / `setup-linux.sh`) và bấm **Gỡ cài đặt**.

Bộ gỡ sẽ: tắt ứng dụng đang chạy, xóa tác vụ tự chạy lại (Task Scheduler / systemd) và tự chạy khi bật máy, xóa biểu tượng Desktop và menu, đóng cổng tường lửa Windows, khôi phục tùy chọn Ctrl+Alt+Del nếu máy đang bị khóa, rồi xóa thư mục cài đặt (`%LOCALAPPDATA%\LabManager` hoặc `~/.local/share/labmanager`). Python và thư viện đã cài nằm trong thư mục đó nên cũng mất theo; Python cài trên hệ thống không bị đụng tới.

**Không bị xóa** (là file của người dùng): thư mục `BaiLam`, `~/ThuBai` (bài đã thu trên máy admin). Xóa tay nếu không cần.

Nếu không chạy được bộ gỡ, gỡ thủ công theo thứ tự: (1) Windows: mở Task Scheduler xóa tác vụ `LabManagerUser`; Linux: `systemctl --user disable --now labmanager-user.service`. (2) Tắt tiến trình (Task Manager: `pythonw.exe`; Linux: `pkill -f labmanager`). (3) Xóa biểu tượng LabManager ở Desktop và thư mục Startup (`shell:startup`; Linux `~/.config/autostart`). (4) Xóa thư mục cài đặt. (5) Windows: xóa luật tường lửa `LabManager` (Windows Defender Firewall nâng cao).

## Hướng dẫn trong ứng dụng
Trên máy admin bấm **F1** (hoặc menu **Hướng dẫn** trên cùng) để mở cửa sổ hướng dẫn: hướng dẫn **từng công cụ** (khóa, tắt máy, chiếu màn hình, quản lý máy, gửi file, thu bài, nhận bài, gửi link, thông báo), phím tắt, **máy có ESET / firewall bên thứ ba** (cổng cần mở, cách tạo luật), xử lý khi không thấy máy học sinh, và các tùy chọn trong `config.json`.

## Chức năng
Màn hình admin là **lưới ảnh thu nhỏ** màn hình của từng máy user (cập nhật khoảng 2 giây/lần), kèm **số thứ tự máy**, tên máy, **tên tài khoản đang đăng nhập** và trạng thái.
- **Số thứ tự** (01, 02, 03…) đánh theo thứ tự hiển thị, sắp theo tên máy kiểu tự nhiên (PC2 trước PC10), nên đặt tên máy `PC01`, `PC02`… là số thứ tự khớp với vị trí máy trong phòng. Số này cũng hiện trong cửa sổ xem máy, Quản lý máy và danh sách Thu bài.
- **Tên tài khoản** (Windows/Linux đang đăng nhập) hiện ở dòng dưới tên máy; máy user cần chạy lại `CAI-USER` bằng gói mới để gửi thông tin này (máy bản cũ vẫn chạy bình thường, chỉ không hiện tài khoản).
- **Chọn máy:** bấm vào ô máy; giữ **Ctrl/Shift** để chọn thêm; **Ctrl+A** hoặc nút "Chọn tất cả" để chọn hết; bấm vùng trống để bỏ chọn. **Chưa chọn máy nào = áp dụng cho tất cả.**
- **Nhấp đúp** vào một máy = xem màn hình máy đó cỡ lớn. **Chuột phải** = menu nhanh.
- **Chương trình / web đang mở:** dưới mỗi máy hiện tên chương trình và tiêu đề cửa sổ phía trước (trình duyệt hiện tên trang web đang xem, không hiện địa chỉ đầy đủ). Chữ **đỏ** nếu chứa từ khóa như youtube, game, facebook… (sửa danh sách `watch_words` trong `config.json` của admin). Linux cần có lệnh `xprop` (gói `x11-utils`).
- **Các kiểu xem:** *Nhỏ / Vừa / Lớn* (cuộn khi nhiều máy); ***Tất cả***: tự co giãn để thấy **mọi máy trong 1 khung hình** (không cuộn, tự thu gọn thông tin khi máy nhiều); **F11** = admin toàn màn hình; nhấp đúp 1 máy = **phóng to** xem trực tiếp, trong cửa sổ đó nhấp đúp hoặc F11 để toàn màn hình, Esc để thoát.
- Cỡ ảnh Nhỏ / Vừa / Lớn và nút bật/tắt "Ảnh thu nhỏ" ở thanh dưới (tắt để tiết kiệm mạng).

| Nút | Tác dụng |
|---|---|
| Khóa / Mở khóa | Phủ màn hình đen toàn màn hình, **khóa hoàn toàn chuột + bàn phím** |
| Tắt máy | Tắt máy user ngay lập tức (có hỏi xác nhận) |
| Khởi động lại | Khởi động lại máy user ngay lập tức (có hỏi xác nhận). Máy bật lại xong, app tự chạy khi học sinh đăng nhập. Cũng có trong menu chuột phải |
| Chiếu màn hình ADMIN | Máy user hiện ảnh màn hình admin **phủ kín toàn bộ màn hình (không viền đen)**; nếu tỉ lệ 2 máy khác nhau, hình bị giãn nhẹ — muốn giữ đúng tỉ lệ (có viền đen) đặt `"present_fit": true` trong `config.json` của máy user; **khóa chuột + bàn phím, không thu nhỏ được** |
| Xem màn hình 1 máy | Xem màn hình của 1 user cỡ lớn ngay trên admin |
| Chiếu máy này cho cả lớp | Màn hình của user đó được chiếu cho các máy còn lại |
| Thu bài | Chọn máy học sinh (bắt buộc bấm chọn ít nhất 1 máy), chọn **loại file / thư mục / thời gian**, bấm **Xem file…** để thấy danh sách file trên từng máy, **tick đúng file cần thu** (mặc định chưa chọn file nào). Chỉ các file đã tick mới được nén và gửi về admin, lưu ở `~/ThuBai/<ngày_giờ>/<tên máy>_<IP>.zip` |
| Nhận bài | Admin bấm **Nhận bài**, đặt tên bài nộp và **chọn / tạo thư mục** lưu bài rồi bấm **Mở nhận bài**. Mọi máy học sinh đang kết nối (và máy kết nối sau đó) hiện cửa sổ **Nộp bài**: học sinh chọn file → **Nộp bài**, file gửi thẳng về thư mục admin (không cần chia sẻ thư mục Windows). Bài lưu ở `<thư mục>\<tên máy>\<file>`; nộp trùng tên thì thành `ten(1).ext`, không ghi đè. Thanh trạng thái hiện số file đã nhận. Bấm **Nhận bài** lần nữa để **Mở thư mục** hoặc **Đóng nhận bài** (cửa sổ nộp bài trên máy học sinh tự tắt). Mỗi file tối đa 100 MB (`"submit_file_max_mb"` trong config admin) |
| Quản lý 1 máy | Chọn đúng 1 máy rồi bấm **Quản lý 1 máy** (hoặc chuột phải → *Quản lý máy này*). Hộp thoại liệt kê các **ứng dụng học sinh đang mở** (tự cập nhật 5 giây): **Đóng ứng dụng** (gửi lệnh đóng cửa sổ như bấm dấu X, ứng dụng có thể hỏi lưu bài) hoặc **Buộc tắt** (tắt ngay, có thể mất dữ liệu). Học sinh thấy thông báo khi ứng dụng bị đóng |
| Điều khiển chuột / bàn phím | Trong cửa sổ **Xem 1 máy** bấm **Điều khiển chuột / bàn phím: TẮT** để bật. Chuột và bàn phím của admin trong khung ảnh sẽ điều khiển máy học sinh; máy học sinh hiện thông báo "Giáo viên đang điều khiển…". Bấm lại để tắt (đóng cửa sổ cũng tự tắt). Linux cần cài `xdotool` (ứng dụng: `wmctrl`) |
| Gửi file | Gửi 1 hay nhiều file; admin chọn thư mục đích trên máy user (mặc định **Desktop**, hoặc BaiLam/Documents/Pictures/Downloads). Không ghi đè file trùng tên |
| Thông báo | Gửi lời nhắc (có sẵn câu mẫu): hộp lớn hiện giữa màn hình máy user cho tới khi học sinh bấm "Đã hiểu" |
| Gửi link | Chọn: **mở ngay** trên máy user (web tự chạy) hoặc **chỉ gửi link** để học sinh tự nhấp; có thể mở luôn trên máy admin (chỉ nhận http/https) |
| Dừng chiếu | Dừng mọi trình chiếu |
| Chặn cài đặt | **Từ bản 2.1**, mặc định **BẬT**: học sinh không chạy được file cài đặt (setup, install, .msi, bộ cài đổi tên…). Máy học sinh tự đóng bộ cài và báo giáo viên; bấm **Chặn cài đặt** để Bật/Tắt, cho phép riêng từng file, xem nhật ký. **Không cần mã mở khóa**. Xem mục "Chặn cài đặt phần mềm" bên dưới |

(Windows hiện thêm biểu tượng emoji trên nút; Linux chỉ hiện chữ để tránh lỗi font emoji của Tk.)

Nếu máy user mất kết nối với admin thì tự mở khóa và tắt trình chiếu, tự kết nối lại sau 3 giây.

## Mở khóa phần mềm (nhập mã)
Máy **admin** luôn mở được, nhưng **chưa có mã (hoặc hết hạn) chỉ dùng các nút cơ bản**: Chọn tất cả, Khóa máy, Mở khóa, Tắt máy, Khởi động lại, Chiếu admin, Xem 1 máy, Quản lý 1 máy, Chiếu cả lớp, Dừng chiếu, Làm tươi. Các nút **Gửi file, Thu bài, Nhận bài, Gửi link, Thông báo, Chặn web** bị mờ. Nhập mã còn hạn thì **mở đầy đủ**. Máy học sinh không cần mã. Bấm menu **Mở khóa** ở thanh trên cùng → dán mã → **Mở khóa**.
- 3 loại mã: **1 tuần (7 ngày)**, **1 tháng (30 ngày)**, **1 năm (365 ngày)**. Thời hạn **bắt đầu tính từ lúc nhập mã**; thanh tiêu đề hiện thời gian còn lại.
- Mỗi mã dùng **1 lần**. Nhập thêm mã khi còn hạn thì cộng nối tiếp vào sau ngày hết hạn.
- Hết hạn: đúng lúc hết hạn app hiện thông báo và tắt ngay các chức năng nâng cao (dừng Chặn web / Nhận bài đang chạy, làm mờ nút); nhập mã mới là mở lại.
- Mã là chữ ký số Ed25519: ứng dụng chỉ chứa khóa công khai nên **không thể sinh mã hay dò ra mã** từ ứng dụng. Mã do nhà phát hành tạo bằng công cụ riêng `taoma.py` (**không** nằm trong gói này).
- Chỉnh lùi đồng hồ máy bị phát hiện và khóa lại. Dữ liệu mở khóa lưu ở `unlock.dat` (thư mục cài đặt) và `~/.labmanager_unlock`.

## Cập nhật / vá lỗi không cần cài lại (từ bản 34)
**Từ bản 1.7:** có nút **Cập nhật từ Internet** – tải thẳng gói mới từ máy chủ cập nhật (link cài sẵn, không phải dán); không có mạng thì vẫn chọn file như dưới đây.

Trên admin bấm **Cập nhật** → chọn gói mới (`.zip` hoặc thư mục, có thể chỉ chứa vài file đã sửa) → xác nhận. Admin tự vá chính nó, rồi **mọi máy user hiện thông báo "Có bản cập nhật mới" kèm nút *Cập nhật ngay***; học sinh bấm là máy tự tải, cài và mở lại ứng dụng trong vài giây.
- **Không đụng** `config.json` (mã lớp, phòng máy), `venv`, `BaiLam`, `ThuBai`.
- **An toàn:** kiểm tra cú pháp trước khi ghi; sau khi ghi chạy thử nạp chương trình, lỗi thì **tự quay về bản cũ**. Mỗi lần cập nhật sao lưu vào `backup/` (giữ 3 bản); nút **Khôi phục bản trước** quay lại và báo các máy user theo.
- **Admin là chuẩn:** máy user có bản khác admin sẽ được mời cập nhật. Hộp thoại Cập nhật liệt kê từng máy (Mới nhất / Chờ cập nhật / Bản cũ) và có nút **Nhắc lại**.
- Số bản nằm trong `version.txt` (hiện trên tiêu đề admin); mã bản dựng được tính từ nội dung code nên **vá lỗi mà không đổi số bản vẫn được nhận ra**.
- Nếu gói đổi `requirements.txt`, máy cần có Internet để cài thư viện mới.
- **Cài lại MỘT LẦN** bằng `CAI-ADMIN` / `CAI-USER` của bản 34 trở lên trên mọi máy để có chức năng này (máy đang chạy bản cũ hơn không có chức năng cập nhật và hiện "Bản cũ" trong hộp thoại). Từ đó về sau chỉ cần nút Cập nhật.

## Chặn web xấu / không an toàn (1.6: thêm nút “Quản lý phòng” – thêm/sửa/xóa phòng ngay trong admin; từ bản 1.1; tiêu đề hiện IP + mã lớp từ 1.2; sửa lỗi cập nhật "charmap" ở 1.3; 1.5: ghi nhật ký an toàn, cập nhật không còn lỗi “charmap”; 1.4: báo + nút “Mở lại admin” khi đã vá nhưng chương trình đang chạy bản cũ)
Trên admin bấm **Chặn web** (hoặc chuột phải → *Chặn web xấu…*): chọn nhóm cần chặn (web người lớn xxx, mạng xã hội Facebook/TikTok/Instagram…, cá cược, game online, video giải trí), tick **chặn/cảnh báo trang http không an toàn**, hoặc gõ thêm tên miền / từ khóa (mỗi dòng một mục) rồi bấm **Bật chặn**. Chưa chọn máy = áp dụng cho tất cả máy đang hiện. Cài đặt được nhớ (`webblock.json`), máy kết nối sau đó tự nhận nếu đang bật.

**Sao chép link trang học sinh đang xem (2.2):** trong hộp thoại **Chặn web** có danh sách *Trang học sinh đang mở / vừa mở* (tự cập nhật 2 giây/lần) cho các máy đang chọn. Chọn một hoặc nhiều dòng rồi bấm **Sao chép link** (hoặc nhấp đúp), **Thêm trang vào danh sách chặn** (chỉ thêm tên miền, vd `facebook.com`) hoặc **Thêm đúng link này**; sau đó bấm **Bật chặn** để áp dụng. Rê chuột vào biểu tượng cửa sổ dưới mỗi máy cũng thấy link. Máy học sinh đọc link từ lịch sử trình duyệt (Chrome, Edge, Brave, Cốc Cốc, Firefox…) – chỉ đọc, không cần quyền admin; tab ẩn danh không có trong lịch sử nên không hiện link. Máy học sinh cần chạy bản 2.2 (bấm **Cập nhật**).
Máy học sinh chặn theo 3 lớp (lớp nào đủ quyền thì làm): chính sách trình duyệt Chrome/Edge/Brave (Windows không cần quyền admin) → file hosts (cần quyền Administrator/root) → canh tiêu đề cửa sổ trình duyệt và **đóng tab** chứa trang bị chặn (mọi trình duyệt). Mất kết nối admin hoặc bấm **Tắt chặn** thì gỡ hết. Linux cần `xdotool`.
**Giới hạn:** nhận diện bằng tên miền / tiêu đề trang nên trang lạ có thể lọt – bổ sung vào ô *Chặn thêm*. Máy học sinh phải chạy bản mới (admin bấm **Cập nhật**).

## Chặn cài đặt phần mềm (từ bản 2.1)
Mặc định **BẬT** trên mọi máy học sinh ngay sau khi cập nhật; **không cần mã mở khóa**. Trên admin bấm **Chặn cài đặt** (hoặc chuột phải → *Chặn cài đặt phần mềm…*).
- **Bật chặn / Tắt chặn:** chưa chọn máy = áp dụng cho tất cả máy và lưu làm chính sách chung (`installblock.json`, máy kết nối sau cũng nhận). Chọn một số máy = chỉ áp dụng cho các máy đó, không đổi chính sách đã lưu.
- **Cho phép riêng:** mỗi dòng 1 tên file được phép chạy (vd: `setup-phanmem-truong.exe`).
- **Nhật ký:** các lần học sinh cố chạy file cài đặt (giờ, máy, tài khoản, tên file, đã đóng được chưa).
- **Máy học sinh:** canh chương trình vừa mở (0,4 giây/lần) và **đóng ngay** bộ cài, hiện thông báo cho học sinh. Chính sách được nhớ trên máy (`installblock_state.json`) nên **vẫn chặn khi mất kết nối admin và sau khi khởi động lại máy**. Không cần quyền Administrator.
- **Nhận diện bộ cài:** (1) công cụ cài của Windows: `msiexec` (.msi), AppInstaller (.msix), `wusa` (.msu), `winget`; (2) tên file chứa `setup` / `install` / `unins` / `caidat`; (3) file `.exe` nằm ngoài thư mục hệ thống mà bên trong là bộ cài (Inno Setup, NSIS, InstallShield, WiX/Burn, 7-Zip SFX…) nên đổi tên `setup.exe` thành `abc.exe` vẫn bị chặn; (4) file tạm `.tmp` do bộ cài giải nén ra Temp.
- **Không đụng tới:** dịch vụ hệ thống (phiên 0: Windows Update, `msiexec /V`, phần mềm quản trị tập trung), chương trình trong Windows / Program Files / ProgramData, thư mục cài LabManager.
- **Muốn cài phần mềm lên máy học sinh:** Tắt chặn trên máy đó rồi bật lại sau khi cài, hoặc thêm tên file vào ô *Cho phép riêng*. Tắt hẳn trên một máy: đặt `"install_block": false` trong `config.json` của máy đó.
- **Giới hạn:** tài khoản học sinh có quyền Administrator thì bộ cài chạy quyền cao, ứng dụng không đóng được (nhật ký ghi "KHÔNG đóng được") → dùng tài khoản học sinh thường. Chương trình chạy thẳng không cần cài (portable) không bị chặn. File `.bat` / `.ps1` có lệnh cài, hoặc bộ cài đóng gói lạ, có thể lọt. Phần mềm tự cập nhật cài riêng từng người dùng (vd: Chrome ở AppData) có thể bị chặn khi tự cập nhật → thêm vào *Cho phép riêng*. Linux: chỉ đóng được tiến trình của chính tài khoản học sinh (dpkg, apt, `snap install`, script install/setup/.run), lệnh `sudo` thì không.
- Máy học sinh cần bản 2.1 trở lên: admin bấm **Cập nhật**. Máy bản cũ hiện "CHƯA xác nhận" sau khi bấm Bật chặn.

## Thu bài làm
Bấm **Thu bài** trên admin, chọn loại file và khoảng thời gian rồi bấm **Thu bài**. Mỗi máy user tự tìm file bài làm và gửi về admin (giữ nguyên cấu trúc thư mục trong file zip).
- **Loại file:** ảnh (jpg, jpeg, png, gif, bmp, webp, tif, tiff, svg, heic) • tài liệu (doc, docx, odt, rtf, txt, pdf) • bảng tính (xls, xlsx, xlsm, ods, csv) • trình chiếu (ppt, pptx, pps, ppsx, odp). Các loại khác (chương trình, game…) không bao giờ được thu.
- **Tìm ở đâu:** `BaiLam`, Desktop, Documents, Pictures, Downloads của tài khoản học sinh (có cả khi Desktop/Documents được đồng bộ OneDrive). Bộ cài tạo sẵn thư mục `BaiLam` kèm biểu tượng ngoài Desktop để học sinh lưu bài vào.
- **Thời gian:** chỉ thu file được lưu/sửa trong khoảng chọn (mặc định 2 giờ qua) để không lẫn file cũ.
- **Minh bạch:** học sinh luôn thấy thông báo "Giáo viên đang thu bài…" và "Đã nộp … file".
- **Giới hạn** (`config.json` máy user): `submit_max_mb` (tổng mỗi máy, mặc định 300; vượt thì bỏ bớt file cũ nhất), `submit_file_max_mb` (mỗi file, mặc định 100), `submit_dirs` (danh sách thư mục tìm file, để trống = mặc định như trên). Máy admin: `collect_dir` (nơi lưu bài thu, mặc định `~/ThuBai`).
- File đang mở/bị khóa (vd. Word đang mở) có thể bị bỏ qua; nên nhắc học sinh lưu và đóng file trước khi thu. File tạm của Office (`~$…`) tự bị loại.
- Chạy lại `CAI-USER` trên các máy user bằng gói mới để có chức năng này.

## Tự chạy khi bật máy user
- **Windows:** `Win+R` → `shell:startup` → tạo shortcut tới `pythonw.exe "C:\...\client.py"`.
- **Linux:** tạo `~/.config/autostart/lab.desktop` với `Exec=python3 /đường/dẫn/client.py`.

## Lưu ý
- **Linux phải dùng phiên X11** (Ubuntu: chọn "Ubuntu on Xorg" lúc đăng nhập). Wayland chặn chụp màn hình.
- **Tắt máy trên Linux:** user chạy client cần quyền `systemctl poweroff` (thường có sẵn với người dùng đang ngồi tại máy); nếu không, chạy client bằng quyền root hoặc thêm sudoers.
- Khóa máy bằng lớp phủ: không chặn được Ctrl+Alt+Del của Windows. Nếu cần chặt hơn, hãy dùng tài khoản học sinh bị hạn chế quyền.
- Mạng yếu / Wi-Fi: giảm `fps`, `width`, `quality` và **`present_width`** (độ rộng ảnh khi chiếu, mặc định 1280) trong `config.json` của admin. Mặc định 3 khung/giây, 1024px; màn hình đứng yên thì gần như không tốn băng thông.
- Dữ liệu truyền không mã hóa (đủ cho mạng nội bộ phòng máy).


### Giới hạn của điều khiển từ xa
- Chương trình học sinh chạy bằng quyền người dùng thường nên **không điều khiển được cửa sổ chạy bằng quyền Administrator** (UAC, Task Manager chạy quyền cao…) và không thấy màn hình đăng nhập Windows.
- Không có Ctrl+Alt+Del / phím Windows từ xa.
- Chặn cổng USB hoặc khóa bàn phím/chuột ở mức hệ thống cần quyền quản trị Windows, chưa có trong bản này.

## Nút Làm tươi
Trên thanh công cụ admin, bấm **Làm tươi** để quét lại mạng LAN ngay (không chờ vòng 5 giây), bỏ các kết nối đã chết và hiện máy user mới cài. Máy cài lại cùng IP sẽ tự thay kết nối cũ.
Nếu vẫn không thấy máy: kiểm tra mã lớp giống nhau, cùng dải mạng, và tường lửa máy user mở TCP 5003 (Windows: lúc cài phải bấm Yes ở hộp UAC).

## Quản lý nhiều phòng máy (mã lớp khác nhau) từ một máy admin
Mỗi phòng dùng **một mã lớp riêng**; một máy admin nhận được tất cả.
- Cài admin bằng cửa sổ đầy đủ (`setup-windows.bat`): ở Bước 2 điền ô **Phòng máy thêm**, mỗi dòng một phòng: chỉ gõ mã (tên tự đặt "Phòng 2", "Phòng 3"…) hoặc `Tên = mã`, ví dụ `Phòng Tin = Kx7mQ4tB`. Mã ở ô trên cùng là phòng 1.
- Hoặc sửa `config.json` của admin (`%LOCALAPPDATA%\LabManager\config.json`):
  `"secret": "MA_PHONG_1", "room_name": "Phòng 1", "rooms": [{"name": "Phòng 2", "secret": "MA_PHONG_2"}]` rồi mở lại admin.
- Máy user của phòng nào thì cài với mã của phòng đó (mỗi phòng một gói / một `config.json`). Trên ô máy của admin hiện thêm nhãn `[Tên phòng]`.
- Cài đè admin bằng cài nhanh (`CAI-ADMIN.bat`) vẫn giữ danh sách phòng thêm.
- Máy user chỉ cần biết mã của phòng mình; không biết mã phòng khác.
- **Lọc theo phòng:** khi admin có từ 2 phòng trở lên, ô **Phòng:** ở thanh dưới cửa sổ admin cho chọn *Tất cả* hoặc từng phòng. Chỉ máy của phòng đang chọn hiện ra, và các lệnh áp dụng cho "tất cả" (khóa, tắt máy, chiếu cả lớp, gửi file…) chỉ tác động lên các máy đang hiện.
- **Ô máy:** số máy và tên nằm trên cùng; dưới ảnh là hàng icon (trạng thái, tài khoản, IP/phòng/hệ điều hành, cửa sổ đang mở). Rê chuột lên icon để xem chi tiết; icon cửa sổ chuyển đỏ nếu chứa từ khóa trong `watch_words`.
