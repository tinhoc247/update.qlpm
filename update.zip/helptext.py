"""Nội dung cửa sổ Hướng dẫn (F1) của máy ADMIN."""

TOPICS = [
("1. Bắt đầu nhanh", """BẮT ĐẦU NHANH

CÀI ĐẶT
- Máy giáo viên: chạy CAI-ADMIN.bat (Windows) hoặc ./cai-admin.sh (Linux).
- Máy học sinh: chạy CAI-USER.bat (Windows) hoặc ./cai-user.sh (Linux).
- Mọi máy phải dùng CÙNG MỘT bản gói (cùng config.json) để trùng mã lớp.
- Máy học sinh tự tìm admin và tự chạy lại khi bật máy.

SAU KHI CÀI
Vài giây sau, các máy học sinh hiện trên lưới của admin: số thứ tự, tên máy, tên tài khoản, ảnh màn hình và trạng thái.

NGUYÊN TẮC DÙNG CÁC NÚT
- Bấm vào ô máy để chọn. Chưa chọn máy nào = nút áp dụng cho TẤT CẢ máy.
- Riêng Chiếu cả lớp, Quản lý 1 máy: bắt buộc phải chọn máy (xem từng mục). Thu bài không chọn máy = thu tất cả.
- Lệnh nguy hiểm (Tắt máy, Khởi động lại) luôn hỏi xác nhận.

MUỐN XEM NHANH TỪNG CÔNG CỤ
Dùng danh sách bên trái: mỗi nút trên thanh công cụ có một mục riêng.
"""),

("2. Màn hình admin (lưới máy)", """MÀN HÌNH ADMIN

MỖI Ô MÁY HIỆN
- Số thứ tự và tên máy, ví dụ "03. PC03". Số thứ tự đánh theo tên máy kiểu tự nhiên (PC2 trước PC10). Đặt tên máy PC01, PC02... thì số khớp với vị trí máy trong phòng.
- Tên tài khoản đang đăng nhập, địa chỉ IP, hệ điều hành.
- Trạng thái: Sẵn sàng / Đã khóa / Đang nhận trình chiếu / Đang chia sẻ màn hình.
- Chương trình hoặc trang web học sinh đang mở (trình duyệt hiện tên trang, không hiện địa chỉ đầy đủ). Chữ ĐỎ nếu chứa từ khóa như youtube, game, facebook... (sửa danh sách "watch_words" trong config.json của admin).
- Máy bị khóa: ảnh tối và có biểu tượng khóa. Máy đang chiếu hoặc đang được xem: có huy hiệu ở góc ảnh.

CHỌN MÁY
- Bấm vào ô để chọn. Giữ Ctrl hoặc Shift để chọn thêm hoặc bỏ chọn.
- Ctrl+A hoặc nút "Chọn tất cả": chọn hết. Bấm vùng trống: bỏ chọn.
- Nhấp đúp ô máy: xem màn hình máy đó cỡ lớn. Chuột phải: menu nhanh.

THANH DƯỚI CÙNG
- Cỡ ảnh: Nhỏ / Vừa / Lớn (cuộn khi nhiều máy) hoặc "Tất cả": tự co giãn để thấy mọi máy trong 1 khung hình, không cần cuộn. Máy càng nhiều thì thông tin phụ càng được rút gọn.
- "Ảnh thu nhỏ": tắt để tiết kiệm mạng (chỉ còn danh sách và trạng thái).
- F11: admin toàn màn hình, Esc để thoát.
- Dòng trạng thái bên trái cho biết kết quả của lệnh vừa gửi.
"""),

("3. Chọn tất cả / Khóa / Mở khóa / Tắt tiếng", """KHÓA MÁY / MỞ KHÓA / TẮT TIẾNG

KHÓA MÁY
Phủ màn hình đen toàn màn hình trên máy học sinh và khóa hoàn toàn chuột + bàn phím.
- Chọn máy cần khóa rồi bấm "Khóa máy". Không chọn máy nào = khóa cả lớp.
- Trên admin, ô máy bị khóa hiện tối và có biểu tượng khóa.

MỞ KHÓA
Bấm "Mở khóa" (cũng áp dụng cho máy đã chọn hoặc tất cả).

TẮT TIẾNG / MỞ TIẾNG
- "Tắt tiếng" tắt âm thanh loa trên máy học sinh; "Mở tiếng" bật lại. Áp dụng cho máy đã chọn, không chọn máy nào = tất cả máy đang hiện (cũng có trong menu chuột phải).
- Máy đang bị tắt tiếng hiện biểu tượng loa gạch chéo đỏ trên ô máy. Học sinh tự bật lại loa thì ứng dụng tự tắt lại sau vài giây, cho tới khi admin bấm "Mở tiếng".
- Máy học sinh cần Windows, hoặc Linux có pactl (PulseAudio / PipeWire) hay amixer, hoặc macOS.

LƯU Ý
- Khóa bằng lớp phủ không chặn được Ctrl+Alt+Del của Windows. Nếu cần chặt hơn, dùng tài khoản học sinh bị hạn chế quyền.
- Nếu máy học sinh mất kết nối với admin thì tự mở khóa, rồi tự kết nối lại sau 3 giây.

CHỌN TẤT CẢ
Nút "Chọn tất cả" (hoặc Ctrl+A) chọn mọi máy đang hiện trên lưới.
"""),

("4. Tắt máy / Khởi động lại", """TẮT MÁY / KHỞI ĐỘNG LẠI

TẮT MÁY
Tắt NGAY các máy đã chọn (không chọn = tất cả). Có hộp thoại xác nhận, học sinh mất dữ liệu chưa lưu, nên nhắc lưu bài trước.

KHỞI ĐỘNG LẠI
Khởi động lại ngay các máy đã chọn, cũng có xác nhận. Máy bật lại xong, ứng dụng tự chạy khi học sinh đăng nhập. Có trong menu chuột phải.

LƯU Ý
- Máy đã tắt thì không bật lại từ xa được (app chưa hỗ trợ Wake-on-LAN).
- Linux: tài khoản chạy client cần quyền "systemctl poweroff" (thường có sẵn với người đang ngồi tại máy).
"""),

("5. Chiếu màn hình / Xem 1 máy", """CHIẾU VÀ XEM MÀN HÌNH

CHIẾU ADMIN
Máy học sinh hiện ảnh màn hình của admin, phủ kín toàn màn hình (không viền đen), khóa chuột + bàn phím, không thu nhỏ được.
- Chọn máy hoặc để trống để chiếu cả lớp.
- Nếu tỉ lệ màn hình 2 máy khác nhau, hình bị giãn nhẹ. Muốn giữ đúng tỉ lệ (có viền đen), đặt "present_fit": true trong config.json của MÁY HỌC SINH.
- Mạng yếu: giảm "present_width" (mặc định 1280), "fps", "quality" trong config.json của admin.

XEM 1 MÁY
Nhấp đúp vào ô máy (hoặc chuột phải vào máy > "Xem màn hình máy này"): xem màn hình máy đó cỡ lớn ngay trên admin. Trong cửa sổ xem: nhấp đúp hoặc F11 để toàn màn hình, Esc để thoát.

CHIẾU CẢ LỚP
Chọn đúng 1 máy học sinh rồi bấm "Chiếu cả lớp": màn hình của máy đó được chiếu cho tất cả máy còn lại (dùng để học sinh giỏi trình bày bài).

DỪNG CHIẾU
Dừng mọi trình chiếu và xem đang chạy.

ĐIỀU KHIỂN CHUỘT / BÀN PHÍM TỪ XA
Trong cửa sổ Xem 1 máy, bấm "Điều khiển chuột / bàn phím: TẮT" để bật. Chuột và bàn phím của admin trong khung ảnh sẽ điều khiển máy học sinh; máy học sinh hiện thông báo "Giáo viên đang điều khiển...". Bấm lại để tắt (đóng cửa sổ cũng tự tắt).
- Không điều khiển được cửa sổ chạy bằng quyền Administrator (UAC, Task Manager quyền cao) và màn hình đăng nhập Windows.
- Không gửi được Ctrl+Alt+Del và phím Windows.
- Linux cần cài xdotool (và wmctrl cho phần quản lý ứng dụng).
"""),

("6. Quản lý 1 máy (ứng dụng)", """QUẢN LÝ 1 MÁY

Chọn đúng 1 máy rồi bấm "Quản lý 1 máy" (hoặc chuột phải > "Quản lý máy này"). Cũng mở được từ cửa sổ Xem 1 máy qua nút "Ứng dụng đang chạy...".

HỘP THOẠI LIỆT KÊ
Các ứng dụng học sinh đang mở (tự cập nhật mỗi 5 giây).
- Đóng ứng dụng: gửi lệnh đóng cửa sổ như bấm dấu X. Ứng dụng có thể hỏi lưu bài, nên an toàn cho dữ liệu.
- Buộc tắt: tắt ngay, có thể mất dữ liệu chưa lưu. Chỉ dùng khi ứng dụng không chịu đóng.
- Học sinh luôn thấy thông báo khi ứng dụng bị đóng.

LƯU Ý
Linux cần cài wmctrl và xprop (gói x11-utils).
"""),

("7. Gửi file / thư mục", """GỬI FILE / THƯ MỤC

CÁCH DÙNG
1. Chọn máy nhận (không chọn = tất cả).
2. Bấm "Gửi file". Hộp thoại mở sẵn cửa sổ chọn file (bấm Hủy nếu không cần). Dùng "Thêm file..." và/hoặc "Thêm thư mục..." để chọn; có thể chọn lẫn cả file lẻ và thư mục, bấm "Bỏ mục chọn" để bỏ bớt.
3. Chọn thư mục đích trên máy học sinh: mặc định Desktop, hoặc BaiLam, Documents, Pictures, Downloads. Bấm "Gửi".

LƯU Ý
- Thư mục gửi xuống được giữ nguyên cấu trúc thư mục con (kể cả thư mục rỗng). Liên kết tắt (symlink), file tạm (~$...), Thumbs.db, desktop.ini được bỏ qua; file đang bị khóa trên máy admin bị bỏ qua.
- Không ghi đè: file trùng tên thành ten(1).ext, thư mục trùng tên thành ThuMuc(1).
- Học sinh thấy thông báo "Đang nhận thư mục..." rồi "Đã nhận thư mục: ... (N file)".
- Gửi thư mục cần máy học sinh bản 2.3 trở lên. Máy bản cũ chỉ nhận file lẻ (admin được cảnh báo trước khi gửi): bấm Cập nhật.
- Tổng dung lượng trên 1 GB sẽ được hỏi xác nhận trước khi gửi.
- Gửi cho nhiều máy cùng lúc; thanh trạng thái hiện "Gửi file: xong x/y máy" và số máy lỗi (nếu có).
- Muốn học sinh nộp ngược lại cho giáo viên, dùng "Nhận bài" hoặc "Thu bài".
"""),

("8. Thu bài (admin kéo bài về)", """THU BÀI

Admin chủ động lấy bài làm từ máy học sinh. Chọn máy cần thu (giữ Ctrl để chọn nhiều); KHÔNG chọn máy nào = thu của TẤT CẢ máy đang hiển thị.

CÁC BƯỚC
1. Chọn máy, bấm "Thu bài".
2. Chọn THU GÌ: "File bài làm" (chọn theo loại) hoặc "Cả thư mục" (mọi loại file, giữ nguyên thư mục con).
3. Với "File bài làm", chọn LOẠI FILE: ảnh, tài liệu (doc, docx, odt, rtf, txt, pdf), bảng tính, trình chiếu. Các loại khác (chương trình, game...) không bao giờ được thu. (Thu cả thư mục thì ô loại file bị mờ.)
4. Chọn THƯ MỤC tìm bài trên máy học sinh: Desktop (chọn sẵn), BaiLam, Documents, Pictures, Downloads (có cả khi được đồng bộ OneDrive). Tick thêm BaiLam nếu học sinh lưu bài ở đó. Với "Cả thư mục", mỗi thư mục con trực tiếp (vd Desktop\\BaiTap) là một mục để chọn.
5. Chọn THỜI GIAN: chỉ thu file (hoặc thư mục có file) lưu / sửa trong 1 / 2 / 4 / 24 giờ qua, hoặc tất cả. Mặc định 2 giờ để không lẫn file cũ.
6. Bấm "Xem file...": hiện danh sách file (hoặc thư mục, kèm số file và dung lượng) trên từng máy. TICK đúng mục cần thu (mặc định chưa tick mục nào).
7. Chỉ các mục đã tick được gửi về admin (từng file, KHÔNG nén).\nThu cả lớp 1 lần: bỏ chọn mọi máy, tick \"Thu TẤT CẢ ngay\" ở hộp thoại Thu bài: bỏ qua bước xem danh sách, máy nào cũng nộp hết file / thư mục phù hợp (theo loại, thư mục, thời gian đã chọn).

TỰ CHỌN FILE / THƯ MỤC TRÊN MÁY HỌC SINH
Trong hộp thoại Thu bài chọn “Tự chọn file / thư mục”, bấm “Duyệt máy...”: cửa sổ hiện cây thư mục của máy học sinh (bắt đầu ở thư mục người dùng; nút Ổ đĩa để sang ổ khác). Bấm đúp để mở thư mục, chọn file / thư mục (Ctrl hoặc Shift để chọn nhiều) rồi bấm “Thêm vào danh sách thu”. Chọn nhiều máy: đổi máy ở ô “Máy đang duyệt”, mỗi máy có danh sách riêng; tick “Áp dụng cho tất cả máy” để thêm cùng đường dẫn (trong thư mục người dùng, vd Desktop/BaiTap) cho mọi máy, máy nào không có đường dẫn đó sẽ bỏ qua. Cuối cùng bấm “Thu các mục đã thêm”. Máy học sinh cần bản 2.6 trở lên.

THU LẠI FILE / THƯ MỤC ĐÃ GỬI (bản 2.7.0)
Ví dụ: gửi thư mục Demo ra Desktop, học sinh sửa xong thì thu lại đúng thư mục đó. Bấm "Thu bài" > chọn "Thu lại đúng file / thư mục ĐÃ GỬI" > chọn lần gửi trong danh sách > "Thu lại ngay". Không cần duyệt hay tick. Bài lưu kèm tên máy: thư mục Demo thành Demo_PC01, Demo_PC02...; file lẻ bai.docx thành bai_PC01.docx. Máy học sinh cần bản 2.7.0 và chỉ thu lại được những gì nhận từ lần gửi sau khi cập nhật. Học sinh đổi tên / di chuyển / xóa thì máy đó báo không có file.

KẾT QUẢ
Lưu ở  <thư mục admin chọn>/<ngày_giờ>/<tên máy>/<file hoặc thư mục>  (file nguyên bản, không nén, giữ nguyên cấu trúc thư mục; hai máy trùng tên thì thêm IP vào tên thư mục). Trong hộp thoại Thu bài, ô "Lưu bài thu vào thư mục" + nút Chọn... cho phép chọn / tạo thư mục lưu trên máy admin; mặc định lấy từ "collect_dir" trong config.json (~/ThuBai).

LƯU Ý
- Học sinh luôn thấy thông báo "Giáo viên đang thu bài..." và "Đã nộp ... file".
- File đang mở (ví dụ Word đang mở) có thể bị bỏ qua: nhắc học sinh lưu và đóng file trước khi thu. File tạm của Office (~$...) tự bị loại.
- Thu cả thư mục: file ẩn (bắt đầu bằng dấu chấm), file tạm, symlink bị loại; mỗi thư mục tối đa 20.000 file. Cần máy học sinh bản 2.3 trở lên (máy bản cũ bị bỏ qua và admin được báo).
- Giới hạn trong config.json của máy học sinh: "submit_max_mb" (tổng mỗi máy, mặc định 300), "submit_file_max_mb" (mỗi file, mặc định 100), "submit_dirs" (thư mục tìm file).
"""),

("9. Nhận bài (học sinh tự nộp)", """NHẬN BÀI

Học sinh tự chọn file và gửi thẳng về thư mục của admin, không cần chia sẻ thư mục Windows.

CÁC BƯỚC
1. Bấm "Nhận bài".
2. Đặt "Tên bài nộp" (học sinh sẽ thấy), chọn hoặc tạo THƯ MỤC lưu bài trên máy admin (mặc định ~/NopBai/<ngày_giờ>).
3. Bấm "Mở nhận bài". Mọi máy học sinh đang kết nối (và máy kết nối sau đó) hiện cửa sổ "Nộp bài".
4. Học sinh chọn file, bấm "Nộp bài".

KẾT QUẢ
- Bài lưu ở  <thư mục>\\<tên máy>\\<file>. Nộp trùng tên thì thành ten(1).ext, không ghi đè.
- Thanh trạng thái hiện số file đã nhận và số máy đã nộp.

KẾT THÚC
Bấm "Nhận bài" lần nữa để "Mở thư mục" xem bài, hoặc "Đóng nhận bài" (cửa sổ Nộp bài trên máy học sinh tự tắt). Học sinh KHÔNG tự đóng được cửa sổ này (nút X vô hiệu, không có nút Đóng); chỉ admin đóng nhận bài hoặc mất kết nối admin mới tắt.

LƯU Ý
Mỗi file tối đa 100 MB (đổi bằng "submit_file_max_mb" trong config.json của admin).

NÊN DÙNG THU BÀI HAY NHẬN BÀI?
- Nhận bài: học sinh chủ động nộp, hợp khi học sinh biết bài nằm ở đâu.
- Thu bài: admin tự lấy, hợp khi hết giờ mà học sinh chưa kịp nộp.
"""),

("10. Gửi link", """GỬI LINK / MỞ WEB

1. Chọn máy nhận (không chọn = tất cả), bấm "Gửi link".
2. Nhập địa chỉ web (không gõ https:// cũng được). Chỉ nhận link http/https hợp lệ.
3. Chọn kiểu gửi:
   - "Mở ngay trên máy học sinh": web tự chạy luôn.
   - "Chỉ gửi link": học sinh tự nhấp vào link để mở.
4. Tùy chọn: "Mở luôn trang này trên máy admin".
5. Bấm "Gửi" (hoặc Enter).

DÙNG KHI NÀO
Cho cả lớp vào cùng một bài kiểm tra trực tuyến, game, trang tài liệu... mà không phải đọc địa chỉ cho từng em.
"""),

("11. Thông báo", """THÔNG BÁO

Gửi lời nhắc: một hộp lớn hiện giữa màn hình máy học sinh cho tới khi học sinh bấm "Đã hiểu".

CÁCH DÙNG
1. Chọn máy nhận (không chọn = tất cả), bấm "Thông báo".
2. Gõ nội dung (tối đa 300 ký tự) hoặc bấm câu mẫu: "Hãy tập trung làm bài.", "Dừng chơi game, quay lại bài học.", "Còn 5 phút nữa."
3. Bấm "Gửi".

MẸO
Kết hợp với màu đỏ trên lưới: thấy ô máy chữ đỏ (youtube, game...) thì chọn đúng máy đó rồi gửi thông báo.
"""),

("11b. Chặn web xấu", """CHẶN WEB XẤU / KHÔNG AN TOÀN

Bấm nút Chặn web (hoặc chuột phải > Chặn web xấu). Chưa chọn máy = áp dụng cho tất cả máy đang hiện.
- Chọn nhóm: Web người lớn (xxx), Mạng xã hội (Facebook, TikTok, Instagram...), Cá cược, Game online, Video giải trí (YouTube, Netflix...).
- Ô "Chặn thêm": mỗi dòng 1 tên miền (vd: tiktok.com) hoặc 1 từ khóa (vd: cờ bạc).
- Tick "Chặn / cảnh báo trang http không an toàn": bắt trình duyệt chỉ vào trang https (Chrome, Edge, Brave trên Windows).
- Bấm Bật chặn / Tắt chặn. Cài đặt được nhớ; máy mới kết nối sau đó nhận luôn nếu đang bật.

MÁY HỌC SINH CHẶN THẾ NÀO (3 lớp, lớp nào đủ quyền thì làm)
1. Chính sách trình duyệt Chrome / Edge / Brave (Windows: không cần quyền admin).
2. File hosts (cần quyền Administrator / root) – chặn mọi trình duyệt.
3. Canh cửa sổ trình duyệt: tiêu đề trang chứa tên trang bị chặn thì tự đóng tab đó và báo học sinh. Chạy được ở mọi máy, kể cả Firefox, Cốc Cốc.
Mất kết nối với admin hoặc Tắt chặn: mọi thay đổi được gỡ về như cũ.

LƯU Ý
- Lớp 3 dựa vào tiêu đề trang nên trang lạ (chưa có tên trong danh sách) có thể lọt; hãy thêm vào ô "Chặn thêm". Trang đổi tên miền liên tục thì cần cập nhật danh sách.
- Linux cần lệnh xdotool để đóng tab (và xprop như phần giám sát cửa sổ).
- Học sinh dùng VPN, proxy hoặc trình duyệt di động-portable có thể né lớp 1-2; lớp 3 vẫn đóng được theo tiêu đề.
- Máy học sinh cần chạy bản có tính năng này (admin bấm Cập nhật).
"""),

("11c. Chặn cài đặt phần mềm", """CHẶN HỌC SINH CÀI ĐẶT PHẦN MỀM

Mặc định BẬT trên mọi máy học sinh (từ bản 2.1). Không cần mã mở khóa. Bấm nút Chặn cài đặt (hoặc chuột phải > Chặn cài đặt phần mềm).
- Bật chặn / Tắt chặn: chưa chọn máy = áp dụng cho tất cả máy và LƯU làm chính sách chung (máy kết nối sau cũng nhận). Chọn một số máy = chỉ áp dụng cho các máy đó.
- Ô \"Cho phép riêng\": mỗi dòng 1 tên file được phép chạy (vd: setup-phanmem-truong.exe). Dùng khi giáo viên cần cài một phần mềm có chủ ý.
- Nhật ký: hiện các lần học sinh cố chạy file cài đặt (giờ, máy, tài khoản, tên file, đã đóng được chưa).

MÁY HỌC SINH LÀM GÌ
Canh các chương trình vừa mở (mỗi 0,4 giây) và ĐÓNG NGAY bộ cài, hiện thông báo \"Máy này không được cài đặt phần mềm\". Chặn cả khi mất kết nối admin và sau khi khởi động lại máy (chính sách được nhớ trên máy). Nhận diện:
1. Công cụ cài của Windows: msiexec (file .msi), AppInstaller (.msix), wusa (.msu), winget.
2. Tên file chứa setup / install / unins / caidat (Setup.exe, ChromeSetup.exe, unins000.exe...).
3. File .exe nằm ngoài thư mục hệ thống mà bên trong là bộ cài (Inno Setup, NSIS, InstallShield, WiX/Burn, 7-Zip SFX...) nên đổi tên setup.exe thành abc.exe vẫn bị chặn.
4. File tạm .tmp do bộ cài giải nén ra thư mục Temp.
Không đụng tới: dịch vụ hệ thống (Windows Update, phần mềm quản trị tập trung), chương trình trong Windows / Program Files / ProgramData, và thư mục cài LabManager.

MUỐN CÀI PHẦN MỀM LÊN MÁY HỌC SINH
Cách 1: Tắt chặn trên máy đó, cài xong bật lại. Cách 2: thêm tên file bộ cài vào ô \"Cho phép riêng\" rồi Bật chặn.
Tắt hẳn trên 1 máy bất kể admin chọn gì: đặt \"install_block\": false trong config.json của máy đó, chạy lại ứng dụng.

GIỚI HẠN (nên biết)
- Học sinh dùng tài khoản Administrator hoặc nhập được mật khẩu quản trị thì bộ cài chạy với quyền cao, ứng dụng không đóng được; nhật ký ghi \"KHÔNG đóng được\". Hãy dùng tài khoản học sinh thường (Standard User).
- Chương trình chạy thẳng không cần cài (portable, game giải nén sẵn) KHÔNG bị chặn; muốn chặn thì dùng Quản lý 1 máy hoặc chặn bằng chính sách của Windows (AppLocker).
- File .bat / .cmd / .ps1 có lệnh cài đặt, và bộ cài đóng gói ở dạng lạ (không có tên / dấu hiệu bộ cài), có thể lọt.
- Phần mềm tự cập nhật cài riêng cho từng người dùng (vd: Chrome cài ở AppData) có thể bị chặn khi tự cập nhật; thêm tên file vào \"Cho phép riêng\" nếu cần.
- Linux: chặn lệnh cài gói của tài khoản học sinh (dpkg, apt, snap install...) và script install / setup / .run; lệnh chạy bằng sudo (quyền root) ứng dụng không đóng được.
- Máy học sinh cần chạy bản 2.1 trở lên (admin bấm Cập nhật). Máy bản cũ hiện \"CHƯA xác nhận\" sau khi bấm Bật chặn.
"""),

("12. Mở khóa phần mềm (nhập mã)", """MỞ KHÓA PHẦN MỀM

CHƯA CÓ MÃ vs CÓ MÃ
- Chưa mở khóa (hoặc hết hạn): vẫn dùng được Chọn tất cả, Khóa máy, Mở khóa, Tắt tiếng, Mở tiếng, Tắt máy, Khởi động lại, Chiếu admin, Quản lý 1 máy, Chiếu cả lớp, Dừng chiếu, Làm tươi. Các nút Gửi file, Thu bài, Nhận bài, Gửi link, Thông báo, Chặn web bị mờ, không dùng được (cả trong menu chuột phải).
- Đã nhập mã còn hạn: dùng đầy đủ mọi chức năng.

CÁCH NHẬP MÃ
1. Bấm menu "Nhập mã" ở trên cùng.
2. Dán mã vào ô (nút "Dán từ clipboard" hoặc Ctrl+V), bấm "Mở khóa".
3. Mã đúng thì báo ngày giờ hết hạn. Thời hạn còn lại hiện ở thanh tiêu đề.

CÁC LOẠI MÃ
- 1 tuần  = 7 ngày
- 1 tháng = 30 ngày
- 1 năm   = 365 ngày
Thời hạn BẮT ĐẦU TÍNH TỪ LÚC NHẬP MÃ (mở khóa), không phải từ lúc nhận mã.

LƯU Ý
- Mỗi mã chỉ kích hoạt được đúng 1 lần (mọi máy). Cần Internet lúc nhập mã; nhập xong chạy offline bình thường. Nếu báo \"không kết nối được\" thì mã chưa mất, kiểm tra mạng rồi nhập lại. Nhập thêm mã khi còn hạn thì được cộng nối tiếp vào sau ngày hết hạn hiện tại.
- Khi hết hạn lúc đang chạy: các chức năng nâng cao TẮT NGAY đúng lúc hết hạn: hiện thông báo, dừng Chặn web / Nhận bài đang chạy, đóng cửa sổ của chúng và làm mờ nút; các nút cơ bản vẫn dùng được.
- Mã dài (khoảng 136 ký tự) vì là chữ ký số; hãy dán nguyên mã, có hay không có dấu gạch ngang đều được.
- Không chỉnh lùi đồng hồ máy: chương trình phát hiện và sẽ khóa lại cho tới khi đồng hồ đúng.
- Mã do nhà phát hành cấp bằng công cụ riêng; ứng dụng không có chức năng tạo mã.
- Máy học sinh không cần mã, chỉ máy admin.
"""),

("12b. Cập nhật / vá lỗi (không cài lại)", """CẬP NHẬT / VÁ LỖI PHẦN MỀM

DÙNG KHI NÀO
Khi có bản mới hoặc bản vá lỗi (nhận được file .zip hoặc thư mục mới). Không cần chạy lại CAI-ADMIN / CAI-USER trên từng máy.

CÁCH LÀM (trên máy admin)
1. Bấm nút Cập nhật trên thanh công cụ.
2. Bấm "Chọn file .zip…" (hoặc "Chọn thư mục…") và chọn gói mới.
3. Admin hiện bản đang cài, bản trong gói và danh sách file sẽ thay. Bấm Có để tiếp tục.
4. Admin tự vá chính nó. Xong, bấm Có để khởi động lại admin (hoặc để sau).
5. Máy học sinh tự hiện hộp "Có bản cập nhật mới" ở góc phải dưới màn hình, có nút "Cập nhật ngay" và "Để sau". Học sinh bấm "Cập nhật ngay": máy tải, cài, tự mở lại ứng dụng trong vài giây. Bấm "Để sau" thì 10 phút sau hộp hiện lại.
(Hộp này chờ tới khi máy hết khóa / hết chiếu mới hiện.)

CẬP NHẬT QUA INTERNET (máy admin có mạng)
Link máy chủ cập nhật đã được cài sẵn trong phần mềm, admin KHÔNG phải dán link.
1. Bấm nút Cập nhật, rồi bấm "Cập nhật từ Internet".
2. Admin tải gói mới nhất, hiện bản đang cài / bản mới / danh sách file thay. Bấm Có để cài.
3. Các bước sau (vá admin, mở lại, máy học sinh bấm "Cập nhật ngay") giống cập nhật bằng file.
Nếu không có mạng hoặc máy chủ lỗi: dùng "Chọn file .zip…" như cũ.

THEO DÕI
Hộp thoại Cập nhật liệt kê từng máy: ✔ Mới nhất / Chờ học sinh bấm / Bản cũ. Nút "Nhắc lại các máy chưa cập nhật" gửi lại thông báo.

AN TOÀN
- Không đụng tới config.json (mã lớp, phòng máy…), thư mục BaiLam, ThuBai.
- Trước khi ghi, admin kiểm tra lỗi cú pháp; sau khi ghi, chạy thử nạp chương trình. Lỗi thì TỰ QUAY VỀ bản cũ, không hỏng máy.
- Mỗi lần cập nhật đều sao lưu (giữ 3 bản gần nhất) trong thư mục backup. Nút "Khôi phục bản trước" đưa admin về bản trước; các máy user sẽ được báo để theo.
- Gói chỉ cần chứa các file thay đổi (vd. chỉ client.py) cũng được: file nào không có trong gói thì giữ nguyên.
- Nếu gói đổi requirements.txt thì máy cần có Internet để cài thư viện mới.

LƯU Ý
- Admin là chuẩn: máy user nào khác bản của admin sẽ được mời cập nhật theo.
- Máy user mà trong hộp thoại hiện "Bản cũ" là máy đang chạy bản chưa có chức năng này: cài lại bằng CAI-USER MỘT LẦN, từ lần sau cập nhật bằng nút Cập nhật.
- Admin khởi động lại thì các máy user nối lại sau vài giây; máy đang khóa / đang chiếu sẽ tự mở.
"""),

("13. Menu chuột phải & phím tắt", """MENU CHUỘT PHẢI VÀ PHÍM TẮT

CHUỘT PHẢI VÀO Ô MÁY
Chọn máy đó rồi mở menu nhanh: Xem màn hình máy này, Quản lý máy này, Chiếu máy này cho cả lớp, Khóa, Mở khóa, Tắt tiếng, Mở tiếng, Tắt máy, Khởi động lại máy, Gửi file, Thu bài, Gửi link, Gửi thông báo.

PHÍM TẮT
F1                  Mở hướng dẫn này
F11                 Admin toàn màn hình (Esc để thoát)
Ctrl+A              Chọn tất cả máy
Ctrl/Shift + bấm    Chọn thêm / bỏ chọn một máy
Nhấp đúp ô máy      Xem màn hình máy đó cỡ lớn
Cuộn chuột          Cuộn lưới khi nhiều máy

TRONG CỬA SỔ XEM 1 MÁY
F11 hoặc nhấp đúp   Toàn màn hình
Esc                 Thoát toàn màn hình
"""),

("14. Tường lửa / phần mềm diệt virus", """TƯỜNG LỬA VÀ PHẦN MỀM DIỆT VIRUS (ESET, Kaspersky, Bitdefender, Norton, McAfee, Avast, AVG, BKAV, Windows Defender...)

VÌ SAO BỊ CHẶN
Trình cài đặt chỉ mở cổng trong Windows Firewall (lệnh netsh). Nhiều phần mềm diệt virus có tường lửa riêng (có khi tự tắt Windows Firewall), không đọc luật của Windows, nên phải cho phép trong chính phần mềm đó. Tên menu mỗi hãng một khác, nhưng nguyên tắc giống nhau như dưới đây.

BƯỚC 1 - XÁC ĐỊNH CÓ PHẢI DO TƯỜNG LỬA
Trên 1 máy học sinh, tạm tắt tường lửa của phần mềm diệt virus khoảng 1 phút để thử (xong bật lại ngay). Máy hiện lên lưới admin = nguyên nhân là tường lửa, làm tiếp bước 2. Vẫn không hiện = xem mục 14 (có thể do mạng).
Hoặc kiểm tra cổng từ máy admin (PowerShell):
  Test-NetConnection -ComputerName IP_MAY_HOC_SINH -Port 5003
Kết quả TcpTestSucceeded : True là cổng đã thông.

CẦN CHO PHÉP NHỮNG GÌ
- Máy USER: TCP 5003, chiều VÀO (admin quét rồi nối ra máy user).
- Máy ADMIN: TCP 5000, chiều VÀO (máy user nối vào admin).
- Máy USER: UDP 5001, chiều VÀO (tự tìm admin, không bắt buộc).
Chỉ cần thông MỘT trong hai chiều là chạy được:
- Chỉ admin có phần mềm chặn: máy user mở TCP 5003 là đủ (kết nối đi ra từ admin thường không bị chặn).
- Cả hai đều có: mở TCP 5003 trên các máy user (hoặc TCP 5000 trên admin). Không mở được UDP 5001 thì chạy máy user với --server IP_ADMIN.

BƯỚC 2 - CÁCH GIẢI QUYẾT CHUNG (làm theo thứ tự, cách nào chạy thì dừng)
A. Cho phép THEO ỨNG DỤNG (nên làm trước, hiệu quả nhất): thêm python.exe và pythonw.exe trong thư mục %LOCALAPPDATA%\\LabManager vào danh sách ứng dụng được phép (Allowed apps / Application rules / Program control), cho cả chiều vào và ra.
B. Cho phép THEO CỔNG: tạo luật mới (Rule / Packet rule / Traffic rule): Direction = In (vào), Action = Allow (cho phép), Protocol = TCP, Local port = 5003 (trên admin: 5000). Thêm 1 luật UDP 5001 nếu muốn tự tìm admin. Nên giới hạn Remote là dải mạng phòng máy, ví dụ 192.168.123.0/24.
C. Đặt mạng phòng máy là mạng TIN CẬY: chuyển loại mạng sang Private / Home / Trusted, hoặc thêm dải IP phòng máy vào Trusted zone / Trusted network / Exclusions. Cách này gọn nhất khi cả phòng dùng chung dải IP.
D. THÊM NGOẠI LỆ CHO THƯ MỤC CÀI: nhiều phần mềm diệt virus coi chức năng khóa bàn phím/chuột, điều khiển từ xa, chụp màn hình là đáng ngờ nên chặn hoặc xóa file. Thêm thư mục %LOCALAPPDATA%\\LabManager (Windows) hoặc ~/.local/share/labmanager (Linux) vào Exclusions / Exceptions / Whitelist của phần mềm diệt virus.
E. ĐỔI CỔNG: nếu mạng chỉ cho một số cổng nhất định, đổi "port" và "agent_port" trong config.json sang cổng được phép (giống nhau ở admin và user).

MỘT SỐ TÊN MENU HAY GẶP (có thể khác theo phiên bản)
- ESET: F5 > Network protection > Firewall > Rules.
- Kaspersky: Settings > Protection > Firewall > Configure application rules / packet rules.
- Bitdefender: Protection > Firewall > Settings > Rules.
- Norton: Settings > Firewall > Traffic Rules / Program Control.
- Avast, AVG: Protection > Firewall > Application settings / Packet rules.
- BKAV, McAfee, các hãng khác: tìm mục Firewall / Tường lửa > Rules / Luật, hoặc Exclusions / Ngoại lệ.

NẾU NHIỀU MÁY (phòng máy trường học, công ty)
Phần mềm thường do IT quản lý tập trung (ví dụ ESET PROTECT) nên các mục trên bị khóa. Nhờ người quản trị thêm luật hoặc ngoại lệ một lần bằng policy cho cả nhóm máy, nhanh hơn nhiều so với đi từng máy. Đưa cho họ danh sách cổng ở trên.

NẾU VẪN KHÔNG ĐƯỢC
- Mạng Wi-Fi có bật "AP isolation / Client isolation" (cách ly thiết bị) hoặc chia VLAN khác nhau sẽ chặn dù đã mở tường lửa. Dùng cáp mạng cùng switch hoặc nhờ IT tắt tính năng này.
- Máy admin và học sinh khác dải IP: thêm dải đó vào "scan" trong config.json của admin.

LUẬT WINDOWS FIREWALL LÀM TAY (nếu cần)
netsh advfirewall firewall add rule name=LabManager dir=in action=allow protocol=TCP localport=5003
"""),

("15. Không thấy máy học sinh", """KHÔNG THẤY MÁY HỌC SINH TRÊN LƯỚI

Kiểm tra lần lượt:
1. Máy học sinh đã bật và đang chạy LabManager User chưa? (Windows: tác vụ tự chạy lại trong tối đa 1 phút.)
2. Admin và máy học sinh cùng một mạng LAN (cùng dải IP)? Mạng khác /24: thêm "scan" vào config.json của admin.
3. Cùng một bản gói? config.json phải có cùng "secret" (mã lớp) trên mọi máy.
4. Tường lửa: Windows Firewall do trình cài mở sẵn. Nếu máy có ESET hoặc phần mềm khác, xem mục 13.
5. Thử nối tay: trên máy học sinh chạy  python client.py --server IP_ADMIN
6. Linux: phải dùng phiên X11 (Ubuntu on Xorg), Wayland chặn chụp màn hình.
7. Đã đủ số máy tối đa ("max_clients" trong config.json, mặc định 50)? Tăng số này nếu cần.
8. Chạy lại CAI-USER bằng gói mới nếu máy học sinh đang dùng bản cũ.

TẮT ADMIN RỒI MỞ LẠI THÌ MẤT MÁY HỌC SINH
- Bản cũ (trước v17) khi đóng cửa sổ admin vẫn còn tiến trình chạy ngầm, giữ kết nối với máy học sinh nên admin mở lại không nối được (hoặc báo "không mở được cổng 5000"). Cách xử lý một lần: mở Task Manager, tắt hết python.exe / pythonw.exe của LabManager (hoặc khởi động lại máy admin), rồi mở lại admin. Bản mới đã thoát hẳn khi đóng cửa sổ.
- Admin bị tắt đột ngột (mất điện, treo máy): máy học sinh nhường cho admin mới sau khoảng 15 giây, không cần làm gì.
- Máy admin có nhiều card mạng (VPN, máy ảo...) hoặc LAN không ra Internet: bản mới quét dải /24 của mọi card mạng. Vẫn không thấy thì khai "scan" trong config.json của admin.

KHÔNG HIỆN TÊN TÀI KHOẢN
Máy học sinh đang chạy bản cũ. Chạy lại CAI-USER bằng gói mới.

CÔNG CỤ CHẨN ĐOÁN (nên chạy trước khi hỏi hỗ trợ)
- Máy ADMIN: bấm đúp CHAN-DOAN.bat (Linux: ./chan-doan.sh). Công cụ quét mạng, thử bắt tay với từng máy học sinh và cho biết: máy nào trả lời, máy nào SAI mã lớp, và gợi ý nguyên nhân.
- Máy USER: chạy  CHAN-DOAN.bat --admin IP_ADMIN  để thử nối tới admin (kiểm tra tường lửa trên máy admin).
- Báo cáo lưu trong file chan-doan.txt, gửi file này để được hỗ trợ.

LỖI KHI CÀI TRÊN WINDOWS
- "Python thiếu tkinter": cài Python từ python.org và GIỮ dấu tick "tcl/tk and IDLE".
- "Smart App Control blocked a file": chuột phải file zip > Properties > tick Unblock trước khi giải nén; hoặc chạy trong thư mục lab:  Get-ChildItem -Recurse | Unblock-File
"""),

("16. Cấu hình (config.json)", """CẤU HÌNH config.json

Mỗi máy có file config.json riêng trong thư mục cài. Sửa xong chạy lại ứng dụng.

DÙNG CHUNG
- secret: mã lớp. PHẢI giống nhau trên mọi máy.
- port (5000), discovery_port (5001), agent_port (5003): cổng mạng. Đổi thì đổi giống nhau ở admin và user.

MÁY ADMIN
- max_clients: số máy tối đa (mặc định 50).
- fps, width, quality: tốc độ và chất lượng khi xem màn hình lớn (mặc định 3 khung/giây, 1024px, 50). Mạng yếu thì giảm.
- present_width: độ rộng ảnh khi chiếu (mặc định 1280).
- watch_words: từ khóa bị tô đỏ (youtube, game, facebook...).
- scan: danh sách dải mạng quét, ví dụ ["192.168.123.0/24"]. scan_interval: giây giữa 2 lần quét (mặc định 5).
- collect_dir: nơi lưu bài thu (mặc định ~/ThuBai). submit_file_max_mb: giới hạn mỗi file nộp.

MÁY USER
- server: "auto" (tự tìm admin) hoặc IP của admin.
- present_fit: true để chiếu giữ đúng tỉ lệ (có viền đen).
- submit_max_mb, submit_file_max_mb, submit_dirs: giới hạn và thư mục khi Thu bài.
- save_dir: thư mục mặc định khi nhận file (mặc định Desktop).
- install_block: true (mặc định) = máy này tuân theo Chặn cài đặt của admin; false = tắt hẳn chặn cài đặt trên máy này (dùng khi cần cài phần mềm).

GỠ CÀI ĐẶT
Làm trên từng máy: GO-CAI-DAT.bat (Windows) hoặc ./go-cai-dat.sh (Linux), hoặc nút "Gỡ cài đặt" trong trình cài đặt. Thư mục bài đã thu (BaiLam, ~/ThuBai) không bị xóa.
"""),
("QUẢN LÝ PHÒNG", """QUẢN LÝ PHÒNG

Bấm nút \"Quản lý phòng\" trên thanh công cụ để xem, thêm, sửa, xóa phòng máy ngay trong admin (không cần sửa config.json).

- Mỗi phòng có tên và 1 mã lớp riêng. Máy học sinh dùng mã lớp nào thì vào phòng đó.
- Thêm...: nhập tên phòng và mã lớp (từ 3 ký tự). Tên và mã không được trùng phòng khác.
- Sửa... (hoặc nhấp đúp vào dòng): đổi tên phòng hoặc mã lớp.
- Xóa phòng (hoặc phím Delete): bỏ phòng khỏi danh sách. Các máy đang nối của phòng đó sẽ bị ngắt và không nối lại được nếu không đổi mã trên máy đó. Luôn phải còn ít nhất 1 phòng.
- Phòng đầu tiên là phòng chính. Xóa phòng chính thì phòng kế tiếp thành phòng chính.
- Thay đổi có hiệu lực ngay và được lưu vào config.json; ô \"Phòng:\" ở góc dưới bên phải chỉ hiện khi có từ 2 phòng trở lên.
"""),
]
