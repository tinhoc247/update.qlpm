"""MỞ KHÓA PHẦN MỀM bằng mã (máy ADMIN).

- Mã do người phát hành tạo bằng công cụ riêng (taoma.py), KHÔNG nằm trong ứng dụng. Mỗi mã là 1 chữ ký số Ed25519 trên
  (loại thời hạn + số ngẫu nhiên). Ứng dụng chỉ chứa KHÓA CÔNG KHAI nên chỉ KIỂM TRA được mã, không thể sinh mã hay suy ra mã.
- 3 loại: 1 tuần (7 ngày), 1 tháng (30 ngày), 1 năm (365 ngày). Thời hạn bắt đầu tính từ lúc NHẬP mã (mở khóa).
- Mỗi mã chỉ dùng được ĐÚNG 1 LẦN (trên mọi máy): lúc kích hoạt, ứng dụng "đăng ký" mã vào sổ trung tâm (Firestore, xem REGISTRY_PROJECT).
  Đã đăng ký rồi thì mã không dùng lại được nữa, kể cả trên máy khác hoặc sau khi xóa unlock.dat / cài lại máy. Kích hoạt cần có Internet;
  sau khi kích hoạt xong thì chạy offline bình thường. Nhập thêm mã khi còn hạn thì cộng nối tiếp vào sau ngày hết hạn hiện tại.
- Trạng thái lưu ở 2 nơi (có chữ ký HMAC để phát hiện sửa tay) + ghi nhận thời điểm đã thấy gần nhất để phát hiện chỉnh lùi đồng hồ.
"""
import base64, hashlib, hmac, json, os, platform, re, time, urllib.error, urllib.request, uuid

PUBKEY = bytes.fromhex("d7fbae4c99ce0df5afb5cd6f969a6303c155c56fc7483ea7248f3153a50cc44d")
TYPES = {1: 7, 2: 30, 3: 365}                         # loại mã -> số ngày
DOMAIN = b"LABMGR-UNLOCK-v1"                          # tách miền chữ ký (không dùng chữ ký này cho việc khác)
HERE = os.path.dirname(os.path.abspath(__file__))
STORES = [os.path.join(HERE, "unlock.dat"), os.path.join(os.path.expanduser("~"), ".labmanager_unlock")]
_MACKEY = hashlib.sha256(b"labmanager-unlock-state-v1").digest()
SLACK = 300                                           # dung sai đồng hồ (giây)
# Sổ trung tâm các mã đã dùng (Firestore REST, không cần thư viện/khóa API – quyền do firestore.rules quyết định, xem firestore.rules).
# Điền ID dự án Firebase vào đây. Để trống = chỉ chống dùng lại trên từng máy (kiểu cũ, KHÔNG chặn dùng 1 mã cho nhiều máy).
REGISTRY_PROJECT = "code-qlpm"
REGISTRY_COLLECTION = "used_codes"
REGISTRY_TIMEOUT = 12                                 # giây
CODE_BYTES = 9 + 64                                   # 1 byte loại + 8 byte ngẫu nhiên + 64 byte chữ ký


# ---------- Ed25519 (RFC 8032, thuần Python, không cần thư viện ngoài) ----------
_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _inv(x): return pow(x, _P - 2, _P)


def _recover_x(y, sign):
    if y >= _P: return None
    x2 = (y * y - 1) * _inv(_D * y * y + 1) % _P
    if x2 == 0: return None if sign else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P: x = x * _I % _P
    if (x * x - x2) % _P: return None
    if (x & 1) != sign: x = _P - x
    return x


_GY = 4 * _inv(5) % _P
_GX = _recover_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)


def _add(a, b):
    A = (a[1] - a[0]) * (b[1] - b[0]) % _P; B = (a[1] + a[0]) * (b[1] + b[0]) % _P
    C = 2 * a[3] * b[3] * _D % _P; D = 2 * a[2] * b[2] % _P
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _P, G * H % _P, F * G % _P, E * H % _P)


def _mul(s, pt):
    r = (0, 1, 1, 0)
    while s > 0:
        if s & 1: r = _add(r, pt)
        pt = _add(pt, pt); s >>= 1
    return r


def _eq(a, b):
    return (a[0] * b[2] - b[0] * a[2]) % _P == 0 and (a[1] * b[2] - b[1] * a[2]) % _P == 0


def _comp(pt):
    zi = _inv(pt[2]); x = pt[0] * zi % _P; y = pt[1] * zi % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decomp(s):
    y = int.from_bytes(s, "little"); sign = y >> 255; y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _P)


def ed_verify(pub, msg, sig):
    """True nếu chữ ký `sig` (64 byte) trên `msg` đúng với khóa công khai `pub` (32 byte)."""
    try:
        if len(pub) != 32 or len(sig) != 64: return False
        A, R = _decomp(pub), _decomp(sig[:32])
        if A is None or R is None: return False
        s = int.from_bytes(sig[32:], "little")
        if s >= _Q: return False
        h = int.from_bytes(hashlib.sha512(sig[:32] + pub + msg).digest(), "little") % _Q
        return _eq(_mul(s, _G), _add(R, _mul(h, A)))
    except Exception:
        return False


# ---------------- trạng thái lưu trên máy ----------------
def _pack(st):
    d = json.dumps(st, sort_keys=True, separators=(",", ":"))
    return json.dumps({"d": d, "m": hmac.new(_MACKEY, d.encode(), hashlib.sha256).hexdigest()})


def _unpack(raw):
    try:
        o = json.loads(raw)
        if not hmac.compare_digest(hmac.new(_MACKEY, o["d"].encode(), hashlib.sha256).hexdigest(), o["m"]): return None
        st = json.loads(o["d"])
        return st if isinstance(st, dict) and isinstance(st.get("used"), list) else None
    except Exception:
        return None


def _load():
    """Đọc cả 2 nơi lưu, chỉ nhận bản có chữ ký đúng; nhiều bản thì lấy bản mới nhất (seen lớn nhất), gộp danh sách mã đã dùng."""
    cands = []
    for p in STORES:
        try:
            with open(p, encoding="utf-8") as f: st = _unpack(f.read())
            if st: cands.append(st)
        except Exception: pass
    if not cands: return None
    best = dict(max(cands, key=lambda s: float(s.get("seen", 0))))
    best["used"] = sorted({u for s in cands for u in s.get("used", [])})
    return best


def _save(st):
    ok = False
    for p in STORES:
        try:
            tmp = p + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f: f.write(_pack(st))
            os.replace(tmp, p); ok = True
        except Exception: pass
    if not ok: raise OSError("Không ghi được dữ liệu mở khóa (kiểm tra quyền ghi thư mục cài đặt).")


def status(now=None):
    """{'state': 'ok'|'none'|'expired'|'clock', 'exp': <timestamp>, 'left': <giây còn lại>}"""
    now = time.time() if now is None else now
    st = _load()
    if not st or not st.get("exp"): return {"state": "none"}
    if now < float(st.get("seen", 0)) - SLACK: return {"state": "clock", "exp": st["exp"]}      # đồng hồ bị chỉnh lùi
    if now > float(st.get("seen", 0)) + 60:
        st["seen"] = now
        try: _save(st)
        except Exception: pass
    left = st["exp"] - now
    return {"state": "ok", "exp": st["exp"], "left": left} if left > 0 else {"state": "expired", "exp": st["exp"]}


def left_text(left, lang="vi"):
    d, h = int(left // 86400), int(left % 86400 // 3600)
    if lang == "en": return f"{d}d {h}h" if d else (f"{h}h {int(left % 3600 // 60)}m" if h else f"{max(1, int(left // 60))}m")
    return f"{d} ngày {h} giờ" if d else (f"{h} giờ {int(left % 3600 // 60)} phút" if h else f"{max(1, int(left // 60))} phút")


def date_text(ts):
    return time.strftime("%d/%m/%Y %H:%M", time.localtime(ts))


def check_code(code):
    """Kiểm tra chữ ký của mã. Trả về (số ngày, nonce_hex) hoặc None nếu mã sai."""
    s = re.sub(r"[^A-Za-z2-7]", "", code or "").upper()
    try: raw = base64.b32decode(s + "=" * (-len(s) % 8))
    except Exception: return None
    if len(raw) != CODE_BYTES: return None
    payload, sig = raw[:9], raw[9:]
    if payload[0] not in TYPES or not ed_verify(PUBKEY, DOMAIN + payload, sig): return None
    return TYPES[payload[0]], payload[1:].hex()


def _machine_id():
    """Mã máy (băm một chiều) chỉ để người phát hành tra cứu mã đã dùng ở máy nào."""
    return hashlib.sha256(f"{uuid.getnode()}|{platform.node()}".encode()).hexdigest()[:16]


def claim_online(nonce, days, now):
    """Đăng ký mã vào sổ trung tâm. Trả về ('ok'|'used'|'error', thông báo). Firestore createDocument là thao tác nguyên tử:
    tài liệu đã tồn tại thì trả 409 -> mã đã bị dùng, nên 2 máy nhập cùng lúc cũng chỉ 1 máy thắng."""
    url = (f"https://firestore.googleapis.com/v1/projects/{REGISTRY_PROJECT}/databases/(default)/documents/"
           f"{REGISTRY_COLLECTION}?documentId={nonce}")
    body = json.dumps({"fields": {"days": {"integerValue": str(days)}, "machine": {"stringValue": _machine_id()},
                                  "at": {"timestampValue": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now))}}}).encode()
    req = urllib.request.Request(url, data=body, method="POST", headers={"Content-Type": "application/json", "User-Agent": "QuanLyPhongMay-Unlock"})
    try:
        with urllib.request.urlopen(req, timeout=REGISTRY_TIMEOUT): return "ok", ""
    except urllib.error.HTTPError as e:
        if e.code == 409: return "used", ""
        if e.code in (401, 403): return "error", "Máy chủ từ chối đăng ký mã (chưa cấu hình đúng firestore.rules). Hãy báo nhà phát hành."
        return "error", f"Máy chủ kích hoạt báo lỗi {e.code}. Thử lại sau ít phút."
    except Exception:
        return "error", "Không kết nối được máy chủ kích hoạt. Hãy kiểm tra Internet rồi nhập lại mã (mã chưa bị mất)."


def activate(code, now=None):
    """Nhập mã. Trả về (ok, thông báo)."""
    now = time.time() if now is None else now
    got = check_code(code)
    if not got: return False, "Mã không hợp lệ. Hãy kiểm tra lại (dán nguyên mã, không thiếu ký tự)."
    days, nonce = got
    st = _load() or {"used": [], "exp": 0, "first": now, "seen": now}
    if now < float(st.get("seen", 0)) - SLACK: return False, "Đồng hồ máy đang chạy lùi so với lần dùng trước. Hãy chỉnh lại đúng ngày giờ rồi nhập lại mã."
    if nonce in st["used"]: return False, "Mã này đã được sử dụng rồi."
    if REGISTRY_PROJECT:                                   # đăng ký trên sổ trung tâm TRƯỚC khi cộng thời hạn: đã ai dùng thì dừng
        r, why = claim_online(nonce, days, now)
        if r == "used": return False, "Mã này đã được sử dụng rồi (mỗi mã chỉ kích hoạt được 1 lần)."
        if r != "ok": return False, why
    base = max(now, float(st.get("exp", 0)))              # còn hạn thì cộng nối tiếp, hết hạn thì tính từ bây giờ
    st["exp"] = base + days * 86400; st["used"].append(nonce); st["seen"] = max(now, float(st.get("seen", 0)))
    try: _save(st)
    except OSError as e: return False, str(e) + (" Mã đã bị đăng ký, hãy báo nhà phát hành để cấp lại." if REGISTRY_PROJECT else "")
    return True, f"Đã mở khóa +{days} ngày. Hết hạn lúc {date_text(st['exp'])}."


# ---------------- hộp thoại nhập mã ----------------
_EN = {"Mã không hợp lệ. Hãy kiểm tra lại (dán nguyên mã, không thiếu ký tự).": "Invalid code. Please check it (paste the whole code, no missing characters).",
       "Mã này đã được sử dụng rồi.": "This code has already been used.",
       "Mã này đã được sử dụng rồi (mỗi mã chỉ kích hoạt được 1 lần).": "This code has already been used (each code can be activated only once).",
       "Đồng hồ máy đang chạy lùi so với lần dùng trước. Hãy chỉnh lại đúng ngày giờ rồi nhập lại mã.": "The system clock is behind its last known time. Fix the date and time, then enter the code again.",
       "Không kết nối được máy chủ kích hoạt. Hãy kiểm tra Internet rồi nhập lại mã (mã chưa bị mất).": "Cannot reach the activation server. Check your Internet and enter the code again (the code is not lost)."}


def _en(t):
    """Dịch thông báo kích hoạt sang tiếng Anh (câu lạ giữ nguyên)."""
    import re as _re
    m = _re.match(r"Đã mở khóa \+(\d+) ngày\. Hết hạn lúc (.+)\.$", t)
    if m: return f"Unlocked +{m.group(1)} days. Expires {m.group(2)}."
    m = _re.match(r"Máy chủ kích hoạt báo lỗi (\d+)\. Thử lại sau ít phút\.$", t)
    if m: return f"Activation server error {m.group(1)}. Try again in a few minutes."
    return _EN.get(t, t)

def dialog(parent, font, reason="", close_text=None, lang="vi"):
    """Hộp thoại modal nhập mã. Trả về True nếu sau khi đóng phần mềm đang được mở khóa."""
    import tkinter as tk
    from tkinter import messagebox
    try:
        from theme import BG, CARD, TEXT, MUTED
    except Exception:
        BG, CARD, TEXT, MUTED = "#f1f5f9", "#ffffff", "#0f172a", "#64748b"
    en = lang == "en"
    T = (lambda vi, e: e if en else vi)
    close_text = close_text or T("Đóng", "Close")
    d = tk.Toplevel(parent); d.title(T("Nhập mã", "Enter code")); d.configure(bg=BG); d.geometry("640x470"); d.resizable(False, False)
    try:
        from common import set_window_icon
        set_window_icon(d, "admin")
    except Exception: pass
    if parent.winfo_viewable(): d.transient(parent)
    tk.Label(d, text=T("Mở khóa phần mềm", "Unlock software"), bg=BG, fg=TEXT, font=(font, 16, "bold")).pack(anchor="w", padx=20, pady=(16, 2))
    if reason: tk.Label(d, text=reason, bg=BG, fg="#b91c1c", font=(font, 11, "bold"), justify="left", wraplength=600).pack(anchor="w", padx=20, pady=(0, 4))
    info = tk.StringVar(); tk.Label(d, textvariable=info, bg=BG, fg=TEXT, font=(font, 11), justify="left", wraplength=600).pack(anchor="w", padx=20)
    tk.Label(d, text=T("Nhập (hoặc dán) mã mở khóa do nhà phát hành cấp:", "Enter (or paste) the unlock code from the publisher:"), bg=BG, fg=MUTED, font=(font, 10)).pack(anchor="w", padx=20, pady=(12, 3))
    tx = tk.Text(d, height=6, width=64, wrap="char", font=("Consolas" if os.name == "nt" else "monospace", 10), bd=1, relief="solid", bg=CARD, fg=TEXT)
    tx.pack(padx=20, fill="x")
    msg = tk.StringVar(); lbl = tk.Label(d, textvariable=msg, bg=BG, fg="#b91c1c", font=(font, 10, "bold"), justify="left", wraplength=600); lbl.pack(anchor="w", padx=20, pady=(8, 0))
    tk.Label(d, text=T("Mã chỉ kích hoạt được 1 lần duy nhất (cần có Internet lúc nhập mã). Thời hạn tính từ lúc nhập mã: 1 tuần (7 ngày) • 1 tháng (30 ngày) • 1 năm (365 ngày).", "Each code can be activated only once (Internet required when entering it). Validity starts when entered: 1 week (7 days) • 1 month (30 days) • 1 year (365 days)."), bg=BG, fg=MUTED, font=(font, 9), wraplength=600, justify="left").pack(anchor="w", padx=20, pady=(2, 0))
    st = {"fails": 0, "until": 0.0}

    def show_status():
        s = status()
        if reason and s["state"] != "ok": return info.set("")        # lý do đã nói rõ ở trên, khỏi lặp lại
        if s["state"] == "ok": info.set(f"Unlocked • {left_text(s['left'], 'en')} left (expires {date_text(s['exp'])}). Enter another code to extend." if en else f"Đang mở khóa • còn {left_text(s['left'])} (hết hạn {date_text(s['exp'])}). Nhập thêm mã để cộng nối tiếp.")
        elif s["state"] == "expired": info.set(f"Expired on {date_text(s['exp'])}." if en else f"Đã hết hạn từ {date_text(s['exp'])}.")
        elif s["state"] == "clock": info.set(T("Đồng hồ máy bị chỉnh lùi – hãy chỉnh lại đúng ngày giờ.", "System clock was set back – please fix the date and time."))
        else: info.set(T("Phần mềm chưa được mở khóa.", "The software is not unlocked."))
    show_status()

    def paste():
        try: tx.delete("1.0", "end"); tx.insert("1.0", d.clipboard_get().strip())
        except Exception: msg.set(T("Clipboard đang trống.", "Clipboard is empty."))

    def go():
        if time.time() < st["until"]: lbl.configure(fg="#b91c1c"); return msg.set(f"Too many wrong attempts – wait {int(st['until'] - time.time()) + 1} s and try again." if en else f"Nhập sai nhiều lần – chờ {int(st['until'] - time.time()) + 1} giây rồi thử lại.")
        ok, text = activate(tx.get("1.0", "end"))
        if en: text = _en(text)
        show_status()
        if ok:
            tx.delete("1.0", "end"); messagebox.showinfo(T("Mở khóa", "Unlock"), text, parent=d); d.destroy(); return
        st["fails"] += 1
        if st["fails"] % 5 == 0: st["until"] = time.time() + 30
        lbl.configure(fg="#b91c1c"); msg.set(text)

    row = tk.Frame(d, bg=BG); row.pack(fill="x", padx=20, pady=12)
    tk.Button(row, text=T("Mở khóa", "Unlock"), command=go, bg="#16a34a", fg="white", font=(font, 11, "bold"), padx=18, pady=3).pack(side="left")
    tk.Button(row, text=T("Dán từ clipboard", "Paste from clipboard"), command=paste, font=(font, 10), padx=8).pack(side="left", padx=8)
    tk.Button(row, text=close_text, command=d.destroy, font=(font, 10), padx=12).pack(side="right")
    m = tk.Menu(tx, tearoff=0); m.add_command(label=T("Dán", "Paste"), command=paste)
    tx.bind("<Button-3>", lambda e: m.tk_popup(e.x_root, e.y_root)); tx.bind("<Control-Return>", lambda e: (go(), "break")[1])
    d.bind("<Escape>", lambda e: d.destroy()); d.update_idletasks()
    try: d.grab_set()
    except Exception: pass
    tx.focus_set(); parent.wait_window(d)
    return status()["state"] == "ok"
