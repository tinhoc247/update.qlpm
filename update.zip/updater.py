"""Cập nhật / vá lỗi tại chỗ – KHÔNG cần cài lại.

- Admin chọn gói mới (.zip hoặc thư mục) -> vá thẳng vào thư mục cài đặt của admin (có sao lưu, lỗi thì tự hoàn tác).
- Admin giữ "ảnh chụp" (snapshot) các file chương trình đang cài; máy user có bản khác sẽ được báo và tự bấm cập nhật.
- Không đụng tới config.json (mã lớp, danh sách phòng…), venv, thư mục BaiLam / ThuBai.
Chạy:  python updater.py --relaunch <script> <pid>   (nội bộ: chờ tiến trình cũ thoát rồi mở lại ứng dụng)"""
import hashlib, io, json, os, re, shutil, subprocess, sys, time, urllib.error, urllib.request, zipfile

for _st in (sys.stdout, sys.stderr):      # pythonw / chạy nền trên Windows: stdout mặc định cp1252 -> print tiếng Việt báo lỗi "charmap"
    try: _st.reconfigure(encoding="utf-8", errors="replace")
    except Exception: pass

HERE = os.path.dirname(os.path.abspath(__file__))
WIN = os.name == "nt"
NOWIN = 0x08000000 if WIN else 0

EXTS = (".py", ".png", ".ico", ".md", ".txt")            # loại file được cập nhật (chỉ file nằm ngay trong thư mục chương trình)
SKIP = {"setup.py", "config.json"}                        # không bao giờ ghi đè (config chứa mã lớp / phòng máy của từng máy)
REQUIRED = ("common.py", "server.py", "theme.py", "helptext.py", "admin.py", "client.py", "updater.py", "webblock.py")        # máy ADMIN cần đủ
USER_FILES = ("common.py", "theme.py", "updater.py", "webblock.py", "client.py", "chan-doan.py", "version.txt", "requirements.txt", "README.md",
              "icon-user.ico", "icon-user.png", "shortcut-user.ico", "shortcut-user.png")                          # bộ file của máy USER (thư mục user/)
REQUIRED_USER = ("common.py", "theme.py", "updater.py", "webblock.py", "client.py")
SMOKE = {"admin": ["common", "server", "theme", "helptext", "updater", "webblock", "admin"], "user": ["common", "theme", "updater", "webblock", "client"]}
MAX_FILE, MAX_TOTAL, KEEP_BACKUPS = 20 << 20, 40 << 20, 3
BAD_PARTS = ("venv", "site-packages", "__pycache__", "__macosx", "backup", ".git", "node_modules")


# ---------------- đọc file / phiên bản / mã bản dựng ----------------
def is_update_file(name):
    return (bool(name) and name == os.path.basename(name) and "/" not in name and "\\" not in name and not name.startswith(".")
            and name not in SKIP and name.lower().endswith(EXTS))


def local_files(d=None):
    d = d or HERE
    out = {}
    try:
        for n in sorted(os.listdir(d)):
            p = os.path.join(d, n)
            if is_update_file(n) and os.path.isfile(p):
                with open(p, "rb") as f: out[n] = f.read()
    except OSError:
        pass
    return out


def _ver_of(files):
    v = files.get("version.txt")
    return (v.decode("utf-8", "replace").strip().splitlines() or ["?"])[0][:20] if v else "?"


def version(d=None):
    return _ver_of(local_files(d))


def build_id(files):
    """Mã nhận dạng bản dựng: băm toàn bộ mã nguồn (.py), requirements.txt, version.txt. Đổi 1 dòng code là mã đổi."""
    h = hashlib.sha256()
    for n in sorted(files):
        if n in USER_FILES and (n.endswith(".py") or n in ("requirements.txt", "version.txt")):      # chỉ băm bộ file chung admin/user (admin.py, server.py… không tính)
            h.update(n.encode() + b"\0" + files[n] + b"\0")
    return h.hexdigest()[:8]


def _say(log, msg):
    """Ghi nhật ký an toàn: stdout lỗi mã hóa / bị đóng không được làm cập nhật thất bại."""
    try: log(msg)
    except Exception: pass


def full_id(files):
    """Mã của TOÀN BỘ file chương trình (kể cả admin.py, server.py…) – để biết chương trình đang chạy có cũ hơn file trên đĩa không."""
    h = hashlib.sha256()
    for n in sorted(files):
        if n.endswith(".py") or n in ("requirements.txt", "version.txt"): h.update(n.encode() + b"\0" + files[n] + b"\0")
    return h.hexdigest()[:8]


def stale():
    """True nếu file trên đĩa đã khác bản đang chạy (đã vá xong nhưng chưa mở lại ứng dụng)."""
    try: return full_id(local_files()) != RUN_FULL
    except Exception: return False


def _running():
    try:
        f = local_files()
        return _ver_of(f), build_id(f)
    except Exception:
        return "?", ""


RUN_VER, RUN_BUILD = _running()      # bản ĐANG CHẠY (tính lúc nạp module = lúc khởi động ứng dụng)
try: RUN_FULL = full_id(local_files())
except Exception: RUN_FULL = ""


def snapshot(d=None):
    """Nén toàn bộ file chương trình đang cài thành 1 gói để gửi cho máy user. Trả về (zip_bytes, build, version)."""
    files = {n: b for n, b in local_files(d).items() if n in USER_FILES}        # máy user chỉ nhận bộ file của user
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n, b in files.items(): z.writestr(n, b)
    return buf.getvalue(), build_id(files), _ver_of(files)


# ---------------- đọc gói cập nhật (zip hoặc thư mục) ----------------
def _clean(name):
    return name.replace("\\", "/").lstrip("/")


def _bad_path(path):
    return any(part.lower() in BAD_PARTS for part in path.split("/")[:-1])


def _read_zipfile(z):
    groups = {}
    for i in z.infolist():
        n = _clean(i.filename)
        if i.is_dir() or not n or _bad_path(n): continue
        d, _, base = n.rpartition("/")
        if is_update_file(base) and i.file_size <= MAX_FILE: groups.setdefault(d, []).append((base, i))
    if not groups: raise ValueError("Không tìm thấy file chương trình (.py…) trong gói.")
    d = max(groups, key=lambda k: (len(groups[k]), -k.count("/")))        # thư mục chứa nhiều file chương trình nhất = thư mục gốc của gói
    files, total = {}, 0
    for base, i in groups[d]:
        total += i.file_size
        if total > MAX_TOTAL: raise ValueError("Gói quá lớn.")
        files[base] = z.read(i)
    return files


def read_zip_bytes(data):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z: return _read_zipfile(z)
    except zipfile.BadZipFile:
        raise ValueError("File không phải gói .zip hợp lệ.")


def read_package(path):
    if os.path.isdir(path):
        best, bn = None, -1
        for root, dirs, fs in os.walk(path):
            dirs[:] = [x for x in dirs if x.lower() not in BAD_PARTS]
            if root[len(path):].count(os.sep) > 2: dirs[:] = []; continue
            n = sum(1 for f in fs if is_update_file(f))
            if n > bn: best, bn = root, n
        if not best or bn <= 0: raise ValueError("Không tìm thấy file chương trình (.py…) trong thư mục.")
        files, total = {}, 0
        for n in sorted(os.listdir(best)):
            p = os.path.join(best, n)
            if is_update_file(n) and os.path.isfile(p) and os.path.getsize(p) <= MAX_FILE:
                with open(p, "rb") as f: files[n] = f.read()
                total += len(files[n])
        if total > MAX_TOTAL: raise ValueError("Gói quá lớn.")
        return files
    if not os.path.isfile(path): raise ValueError("Không tìm thấy: " + path)
    try:
        with zipfile.ZipFile(path) as z: return _read_zipfile(z)
    except zipfile.BadZipFile:
        raise ValueError("File không phải gói .zip hợp lệ.")


# ---------------- tải gói cập nhật từ Internet (GitHub / Netlify / host bất kỳ) ----------------
def candidate_urls(url):
    """Chuẩn hóa link người dùng dán vào -> danh sách link tải trực tiếp (thử lần lượt).
    - link file .zip bất kỳ (Netlify, GitHub Pages, GitHub Releases, raw.githubusercontent.com…): dùng nguyên
    - github.com/<user>/<repo>/blob/<nhánh>/<file>.zip -> link raw
    - github.com/<user>/<repo>[/tree/<nhánh>]: tải toàn bộ kho (zip nhánh main, không có thì master)"""
    u = (url or "").strip().strip('"').strip("'")
    if not u: raise ValueError("Chưa nhập link gói cập nhật.")
    if not re.match(r"https?://", u, re.I): u = "https://" + u
    m = re.match(r"https?://(?:www\.)?github\.com/([^/]+)/([^/?#]+?)(?:\.git)?/blob/([^?#]+)", u, re.I)
    if m: return [f"https://raw.githubusercontent.com/{m.group(1)}/{m.group(2)}/{m.group(3)}"]
    m = re.match(r"https?://(?:www\.)?github\.com/([^/]+)/([^/?#]+?)(?:\.git)?(?:/tree/([^?#]+))?/?(?:[?#].*)?$", u, re.I)
    if m:
        br = [m.group(3)] if m.group(3) else ["main", "master"]
        return [f"https://github.com/{m.group(1)}/{m.group(2)}/archive/refs/heads/{b}.zip" for b in br]
    return [u]


def fetch_package(url, timeout=30):
    """Tải gói .zip từ Internet, trả về dict {tên file: nội dung} như read_package(). Ném ValueError (thông báo tiếng Việt) khi lỗi."""
    last = None
    for u in candidate_urls(url):
        if "raw.githubusercontent.com" in u: u += ("&" if "?" in u else "?") + "_=%d" % int(time.time())      # tránh bộ nhớ đệm 5 phút của GitHub
        req = urllib.request.Request(u, headers={"User-Agent": "QuanLyPhongMay-Updater", "Cache-Control": "no-cache", "Pragma": "no-cache"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                buf = io.BytesIO()
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk: break
                    buf.write(chunk)
                    if buf.tell() > MAX_TOTAL: raise ValueError("Gói quá lớn.")
            data = buf.getvalue()
        except urllib.error.HTTPError as e:
            last = ValueError("Không tìm thấy file trên máy chủ (lỗi 404). Kiểm tra lại link." if e.code == 404 else f"Máy chủ trả lỗi {e.code}. Kiểm tra lại link / quyền truy cập (kho GitHub phải để Public).")
            continue
        except (urllib.error.URLError, OSError) as e:
            raise ValueError("Không kết nối được Internet hoặc máy chủ (%s).\nKhông có mạng thì dùng nút \"Chọn file .zip…\"." % (getattr(e, "reason", None) or e))
        if data[:2] != b"PK": last = ValueError("Link này không trả về file .zip (có thể là trang web). Hãy dùng link tải trực tiếp file .zip."); continue
        return read_zip_bytes(data)
    raise last or ValueError("Không tải được gói.")


def check_syntax(files):
    for n, b in files.items():
        if n.endswith(".py"):
            try: compile(b, n, "exec")
            except SyntaxError as e: raise ValueError(f"Lỗi cú pháp trong {n} (dòng {e.lineno}): {e.msg}")
            except (ValueError, UnicodeDecodeError) as e: raise ValueError(f"{n} không đọc được: {e}")


def plan(pkg, d=None, role="admin"):
    """So gói với bản đang cài. Trả về dict: changed (file đổi), added (file mới), ver_old, ver_new. Ném ValueError nếu gói hỏng."""
    cur = local_files(d)
    changed = sorted(n for n, b in pkg.items() if cur.get(n) != b)
    check_syntax({n: pkg[n] for n in changed})
    merged = dict(cur); merged.update(pkg)
    miss = [r for r in (REQUIRED_USER if role == "user" else REQUIRED) if r not in merged]
    if miss: raise ValueError("Gói thiếu file bắt buộc: " + ", ".join(miss))
    return {"changed": changed, "added": [n for n in changed if n not in cur], "ver_old": _ver_of(cur), "ver_new": _ver_of(merged),
            "build_old": build_id(cur), "build_new": build_id(merged)}


# ---------------- áp dụng (có sao lưu, tự hoàn tác khi lỗi) ----------------
def _py_exe():
    py = sys.executable
    if WIN and py.lower().endswith("pythonw.exe"):
        c = os.path.join(os.path.dirname(py), "python.exe")
        if os.path.exists(c): return c
    return py


def _env():
    return dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")


def smoke_test(d, role):
    mods = ", ".join(SMOKE.get(role, SMOKE["user"]))
    r = subprocess.run([_py_exe(), "-c", "import " + mods], cwd=d, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       timeout=90, creationflags=NOWIN, env=_env())
    if r.returncode != 0:
        tail = [x for x in r.stderr.strip().splitlines() if x.strip()]
        raise RuntimeError("Bản mới không chạy được: " + (tail[-1] if tail else "lỗi không rõ"))


def pip_install(d, log):
    _say(log, "requirements.txt đổi – cài thêm thư viện (cần Internet)…")
    r = subprocess.run([_py_exe(), "-m", "pip", "install", "--disable-pip-version-check", "-r", os.path.join(d, "requirements.txt")],
                       cwd=d, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300, creationflags=NOWIN, env=_env())
    if r.returncode != 0:
        tail = [x for x in r.stderr.strip().splitlines() if x.strip()]
        raise RuntimeError("Không cài được thư viện mới (kiểm tra Internet): " + (tail[-1][:120] if tail else ""))


def _write(path, data):
    tmp = path + ".new"
    with open(tmp, "wb") as f: f.write(data)
    os.replace(tmp, path)


def _backups(d):
    b = os.path.join(d, "backup")
    try: return sorted(x for x in os.listdir(b) if os.path.isfile(os.path.join(b, x, "meta.json")))
    except OSError: return []


def _restore(bdir, d):
    with open(os.path.join(bdir, "meta.json"), encoding="utf-8") as f: meta = json.load(f)
    for n in meta.get("files", []):
        src = os.path.join(bdir, n)
        if n not in meta.get("added", []) and os.path.exists(src): _write(os.path.join(d, n), open(src, "rb").read())
    for n in meta.get("added", []):
        try: os.remove(os.path.join(d, n))
        except OSError: pass


def apply(pkg, d=None, role="user", log=print):
    """Ghi các file khác biệt vào thư mục cài đặt. Trả về danh sách file đã đổi ([] nếu không có gì khác).
    Lỗi ở bất kỳ bước nào (cú pháp, thiếu thư viện, import hỏng) -> khôi phục bản cũ rồi ném lỗi."""
    d = d or HERE
    if role == "user": pkg = {n: b for n, b in pkg.items() if n in USER_FILES}
    p = plan(pkg, d, role)
    changed = p["changed"]
    if not changed: return []
    cur = local_files(d)
    bdir = os.path.join(d, "backup", time.strftime("%Y%m%d-%H%M%S") + "-v" + p["ver_old"])
    os.makedirs(bdir, exist_ok=True)
    for n in changed:
        if n in cur: shutil.copy2(os.path.join(d, n), os.path.join(bdir, n))
    with open(os.path.join(bdir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump({"files": changed, "added": p["added"], "ver": p["ver_old"], "ver_new": p["ver_new"], "time": time.time()}, f)
    for old in _backups(d)[:-KEEP_BACKUPS]: shutil.rmtree(os.path.join(d, "backup", old), ignore_errors=True)
    try:
        for n in changed:
            try: _write(os.path.join(d, n), pkg[n])
            except OSError:
                if n.endswith(".py") or n in ("requirements.txt", "version.txt"): raise      # file code bắt buộc ghi được; icon/README bị khóa thì bỏ qua
                _say(log, "  bỏ qua (đang bị khóa): " + n)
        if "requirements.txt" in changed: pip_install(d, log)
        smoke_test(d, role)
    except Exception:
        try: _restore(bdir, d)
        except Exception as e: _say(log, "Không hoàn tác được: %s" % e)
        shutil.rmtree(bdir, ignore_errors=True)
        raise
    _say(log, "Đã cập nhật %d file: %s" % (len(changed), ", ".join(changed)))
    return changed


def last_backup(d=None):
    d = d or HERE
    b = _backups(d)
    if not b: return None
    try:
        with open(os.path.join(d, "backup", b[-1], "meta.json"), encoding="utf-8") as f: meta = json.load(f)
    except Exception:
        return None
    meta["name"] = b[-1]
    return meta


def rollback(d=None, role="user", log=print):
    """Khôi phục bản trước lần cập nhật gần nhất."""
    d = d or HERE
    info = last_backup(d)
    if not info: raise RuntimeError("Chưa có bản sao lưu để khôi phục.")
    bdir = os.path.join(d, "backup", info["name"])
    _restore(bdir, d)
    shutil.rmtree(bdir, ignore_errors=True)
    smoke_test(d, role)
    _say(log, "Đã khôi phục bản %s" % info.get("ver", "?"))
    return info


# ---------------- khởi động lại ứng dụng sau khi cập nhật ----------------
def relaunch(script):
    """Mở tiến trình phụ: chờ tiến trình hiện tại thoát rồi chạy lại <script>. Gọi xong thì thoát tiến trình hiện tại."""
    kw = {"creationflags": 0x00000008 | 0x00000200} if WIN else {"start_new_session": True}
    subprocess.Popen([sys.executable, os.path.join(HERE, "updater.py"), "--relaunch", script, str(os.getpid())], cwd=HERE,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)


def _wait_exit(pid, timeout=25):
    if WIN:
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x00100000, False, pid)     # SYNCHRONIZE
            if h:
                ctypes.windll.kernel32.WaitForSingleObject(h, int(timeout * 1000)); ctypes.windll.kernel32.CloseHandle(h)
                return
        except Exception:
            pass
    end = time.time() + timeout
    while time.time() < end:
        try: os.kill(pid, 0)
        except OSError: return
        time.sleep(0.3)


if __name__ == "__main__" and len(sys.argv) >= 4 and sys.argv[1] == "--relaunch":
    _wait_exit(int(sys.argv[3])); time.sleep(1.0)
    kw = {"creationflags": 0x00000008 | 0x00000200} if WIN else {"start_new_session": True}
    subprocess.Popen([sys.executable, os.path.join(HERE, os.path.basename(sys.argv[2]))], cwd=HERE, stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
