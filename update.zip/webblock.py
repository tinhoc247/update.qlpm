"""Chặn web xấu / đen / không an toàn – dùng chung cho admin (chọn danh mục, lưu cài đặt) và user (thực thi).

Máy user chặn theo 3 lớp (lớp nào làm được thì làm, lớp nào không đủ quyền thì bỏ qua):
  1. Chính sách trình duyệt (Chrome / Edge / Brave): Windows ghi vào HKEY_CURRENT_USER (không cần quyền admin);
     Linux ghi vào /etc/.../policies/managed nếu có quyền root. Gồm danh sách chặn URL và (tùy chọn) bắt buộc HTTPS.
  2. File hosts (cần quyền Administrator / root) – chặn cả khi dùng trình duyệt khác.
  3. Canh cửa sổ trình duyệt đang mở: tiêu đề chứa tên trang bị chặn (facebook, tiktok, xxx...) thì đóng tab đó (Ctrl+W).
     Lớp này chạy được mọi trình duyệt, không cần quyền gì.
Khi mất kết nối với admin hoặc admin bấm Tắt chặn: mọi thay đổi được gỡ về như cũ."""
import json, os, re, subprocess, time, unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(HERE, "webblock.json")                # máy admin: nhớ cài đặt lần trước
STATE = os.path.join(HERE, "webblock_state.json")         # máy user: ghi lại những gì đã chỉnh để gỡ cho sạch
WIN = os.name == "nt"
MARK_B, MARK_E = "# LabManager-BEGIN (tu dong, khong sua)", "# LabManager-END"

# khóa danh mục -> (tên hiển thị, [tên miền], [từ khóa trong tiêu đề trang])
CATEGORIES = {
    "adult": ("Web người lớn / đen (xxx, porn…)",
              ["pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com", "youporn.com", "spankbang.com", "xvideos2.com",
               "onlyfans.com", "chaturbate.com", "stripchat.com", "livejasmin.com", "hentaihaven.xxx", "nhentai.net", "motphim.tv", "phimsex.com",
               "sex.com", "porn.com", "eporner.com", "tnaflix.com", "beeg.com", "rule34.xxx"],
              ["xxx", "porn", "porno", "pornhub", "xvideos", "xnxx", "hentai", "sex video", "phim sex", "sex vietsub", "jav", "nsfw", "18+", "chat sex", "gai goi"]),
    "social": ("Mạng xã hội (Facebook, TikTok, Instagram…)",
               ["facebook.com", "fb.com", "fb.watch", "fbcdn.net", "messenger.com", "instagram.com", "tiktok.com", "tiktokv.com", "musical.ly",
                "twitter.com", "x.com", "snapchat.com", "threads.net", "pinterest.com", "reddit.com", "tumblr.com", "discord.com", "telegram.org", "web.telegram.org"],
               ["facebook", "tiktok", "instagram", "messenger", "snapchat", "twitter", "discord"]),
    "gambling": ("Cá cược / cờ bạc",
                 ["bet365.com", "1xbet.com", "w88.com", "fb88.com", "m88.com", "188bet.com", "vn88.com", "12bet.com", "bk8.com", "new88.com", "789bet.com",
                  "kubet.com", "debet.com", "sbobet.com", "go88.com", "sunwin.com", "b52.club", "hitclub.win", "789club.com", "rikvip.club"],
                 ["ca cuoc", "nha cai", "casino", "tai xiu", "xoc dia", "no hu", "danh bai doi thuong", "bet365", "1xbet", "w88", "fb88", "m88"]),
    "game": ("Game online (Roblox, Liên Quân, game flash…)",
             ["roblox.com", "garena.vn", "garena.com", "lienquan.garena.vn", "miniclip.com", "poki.com", "y8.com", "crazygames.com", "friv.com",
              "agar.io", "slither.io", "steampowered.com", "epicgames.com", "minecraft.net", "freefire.garena.vn", "playtogether.com", "gamevui.vn", "game24h.vn", "kiz10.com"],
             ["roblox", "lien quan", "free fire", "minecraft", "poki", "miniclip", "crazygames", "gamevui", "game vui", "game24h", "csgo", "pubg", "fortnite"]),
    "video": ("Video giải trí (YouTube, Netflix, Twitch…)",
              ["youtube.com", "youtu.be", "m.youtube.com", "netflix.com", "twitch.tv", "dailymotion.com", "bilibili.com", "vimeo.com", "phimmoi.net", "fptplay.vn"],
              ["youtube", "netflix", "twitch", "bilibili"]),
}
DEFAULT_CATS = ["adult", "social", "gambling"]
BROWSERS = {"chrome", "edge", "msedge", "firefox", "brave", "opera", "opera_gx", "chromium", "chromium-browser", "firefox-esr", "vivaldi",
            "coccoc", "browser", "iexplore", "waterfox", "librewolf", "epiphany", "falkon", "tor browser", "safari"}
_DOMAIN = re.compile(r"[a-z0-9-]+(\.[a-z0-9-]+)+")
_SLD = {"com", "net", "org", "co", "gov", "edu", "vn", "info", "biz", "club"}


def norm(s):
    """Chữ thường, bỏ dấu tiếng Việt (để 'Cá cược' khớp 'ca cuoc')."""
    s = unicodedata.normalize("NFD", str(s).lower().replace("đ", "d"))
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")


def clean_policy(p):
    """Chuẩn hóa chính sách nhận từ mạng / file: {'on': bool, 'cats': [...], 'custom': [...], 'https': bool}."""
    p = p if isinstance(p, dict) else {}
    cats = [k for k in (p.get("cats") or []) if k in CATEGORIES] if isinstance(p.get("cats"), list) else list(DEFAULT_CATS)
    custom = []
    for x in (p.get("custom") or [])[:300] if isinstance(p.get("custom"), list) else []:
        x = str(x).strip()[:100]
        if x and x not in custom: custom.append(x)
    return {"on": bool(p.get("on")), "cats": cats, "custom": custom, "https": bool(p.get("https"))}


def _host(line):
    e = norm(line).strip()
    e = e.split("://", 1)[-1].split("/", 1)[0].split("?", 1)[0].split(":", 1)[0]
    if e.startswith("www."): e = e[4:]
    return e if _DOMAIN.fullmatch(e) else None


class Rules:
    def __init__(self, policy):
        p = clean_policy(policy)
        doms, words = [], []
        for k in p["cats"]: doms += CATEGORIES[k][1]; words += CATEGORIES[k][2]
        for x in p["custom"]:
            h = _host(x)
            if h: doms.append(h)
            elif norm(x).strip(): words.append(norm(x).strip())
        self.domains = list(dict.fromkeys(doms))
        self.words = list(dict.fromkeys(norm(w) for w in words))
        labels = []
        for d in self.domains:
            parts = d.split(".")
            lab = parts[-3] if len(parts) >= 3 and parts[-2] in _SLD else parts[-2]
            if len(lab) >= 5: labels.append(lab)
        self.labels = list(dict.fromkeys(labels))
        self.https = p["https"]
        self._re = [re.compile(r"(?<![a-z0-9])" + re.escape(w) + r"(?![a-z0-9])") for w in self.words]
        self._dre = [(d, re.compile(r"(?<![a-z0-9.-])" + re.escape(d) + r"(?![a-z0-9-])")) for d in self.domains]

    def match(self, title):
        """Tiêu đề trang chứa tên miền / tên trang bị chặn -> trả về cụm khớp, không thì None."""
        t = norm(title)
        if not t: return None
        for d, r in self._dre:
            if r.search(t): return d
        for l in self.labels:
            if l in t: return l
        for w, r in zip(self.words, self._re):
            if r.search(t): return w
        return None


# ---------------- lưu / nạp (máy admin) ----------------
def load():
    try:
        with open(FILE, encoding="utf-8") as f: return clean_policy(json.load(f))
    except Exception:
        return {"on": False, "cats": list(DEFAULT_CATS), "custom": [], "https": False}


def save(p):
    try:
        with open(FILE, "w", encoding="utf-8") as f: json.dump(clean_policy(p), f, ensure_ascii=False, indent=1)
    except OSError as e:
        print("webblock lưu:", e)


# ---------------- lớp 2: file hosts ----------------
def hosts_path(): return r"C:\Windows\System32\drivers\etc\hosts" if WIN else "/etc/hosts"


def _strip_block(text):
    out, skip = [], False
    for ln in text.splitlines():
        if ln.startswith(MARK_B): skip = True; continue
        if skip and ln.startswith(MARK_E): skip = False; continue
        if not skip: out.append(ln)
    return "\n".join(out).rstrip("\n") + "\n"


def write_hosts(domains, path=None):
    """Ghi (hoặc gỡ khi domains rỗng) khối chặn trong hosts. Trả về True nếu đã ghi được."""
    path = path or hosts_path()
    try:
        with open(path, encoding="utf-8", errors="replace") as f: text = f.read()
        new = _strip_block(text)
        if domains:
            lines = [MARK_B]
            for d in domains[:1500]: lines += ["0.0.0.0 " + d, "0.0.0.0 www." + d]
            new += "\n".join(lines + [MARK_E]) + "\n"
        if new != text:
            with open(path, "w", encoding="utf-8", newline="\n") as f: f.write(new)
            if WIN: subprocess.run(["ipconfig", "/flushdns"], capture_output=True, creationflags=0x08000000, timeout=15)
        return True
    except Exception:
        return False


# ---------------- lớp 1: chính sách trình duyệt ----------------
_REG = [(r"Software\Policies\Google\Chrome", "chrome"), (r"Software\Policies\Microsoft\Edge", "edge"), (r"Software\Policies\BraveSoftware\Brave", "brave")]
_LINUX_DIRS = ["/etc/opt/chrome/policies/managed", "/etc/chromium/policies/managed", "/etc/brave/policies/managed", "/etc/opt/edge/policies/managed"]


def _win_apply(domains, https):
    import winreg
    H, made = winreg.HKEY_CURRENT_USER, []
    for base, kind in _REG:
        try:
            try:
                winreg.CloseKey(winreg.OpenKey(H, base + r"\URLBlocklist")); continue      # đã có chính sách của nơi khác: không đụng vào
            except OSError: pass
            item = {"base": base, "https": None}
            with winreg.CreateKey(H, base + r"\URLBlocklist") as k:
                for i, d in enumerate(domains[:900], 1): winreg.SetValueEx(k, str(i), 0, winreg.REG_SZ, d)
            if https:
                name, typ, val = ("AutomaticHttpsDefault", winreg.REG_DWORD, 2) if kind == "edge" else ("HttpsOnlyMode", winreg.REG_SZ, "force_enabled")
                with winreg.CreateKey(H, base) as k:
                    try: winreg.QueryValueEx(k, name)
                    except OSError: winreg.SetValueEx(k, name, 0, typ, val); item["https"] = name
            made.append(item)
        except OSError:
            pass
    return made


def _win_remove(made):
    import winreg
    H = winreg.HKEY_CURRENT_USER
    for it in made:
        try:
            with winreg.OpenKey(H, it["base"] + r"\URLBlocklist", 0, winreg.KEY_ALL_ACCESS) as k:
                while True:
                    try: winreg.DeleteValue(k, winreg.EnumValue(k, 0)[0])
                    except OSError: break
            winreg.DeleteKey(H, it["base"] + r"\URLBlocklist")
        except OSError: pass
        if it.get("https"):
            try:
                with winreg.OpenKey(H, it["base"], 0, winreg.KEY_ALL_ACCESS) as k: winreg.DeleteValue(k, it["https"])
            except OSError: pass
        try: winreg.DeleteKey(H, it["base"])       # chỉ xóa được khi trống (khóa do ta tạo); có chính sách khác thì giữ nguyên
        except OSError: pass


def _linux_apply(domains, https):
    made = []
    pol = {"URLBlocklist": domains[:900]}
    if https: pol["HttpsOnlyMode"] = "force_enabled"
    for d in _LINUX_DIRS:
        try:
            os.makedirs(d, exist_ok=True)
            p = os.path.join(d, "labmanager.json")
            with open(p, "w", encoding="utf-8") as f: json.dump(pol, f)
            made.append(p)
        except OSError:
            pass
    return made


# ---------------- lớp 3: đóng tab ----------------
def close_tab():
    """Ctrl+W vào cửa sổ đang ở phía trước (trình duyệt đang hiện trang bị chặn)."""
    try:
        if WIN:
            import ctypes
            u = ctypes.windll.user32
            u.keybd_event(0x11, 0, 0, 0); u.keybd_event(0x57, 0, 0, 0); u.keybd_event(0x57, 0, 2, 0); u.keybd_event(0x11, 0, 2, 0)
        else:
            subprocess.run(["xdotool", "key", "--clearmodifiers", "ctrl+w"], capture_output=True, timeout=3)
        return True
    except Exception:
        return False


class Enforcer:
    """Thực thi trên máy user. active = đang bật chặn."""
    def __init__(self):
        self.rules = None; self.info = {}

    @property
    def active(self): return self.rules is not None

    def apply(self, policy):
        p = clean_policy(policy)
        self.clear()
        r = Rules(p)
        if not (r.domains or r.words): return {}
        state = {"hosts": False, "reg": [], "files": []}
        try: state["reg"] = _win_apply(r.domains, r.https) if WIN else []
        except Exception: pass
        try: state["files"] = [] if WIN else _linux_apply(r.domains, r.https)
        except Exception: pass
        state["hosts"] = write_hosts(r.domains)
        try:
            with open(STATE, "w", encoding="utf-8") as f: json.dump(state, f)
        except OSError: pass
        self.rules = r
        self.info = {"browser": bool(state["reg"] or state["files"]), "hosts": state["hosts"], "domains": len(r.domains)}
        return self.info

    def clear(self):
        """Gỡ mọi thay đổi (cả những gì còn sót từ lần chạy trước bị tắt đột ngột)."""
        self.rules = None; self.info = {}
        try:
            with open(STATE, encoding="utf-8") as f: st = json.load(f)
        except Exception:
            return
        try:
            if st.get("hosts"): write_hosts([])
            if WIN and st.get("reg"): _win_remove(st["reg"])
            for p in st.get("files", []):
                try: os.remove(p)
                except OSError: pass
        finally:
            try: os.remove(STATE)
            except OSError: pass

    def check(self, app, title):
        """Cửa sổ trình duyệt đang hiện trang bị chặn? -> cụm khớp hoặc None."""
        if not self.rules or str(app).lower() not in BROWSERS: return None
        return self.rules.match(title)


# ======================================================================================================================
# CHẶN CHẠY FILE CÀI ĐẶT (máy user)
# Admin chọn Bật/Tắt + danh sách file được phép; máy user canh các tiến trình mới và ĐÓNG ngay trình cài đặt.
# Chính sách được nhớ ngay trên máy user (installblock_state.json) nên vẫn chặn khi mất kết nối admin hoặc sau khi bật lại máy.
# Không cần quyền Administrator (chỉ đóng được tiến trình do chính tài khoản học sinh chạy).
# Nhận diện: (1) công cụ cài của hệ thống (msiexec, wusa, winget, AppInstaller); (2) tên file chứa setup / install / unins / caidat;
#            (3) file .exe nằm ngoài thư mục hệ thống mà bên trong là bộ cài (Inno Setup, NSIS, InstallShield, WiX/Burn, 7-Zip SFX...),
#            nên đổi tên setup.exe thành abc.exe vẫn bị chặn; (4) file tạm .tmp do bộ cài giải nén ra thư mục Temp.
# Không đụng tới: tiến trình của dịch vụ hệ thống (phiên 0: Windows Update, msiexec /V, phần mềm quản trị tập trung), file trong
# Windows / Program Files / ProgramData và thư mục cài đặt của LabManager.
# ======================================================================================================================
INST_FILE = os.path.join(HERE, "installblock.json")             # máy admin: nhớ cài đặt lần trước
INST_STATE = os.path.join(HERE, "installblock_state.json")      # máy user: nhớ chính sách để vẫn chặn khi mất kết nối admin
INST_DEFAULT = {"on": True, "allow": []}
WIN_TOOLS = {"msiexec.exe", "appinstaller.exe", "wusa.exe", "winget.exe"}
LINUX_PKG = {"dpkg", "apt", "apt-get", "aptitude", "gdebi", "gdebi-gtk", "gnome-software", "synaptic", "dnf", "yum", "rpm",
             "pamac-manager", "plasma-discover", "software-center"}
LINUX_SUB = {"snap": {"install", "refresh", "remove"}, "flatpak": {"install", "update", "uninstall"}}
LINUX_INTERP = {"bash", "sh", "dash", "zsh", "python", "python3", "perl", "ruby"}
_HINTS = ("setup", "install", "unins", "caidat")
_SIGS = (b"Nullsoft Install System", b"Inno Setup Setup Data", b"Inno Setup Messages", b"InstallShield", b".wixburn", b"WixBurn",
         b"Advanced Installer", b"Setup Factory", b"Wise Installation", b";!@Install@!UTF-8!")


def clean_inst(p):
    """Chuẩn hóa chính sách chặn cài đặt: {'on': bool, 'allow': [tên file được phép]}. Thiếu 'on' = BẬT."""
    p = p if isinstance(p, dict) else {}
    allow = []
    for x in (p.get("allow") or [])[:200] if isinstance(p.get("allow"), list) else []:
        x = os.path.basename(str(x).replace("\\", "/")).strip().lower()[:100]
        if x and x not in allow: allow.append(x)
    return {"on": bool(p["on"]) if "on" in p else True, "allow": allow}


def inst_load(path=None):
    try:
        with open(path or INST_FILE, encoding="utf-8") as f: return clean_inst(json.load(f))
    except Exception:
        return clean_inst(INST_DEFAULT)


def inst_save(p, path=None):
    try:
        with open(path or INST_FILE, "w", encoding="utf-8") as f: json.dump(clean_inst(p), f, ensure_ascii=False, indent=1)
    except OSError as e:
        print("installblock lưu:", e)


def looks_like_installer(name):
    """Tên file có vẻ là bộ cài: setup, install, uninstall, unins000, 'Cài đặt'... (bỏ dấu, bỏ ký tự phân cách)."""
    flat = re.sub(r"[^a-z0-9]", "", norm(os.path.splitext(str(name).lower())[0]))
    return any(h in flat for h in _HINTS)


def has_installer_signature(path, cache=None):
    """File .exe có dấu hiệu bên trong là bộ cài (đọc 4 MB đầu, kết quả nhớ theo đường dẫn + dung lượng + ngày sửa)."""
    cache = cache if cache is not None else {}
    try: st = os.stat(path)
    except OSError: return False
    key = (path, st.st_size, int(st.st_mtime))
    if key in cache: return cache[key]
    hit = False
    try:
        with open(path, "rb") as f: head = f.read(4 << 20)
        hit = head[:2] == b"MZ" and any(s in head for s in _SIGS)
    except OSError:
        pass
    if len(cache) > 500: cache.clear()
    cache[key] = hit
    return hit


def trusted_dirs():
    """Thư mục hệ thống / chương trình đã cài: file chạy từ đây không bị coi là bộ cài do học sinh mang vào."""
    if WIN:
        sd = os.environ.get("SystemDrive", "C:")
        vals = [os.environ.get(k, "") for k in ("SystemRoot", "ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "ProgramData")] + [sd + "\\$Windows.~BT", HERE]
    else:
        vals = ["/usr", "/bin", "/sbin", "/lib", "/lib64", "/opt", "/snap", "/var/lib", "/etc", HERE]
    return tuple(os.path.normcase(os.path.abspath(v)) + os.sep for v in vals if v)


def _descendants(pid, procs):
    kids = {}
    for p, (pp, _) in procs.items(): kids.setdefault(pp, []).append(p)
    out, stack = [], [pid]
    while stack:
        for c in kids.get(stack.pop(), []):
            if c != pid and c not in out: out.append(c); stack.append(c)
    return out


# ---------------- Windows: liệt kê / thông tin / đóng tiến trình (ctypes, không cần thư viện ngoài) ----------------
def _win_procs():
    """{pid: (pid cha, tên file)} bằng Toolhelp snapshot."""
    import ctypes
    from ctypes import wintypes

    class PE(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("pid", wintypes.DWORD), ("heap", ctypes.c_size_t),
                    ("mod", wintypes.DWORD), ("thr", wintypes.DWORD), ("ppid", wintypes.DWORD), ("pri", ctypes.c_long),
                    ("flags", wintypes.DWORD), ("exe", ctypes.c_wchar * 260)]
    k = ctypes.windll.kernel32
    k.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    k.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    k.Process32FirstW.argtypes = k.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PE)]
    k.CloseHandle.argtypes = [wintypes.HANDLE]
    snap = k.CreateToolhelp32Snapshot(0x2, 0)
    out = {}
    if not snap or snap == wintypes.HANDLE(-1).value: return out
    try:
        e = PE(); e.dwSize = ctypes.sizeof(PE)
        ok = k.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            out[int(e.pid)] = (int(e.ppid), e.exe)
            ok = k.Process32NextW(snap, ctypes.byref(e))
    finally:
        k.CloseHandle(snap)
    return out


def _win_path(pid):
    import ctypes
    from ctypes import wintypes
    k = ctypes.windll.kernel32
    k.OpenProcess.restype = wintypes.HANDLE; k.CloseHandle.argtypes = [wintypes.HANDLE]
    h = k.OpenProcess(0x1000, False, pid)            # PROCESS_QUERY_LIMITED_INFORMATION
    if not h: return ""
    try:
        sz = wintypes.DWORD(1040); b = ctypes.create_unicode_buffer(1040)
        return b.value if k.QueryFullProcessImageNameW(h, 0, b, ctypes.byref(sz)) else ""
    finally:
        k.CloseHandle(h)


def _win_session(pid):
    import ctypes
    from ctypes import wintypes
    sid = wintypes.DWORD()
    return int(sid.value) if ctypes.windll.kernel32.ProcessIdToSessionId(pid, ctypes.byref(sid)) else -1


def _win_kill(pid):
    import ctypes
    from ctypes import wintypes
    k = ctypes.windll.kernel32
    k.OpenProcess.restype = wintypes.HANDLE; k.CloseHandle.argtypes = [wintypes.HANDLE]
    k.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
    h = k.OpenProcess(0x0001, False, pid)            # PROCESS_TERMINATE
    if not h: return False
    try: return bool(k.TerminateProcess(h, 1))
    finally: k.CloseHandle(h)


# ---------------- Linux: đọc /proc ----------------
def _linux_procs():
    out = {}
    try: names = os.listdir("/proc")
    except OSError: return out
    for d in names:
        if not d.isdigit(): continue
        try:
            with open("/proc/%s/stat" % d, encoding="utf-8", errors="replace") as f: s = f.read()
            r = s.rfind(")")
            out[int(d)] = (int(s[r + 2:].split()[1]), s[s.find("(") + 1:r])
        except Exception:
            continue
    return out


def _linux_kill(pid):
    try: os.kill(pid, 9); return True
    except OSError: return False


class InstallGuard:
    """Thực thi trên máy user: canh tiến trình mới và đóng trình cài đặt. Chạy trong luồng riêng, độc lập với kết nối admin."""
    def __init__(self, interval=0.4):
        self.policy = clean_inst(INST_DEFAULT); self.enabled = True       # enabled=False: máy này tắt hẳn tính năng (config.json "install_block": false)
        self.interval, self.notify, self.hook = interval, None, None      # notify(text): báo học sinh | hook(name, đã_đóng): báo admin
        self.known, self.sig, self.th, self.last_note, self.sid, self.label = {}, {}, None, 0.0, None, None
        self.state_path = INST_STATE

    @property
    def active(self): return self.enabled and self.policy["on"]

    def load(self):
        """Nạp chính sách đã nhớ (chưa từng nhận thì mặc định: BẬT)."""
        try:
            with open(self.state_path, encoding="utf-8") as f: self.policy = clean_inst(json.load(f))
        except Exception:
            self.policy = clean_inst(INST_DEFAULT)

    def apply(self, policy):
        """Nhận chính sách từ admin, nhớ lại trên máy. Trả về True nếu có thay đổi."""
        p = clean_inst(policy); changed = p != self.policy; self.policy = p
        try:
            with open(self.state_path, "w", encoding="utf-8") as f: json.dump(p, f, ensure_ascii=False)
        except OSError:
            pass
        return changed

    def start(self):
        if self.th and self.th.is_alive(): return
        import threading
        self.th = threading.Thread(target=self._loop, daemon=True); self.th.start()

    def _loop(self):
        while True:
            time.sleep(self.interval)
            if not self.active: self.known = {}; continue
            try: self.scan()
            except Exception as e: print("installblock:", e)

    # ---- nhận diện ----
    def judge(self, pid, name, procs):
        """Trả về lý do nếu tiến trình là trình cài đặt cần đóng, không thì None."""
        allow = set(self.policy["allow"]); self.label = None
        if name.lower() in allow: return None
        try: return self._judge_win(pid, name, allow) if WIN else self._judge_linux(pid, allow)
        except Exception: return None

    def _judge_win(self, pid, name, allow):
        if self.sid is None: self.sid = _win_session(os.getpid())
        if _win_session(pid) != self.sid: return None                 # chỉ phiên của học sinh; bỏ qua dịch vụ hệ thống (Windows Update, msiexec /V...)
        if name.lower() in WIN_TOOLS: return "công cụ cài đặt của Windows"
        path = _win_path(pid)
        if not path: return None
        low = os.path.normcase(path); base = os.path.basename(low)
        if base in allow or low.startswith(trusted_dirs()): return None
        ext = os.path.splitext(base)[1]
        if ext == ".tmp" and (os.sep + "temp" + os.sep) in low: return "file cài đặt tạm"
        if ext != ".exe": return None
        if looks_like_installer(base): return "tên file là bộ cài đặt"
        if has_installer_signature(path, self.sig): return "bên trong là bộ cài đặt"
        return None

    def _judge_linux(self, pid, allow):
        uid = os.stat("/proc/%d" % pid).st_uid
        if uid == 0 and os.getuid() != 0: return None                  # không đóng được tiến trình root
        with open("/proc/%d/cmdline" % pid, "rb") as f: args = [a.decode("utf-8", "replace") for a in f.read().split(b"\0") if a]
        if not args: return None
        a0 = os.path.basename(args[0]).lower()
        if a0 in LINUX_PKG: return "trình cài đặt gói"
        if a0 in LINUX_SUB and any(a in LINUX_SUB[a0] for a in args[1:3]): return "lệnh cài đặt " + a0
        target = args[0]
        if a0 in LINUX_INTERP:                                         # bash install.sh / python3 setup.py
            target = next((a for a in args[1:] if not a.startswith("-")), "")
            if not target: return None
        if not os.path.isabs(target):
            try: target = os.path.join(os.readlink("/proc/%d/cwd" % pid), target)
            except OSError: return None
        target = os.path.normcase(os.path.abspath(target)); b = os.path.basename(target).lower(); self.label = os.path.basename(target)
        if b in allow or target.startswith(trusted_dirs()): return None
        if looks_like_installer(b) or b.endswith(".run"): return "tên file là bộ cài đặt"
        return None

    def scan(self):
        procs = _win_procs() if WIN else _linux_procs()
        me = os.getpid()
        new = [p for p, (_, n) in procs.items() if self.known.get(p) != n]
        self.known = {p: n for p, (_, n) in procs.items()}
        mine = set(_descendants(me, procs)) | {me}
        for pid in new:
            if pid in mine or pid not in procs: continue
            reason = self.judge(pid, procs[pid][1], procs)
            if reason: self.block(pid, self.label or procs[pid][1], reason, procs)

    def block(self, pid, name, reason, procs):
        kill = _win_kill if WIN else _linux_kill
        for c in reversed(_descendants(pid, procs)): kill(c)          # bộ cài mở thêm tiến trình con: đóng luôn
        ok = kill(pid)
        print("installblock: %s %s (%s)" % ("đã đóng" if ok else "KHÔNG đóng được", name, reason))
        if time.time() - self.last_note > 4:
            self.last_note = time.time()
            if self.notify: self.notify("Máy này không được cài đặt phần mềm\nĐã chặn: " + name)
        if self.hook:
            try: self.hook(name, ok)
            except Exception: pass
