"""Chặn web xấu / đen / không an toàn – dùng chung cho admin (chọn danh mục, lưu cài đặt) và user (thực thi).

Máy user chặn theo 3 lớp (lớp nào làm được thì làm, lớp nào không đủ quyền thì bỏ qua):
  1. Chính sách trình duyệt (Chrome / Edge / Brave): Windows ghi vào HKEY_CURRENT_USER (không cần quyền admin);
     Linux ghi vào /etc/.../policies/managed nếu có quyền root. Gồm danh sách chặn URL và (tùy chọn) bắt buộc HTTPS.
  2. File hosts (cần quyền Administrator / root) – chặn cả khi dùng trình duyệt khác.
  3. Canh cửa sổ trình duyệt đang mở: tiêu đề chứa tên trang bị chặn (facebook, tiktok, xxx...) thì đóng tab đó (Ctrl+W).
     Lớp này chạy được mọi trình duyệt, không cần quyền gì.
Khi mất kết nối với admin hoặc admin bấm Tắt chặn: mọi thay đổi được gỡ về như cũ."""
import json, os, re, subprocess, time, unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(HERE, "webblock.json")                # máy admin: nhớ cài đặt lần trước
STATE = os.path.join(HERE, "webblock_state.json")         # máy user: ghi lại những gì đã chỉnh để gỡ cho sạch
WIN = os.name == "nt"
MARK_B, MARK_E = "# LabManager-BEGIN (tu dong, khong sua)", "# LabManager-END"

# khóa danh mục -> (tên hiển thị, [tên miền], [từ khóa trong tiêu đề trang])
CATEGORIES = {
    "adult": ("Web người lớn / đen (xxx, porn…)",
              ["pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com", "youporn.com", "spankbang.com", "xvideos2.com",
               "onlyfans.com", "chaturbate.com", "stripchat.com", "livejasmin.com", "hentaihaven.xxx", "nhentai.net", "motphim.tv", "phimsex.com",
               "sex.com", "porn.com", "eporner.com", "tnaflix.com", "beeg.com", "rule34.xxx"],
              ["xxx", "porn", "porno", "pornhub", "xvideos", "xnxx", "hentai", "sex video", "phim sex", "sex vietsub", "jav", "nsfw", "18+", "chat sex", "gai goi"]),
    "social": ("Mạng xã hội (Facebook, TikTok, Instagram…)",
               ["facebook.com", "fb.com", "fb.watch", "fbcdn.net", "messenger.com", "instagram.com", "tiktok.com", "tiktokv.com", "musical.ly",
                "twitter.com", "x.com", "snapchat.com", "threads.net", "pinterest.com", "reddit.com", "tumblr.com", "discord.com", "telegram.org", "web.telegram.org"],
               ["facebook", "tiktok", "instagram", "messenger", "snapchat", "twitter", "discord"]),
    "gambling": ("Cá cược / cờ bạc",
                 ["bet365.com", "1xbet.com", "w88.com", "fb88.com", "m88.com", "188bet.com", "vn88.com", "12bet.com", "bk8.com", "new88.com", "789bet.com",
                  "kubet.com", "debet.com", "sbobet.com", "go88.com", "sunwin.com", "b52.club", "hitclub.win", "789club.com", "rikvip.club"],
                 ["ca cuoc", "nha cai", "casino", "tai xiu", "xoc dia", "no hu", "danh bai doi thuong", "bet365", "1xbet", "w88", "fb88", "m88"]),
    "game": ("Game online (Roblox, Liên Quân, game flash…)",
             ["roblox.com", "garena.vn", "garena.com", "lienquan.garena.vn", "miniclip.com", "poki.com", "y8.com", "crazygames.com", "friv.com",
              "agar.io", "slither.io", "steampowered.com", "epicgames.com", "minecraft.net", "freefire.garena.vn", "playtogether.com", "gamevui.vn", "game24h.vn", "kiz10.com"],
             ["roblox", "lien quan", "free fire", "minecraft", "poki", "miniclip", "crazygames", "gamevui", "game vui", "game24h", "csgo", "pubg", "fortnite"]),
    "video": ("Video giải trí (YouTube, Netflix, Twitch…)",
              ["youtube.com", "youtu.be", "m.youtube.com", "netflix.com", "twitch.tv", "dailymotion.com", "bilibili.com", "vimeo.com", "phimmoi.net", "fptplay.vn"],
              ["youtube", "netflix", "twitch", "bilibili"]),
}
DEFAULT_CATS = ["adult", "social", "gambling"]
BROWSERS = {"chrome", "edge", "msedge", "firefox", "brave", "opera", "opera_gx", "chromium", "chromium-browser", "firefox-esr", "vivaldi",
            "coccoc", "browser", "iexplore", "waterfox", "librewolf", "epiphany", "falkon", "tor browser", "safari"}
_DOMAIN = re.compile(r"[a-z0-9-]+(\.[a-z0-9-]+)+")
_SLD = {"com", "net", "org", "co", "gov", "edu", "vn", "info", "biz", "club"}


def norm(s):
    """Chữ thường, bỏ dấu tiếng Việt (để 'Cá cược' khớp 'ca cuoc')."""
    s = unicodedata.normalize("NFD", str(s).lower().replace("đ", "d"))
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")


def clean_policy(p):
    """Chuẩn hóa chính sách nhận từ mạng / file: {'on': bool, 'cats': [...], 'custom': [...], 'https': bool}."""
    p = p if isinstance(p, dict) else {}
    cats = [k for k in (p.get("cats") or []) if k in CATEGORIES] if isinstance(p.get("cats"), list) else list(DEFAULT_CATS)
    custom = []
    for x in (p.get("custom") or [])[:300] if isinstance(p.get("custom"), list) else []:
        x = str(x).strip()[:100]
        if x and x not in custom: custom.append(x)
    return {"on": bool(p.get("on")), "cats": cats, "custom": custom, "https": bool(p.get("https"))}


def _host(line):
    e = norm(line).strip()
    e = e.split("://", 1)[-1].split("/", 1)[0].split("?", 1)[0].split(":", 1)[0]
    if e.startswith("www."): e = e[4:]
    return e if _DOMAIN.fullmatch(e) else None


class Rules:
    def __init__(self, policy):
        p = clean_policy(policy)
        doms, words = [], []
        for k in p["cats"]: doms += CATEGORIES[k][1]; words += CATEGORIES[k][2]
        for x in p["custom"]:
            h = _host(x)
            if h: doms.append(h)
            elif norm(x).strip(): words.append(norm(x).strip())
        self.domains = list(dict.fromkeys(doms))
        self.words = list(dict.fromkeys(norm(w) for w in words))
        labels = []
        for d in self.domains:
            parts = d.split(".")
            lab = parts[-3] if len(parts) >= 3 and parts[-2] in _SLD else parts[-2]
            if len(lab) >= 5: labels.append(lab)
        self.labels = list(dict.fromkeys(labels))
        self.https = p["https"]
        self._re = [re.compile(r"(?<![a-z0-9])" + re.escape(w) + r"(?![a-z0-9])") for w in self.words]
        self._dre = [(d, re.compile(r"(?<![a-z0-9.-])" + re.escape(d) + r"(?![a-z0-9-])")) for d in self.domains]

    def match(self, title):
        """Tiêu đề trang chứa tên miền / tên trang bị chặn -> trả về cụm khớp, không thì None."""
        t = norm(title)
        if not t: return None
        for d, r in self._dre:
            if r.search(t): return d
        for l in self.labels:
            if l in t: return l
        for w, r in zip(self.words, self._re):
            if r.search(t): return w
        return None


# ---------------- lưu / nạp (máy admin) ----------------
def load():
    try:
        with open(FILE, encoding="utf-8") as f: return clean_policy(json.load(f))
    except Exception:
        return {"on": False, "cats": list(DEFAULT_CATS), "custom": [], "https": False}


def save(p):
    try:
        with open(FILE, "w", encoding="utf-8") as f: json.dump(clean_policy(p), f, ensure_ascii=False, indent=1)
    except OSError as e:
        print("webblock lưu:", e)


# ---------------- lớp 2: file hosts ----------------
def hosts_path(): return r"C:\Windows\System32\drivers\etc\hosts" if WIN else "/etc/hosts"


def _strip_block(text):
    out, skip = [], False
    for ln in text.splitlines():
        if ln.startswith(MARK_B): skip = True; continue
        if skip and ln.startswith(MARK_E): skip = False; continue
        if not skip: out.append(ln)
    return "\n".join(out).rstrip("\n") + "\n"


def write_hosts(domains, path=None):
    """Ghi (hoặc gỡ khi domains rỗng) khối chặn trong hosts. Trả về True nếu đã ghi được."""
    path = path or hosts_path()
    try:
        with open(path, encoding="utf-8", errors="replace") as f: text = f.read()
        new = _strip_block(text)
        if domains:
            lines = [MARK_B]
            for d in domains[:1500]: lines += ["0.0.0.0 " + d, "0.0.0.0 www." + d]
            new += "\n".join(lines + [MARK_E]) + "\n"
        if new != text:
            with open(path, "w", encoding="utf-8", newline="\n") as f: f.write(new)
            if WIN: subprocess.run(["ipconfig", "/flushdns"], capture_output=True, creationflags=0x08000000, timeout=15)
        return True
    except Exception:
        return False


# ---------------- lớp 1: chính sách trình duyệt ----------------
_REG = [(r"Software\Policies\Google\Chrome", "chrome"), (r"Software\Policies\Microsoft\Edge", "edge"), (r"Software\Policies\BraveSoftware\Brave", "brave")]
_LINUX_DIRS = ["/etc/opt/chrome/policies/managed", "/etc/chromium/policies/managed", "/etc/brave/policies/managed", "/etc/opt/edge/policies/managed"]


def _win_apply(domains, https):
    import winreg
    H, made = winreg.HKEY_CURRENT_USER, []
    for base, kind in _REG:
        try:
            try:
                winreg.CloseKey(winreg.OpenKey(H, base + r"\URLBlocklist")); continue      # đã có chính sách của nơi khác: không đụng vào
            except OSError: pass
            item = {"base": base, "https": None}
            with winreg.CreateKey(H, base + r"\URLBlocklist") as k:
                for i, d in enumerate(domains[:900], 1): winreg.SetValueEx(k, str(i), 0, winreg.REG_SZ, d)
            if https:
                name, typ, val = ("AutomaticHttpsDefault", winreg.REG_DWORD, 2) if kind == "edge" else ("HttpsOnlyMode", winreg.REG_SZ, "force_enabled")
                with winreg.CreateKey(H, base) as k:
                    try: winreg.QueryValueEx(k, name)
                    except OSError: winreg.SetValueEx(k, name, 0, typ, val); item["https"] = name
            made.append(item)
        except OSError:
            pass
    return made


def _win_remove(made):
    import winreg
    H = winreg.HKEY_CURRENT_USER
    for it in made:
        try:
            with winreg.OpenKey(H, it["base"] + r"\URLBlocklist", 0, winreg.KEY_ALL_ACCESS) as k:
                while True:
                    try: winreg.DeleteValue(k, winreg.EnumValue(k, 0)[0])
                    except OSError: break
            winreg.DeleteKey(H, it["base"] + r"\URLBlocklist")
        except OSError: pass
        if it.get("https"):
            try:
                with winreg.OpenKey(H, it["base"], 0, winreg.KEY_ALL_ACCESS) as k: winreg.DeleteValue(k, it["https"])
            except OSError: pass
        try: winreg.DeleteKey(H, it["base"])       # chỉ xóa được khi trống (khóa do ta tạo); có chính sách khác thì giữ nguyên
        except OSError: pass


def _linux_apply(domains, https):
    made = []
    pol = {"URLBlocklist": domains[:900]}
    if https: pol["HttpsOnlyMode"] = "force_enabled"
    for d in _LINUX_DIRS:
        try:
            os.makedirs(d, exist_ok=True)
            p = os.path.join(d, "labmanager.json")
            with open(p, "w", encoding="utf-8") as f: json.dump(pol, f)
            made.append(p)
        except OSError:
            pass
    return made


# ---------------- lớp 3: đóng tab ----------------
def close_tab():
    """Ctrl+W vào cửa sổ đang ở phía trước (trình duyệt đang hiện trang bị chặn)."""
    try:
        if WIN:
            import ctypes
            u = ctypes.windll.user32
            u.keybd_event(0x11, 0, 0, 0); u.keybd_event(0x57, 0, 0, 0); u.keybd_event(0x57, 0, 2, 0); u.keybd_event(0x11, 0, 2, 0)
        else:
            subprocess.run(["xdotool", "key", "--clearmodifiers", "ctrl+w"], capture_output=True, timeout=3)
        return True
    except Exception:
        return False


class Enforcer:
    """Thực thi trên máy user. active = đang bật chặn."""
    def __init__(self):
        self.rules = None; self.info = {}

    @property
    def active(self): return self.rules is not None

    def apply(self, policy):
        p = clean_policy(policy)
        self.clear()
        r = Rules(p)
        if not (r.domains or r.words): return {}
        state = {"hosts": False, "reg": [], "files": []}
        try: state["reg"] = _win_apply(r.domains, r.https) if WIN else []
        except Exception: pass
        try: state["files"] = [] if WIN else _linux_apply(r.domains, r.https)
        except Exception: pass
        state["hosts"] = write_hosts(r.domains)
        try:
            with open(STATE, "w", encoding="utf-8") as f: json.dump(state, f)
        except OSError: pass
        self.rules = r
        self.info = {"browser": bool(state["reg"] or state["files"]), "hosts": state["hosts"], "domains": len(r.domains)}
        return self.info

    def clear(self):
        """Gỡ mọi thay đổi (cả những gì còn sót từ lần chạy trước bị tắt đột ngột)."""
        self.rules = None; self.info = {}
        try:
            with open(STATE, encoding="utf-8") as f: st = json.load(f)
        except Exception:
            return
        try:
            if st.get("hosts"): write_hosts([])
            if WIN and st.get("reg"): _win_remove(st["reg"])
            for p in st.get("files", []):
                try: os.remove(p)
                except OSError: pass
        finally:
            try: os.remove(STATE)
            except OSError: pass

    def check(self, app, title):
        """Cửa sổ trình duyệt đang hiện trang bị chặn? -> cụm khớp hoặc None."""
        if not self.rules or str(app).lower() not in BROWSERS: return None
        return self.rules.match(title)
