"""MÁY ADMIN – chạy:  python admin.py
Giao diện lưới ảnh thu nhỏ màn hình các máy (giống phần mềm quản lý lớp học)."""
import io, json, os, re, subprocess, sys, threading, time, webbrowser
import tkinter as tk
from tkinter import messagebox, filedialog, simpledialog, ttk
from urllib.parse import urlparse
from PIL import Image, ImageTk
from common import *
from server import Server
from theme import *
from helptext import TOPICS
import webblock
import updater
import unlock

# Chuyển ngữ Anh - Việt cho THANH CÔNG CỤ (nhãn tiếng Việt -> tiếng Anh)
TB_EN = {"Chọn tất cả": "Select all", "Khóa máy": "Lock", "Mở khóa": "Unlock", "Tắt máy": "Shut down", "Khởi động lại": "Restart",
         "Chiếu admin": "Present", "Xem 1 máy": "View 1 PC", "Quản lý 1 máy": "Manage 1 PC", "Chiếu cả lớp": "Broadcast", "Dừng chiếu": "Stop",
         "Gửi file": "Send file", "Thu bài": "Collect", "Nhận bài": "Inbox", "Gửi link": "Send link", "Thông báo": "Message",
         "Chặn web": "Block web", "Chặn cài đặt": "Block installs", "Làm tươi": "Rescan", "Cập nhật": "Update", "Quản lý phòng": "Rooms"}
LANG_FILE = os.path.join(os.path.expanduser("~"), ".labmanager_admin_lang")


def load_lang():
    try:
        with open(LANG_FILE, encoding="utf-8") as f: return "en" if f.read().strip() == "en" else "vi"
    except Exception: return "vi"


PREMIUM = {"Gửi file", "Thu bài", "Nhận bài", "Gửi link", "Thông báo", "Chặn web"}      # nút cần mã mở khóa
MENU_PREMIUM = {"Gửi file…", "Thu bài", "Gửi link…", "Gửi thông báo…", "Chặn web xấu…"}
LIC_GUARDED = ("send_file", "collect", "inbox_dialog", "send_link", "send_message", "web_dialog")


def _needs_license(fn):
    def w(self, *a, **k):
        if unlock.status()["state"] != "ok":
            self.apply_license(); self.msg = "Chức năng này cần mã mở khóa (menu Mở khóa → Nhập mã mở khóa)."; self.refresh()
            return messagebox.showinfo("Cần mở khóa", "Chức năng này cần mã mở khóa còn hạn.\nVào menu Mở khóa → Nhập mã mở khóa.", parent=self.root)
        return fn(self, *a, **k)
    return w


SIZES = [("Nhỏ", 170, 106), ("Vừa", 230, 144), ("Lớn", 310, 194), ("Tất cả", 0, 0)]
FIT = 3                                  # chế độ "Tất cả": tự co giãn để thấy mọi máy trong 1 khung hình
ASPECT = 0.625


def nat_key(s):
    """Sắp xếp tự nhiên: PC2 đứng trước PC10."""
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", s.lower())]


class Tile:
    def __init__(self, cid):
        self.cid, self.name, self.key, self.photo = cid, "", None, None
        self.no, self.user = 0, ""              # số thứ tự máy (theo thứ tự hiển thị) + tên tài khoản đang đăng nhập


class App:
    def __init__(self, cfg):
        self.cfg, self.srv = cfg, Server(cfg)
        self.stop_ev = self.prev = self.prev_lbl = self.prev_id = self.prev_last = self.prev_photo = None
        self.rc_on, self.rc_t, self.prev_img, self.mg, self.proc_data = False, 0.0, (0, 0), None, None
        self.sel, self.tiles, self.cols, self.blank = set(), {}, 0, {}
        self.fw, self.fh, self._rl, self.full = 230, 144, None, False
        r = self.root = tk.Tk(); r.title(f"Quản lý phòng máy – ADMIN  (bản {updater.RUN_VER})"); set_window_icon(r, "admin"); r.geometry("1180x760"); r.configure(bg=BG)
        self.F = pick_font(r); self.sc = scale_of(r); F = self.F
        self.tsize = tk.IntVar(value=1); self.thumbs = tk.BooleanVar(value=True); self.msg = ""
        isz = int(34 * self.sc)

        top = tk.Frame(r, bg=CARD); top.pack(fill="x")
        bar = self.bar = tk.Frame(top, bg=CARD); bar.pack(fill="x", padx=8, pady=(6, 4)); self._fit_job = None
        bar.bind("<Configure>", lambda e: self.fit_toolbar_later())
        tk.Frame(top, bg=BORDER, height=1).pack(fill="x")
        self.lang = load_lang(); self.tb_btns = []; self.lic_btns = []; self._lic_on = None
        self.lang_var = tk.StringVar(value=self.lang)
        def tb(icon, color, label, cmd):
            b = tk.Button(bar, text=TB_EN[label] if self.lang == "en" else label, image=tkicon(icon, isz, color), compound="top", command=cmd, relief="flat", bd=0, bg=CARD,
                          activebackground=PRIMARY_BG, font=(F, 9), fg=TEXT, padx=12, pady=5, cursor="hand2", takefocus=0)
            b.pack(side="left", padx=1); self.tb_btns.append((b, label))
            if label in PREMIUM: self.lic_btns.append((b, tkicon(icon, isz, color), tkicon(icon, isz, "#cbd5e1")))
            b.bind("<Enter>", lambda e: b.configure(bg=SEL_BG) if str(b["state"]) == "normal" else None); b.bind("<Leave>", lambda e: b.configure(bg=CARD))
        def sep(): tk.Frame(bar, bg=BORDER, width=1).pack(side="left", fill="y", padx=8, pady=6)
        tb("check", "#475569", "Chọn tất cả", self.select_all); sep()
        tb("lock", "#ea580c", "Khóa máy", lambda: self.lock(True)); tb("unlock", "#16a34a", "Mở khóa", lambda: self.lock(False))
        tb("power", "#dc2626", "Tắt máy", self.shutdown); tb("restart", "#d97706", "Khởi động lại", self.restart); sep()
        tb("present", "#2563eb", "Chiếu admin", self.present_admin); tb("manage", "#0f766e", "Quản lý 1 máy", self.manage)
        tb("broadcast", "#0891b2", "Chiếu cả lớp", lambda: self.share_user(True)); tb("stop", "#64748b", "Dừng chiếu", self.stop_all); sep()
        tb("file", "#f59e0b", "Gửi file", self.send_file); tb("inbox", "#0369a1", "Thu bài", self.collect); tb("folderup", "#16a34a", "Nhận bài", self.inbox_dialog); tb("link", "#0d9488", "Gửi link", self.send_link); tb("info", "#2563eb", "Thông báo", self.send_message); tb("block", "#b91c1c", "Chặn web", self.web_dialog); tb("noinstall", "#9a3412", "Chặn cài đặt", self.inst_dialog); sep()
        tb("pc", "#0f766e", "Quản lý phòng", self.rooms_dialog); tb("refresh", "#0ea5e9", "Làm tươi", self.rescan); tb("update", "#16a34a", "Cập nhật", self.update_dialog)
        self.apply_lang()


        bot = tk.Frame(r, bg=CARD); bot.pack(side="bottom", fill="x")
        tk.Frame(bot, bg=BORDER, height=1).pack(fill="x")
        row = tk.Frame(bot, bg=CARD); row.pack(fill="x", padx=10, pady=5)
        tk.Label(row, text=COPYRIGHT, bg=CARD, fg=MUTED, font=(F, 9)).pack(side="right", padx=(12, 0))
        self.status = tk.StringVar(); tk.Label(row, textvariable=self.status, bg=CARD, fg=MUTED, font=(F, 10), anchor="w").pack(side="left")
        tk.Checkbutton(row, text="Ảnh thu nhỏ", variable=self.thumbs, bg=CARD, font=(F, 10), activebackground=CARD, command=self.toggle_thumbs).pack(side="right", padx=6)
        for i, (n, _, _) in reversed(list(enumerate(SIZES))):
            tk.Radiobutton(row, text=n, variable=self.tsize, value=i, bg=CARD, font=(F, 10), activebackground=CARD, command=self.resize).pack(side="right")
        tk.Label(row, text="Cỡ ảnh:", bg=CARD, fg=MUTED, font=(F, 10)).pack(side="right")
        self.rooms = [n for n, _ in room_secrets(cfg) if n]
        self.room_var = tk.StringVar(value="Tất cả")
        self.set_title()
        self.room_cb = ttk.Combobox(row, textvariable=self.room_var, values=["Tất cả"] + self.rooms, state="readonly", width=14, font=(F, 10))
        self.room_cb.bind("<<ComboboxSelected>>", lambda e: self.on_room())
        self.room_lbl = tk.Label(row, text="Phòng:", bg=CARD, fg=MUTED, font=(F, 10))
        self.show_room_filter()

        wrap = tk.Frame(r, bg=BG); wrap.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(wrap, bg=BG, highlightthickness=0)
        sb = tk.Scrollbar(wrap, command=self.canvas.yview); self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); self.canvas.pack(side="left", fill="both", expand=True)
        self.grid_f = tk.Frame(self.canvas, bg=BG); self.win = self.canvas.create_window(0, 0, window=self.grid_f, anchor="nw")
        self.grid_f.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", self.on_resize)
        self.empty = tk.Label(self.canvas, bg=BG, fg=MUTED, font=(F, 13), justify="center",
                              text="Chưa có máy nào kết nối.\nHãy mở ứng dụng trên máy học sinh (cùng mã lớp).")
        for w in (self.canvas, self.grid_f): w.bind("<Button-1>", self.clear_sel)
        r.bind_all("<MouseWheel>", lambda e: self.canvas.yview_scroll(-1 if e.delta > 0 else 1, "units"))
        r.bind_all("<Button-4>", lambda e: self.canvas.yview_scroll(-1, "units"))
        r.bind_all("<Button-5>", lambda e: self.canvas.yview_scroll(1, "units"))
        r.bind("<Control-a>", lambda e: self.select_all())
        r.bind("<F11>", lambda e: r.attributes("-fullscreen", not r.attributes("-fullscreen")))
        r.bind("<F1>", lambda e: self.show_help())
        mb = tk.Menu(r, tearoff=0); hm = tk.Menu(mb, tearoff=0)
        hm.add_command(label="Hướng dẫn sử dụng", accelerator="F1", command=lambda: self.show_help(0))
        hm.add_separator()
        for i, (title, _) in enumerate(TOPICS[1:], 1): hm.add_command(label=title, command=lambda i=i: self.show_help(i))
        mb.add_cascade(label="Hướng dẫn", menu=hm)
        um = tk.Menu(mb, tearoff=0, postcommand=lambda: um.entryconfigure(0, label=self.lic_text()))
        um.add_command(label="", state="disabled"); um.add_separator(); um.add_command(label="Nhập mã mở khóa…", command=self.unlock_dialog)
        mb.add_cascade(label="Mở khóa", menu=um)
        lm = tk.Menu(mb, tearoff=0)                                                    # chọn ngôn ngữ: Tiếng Việt / English (nằm ngay dưới thanh tiêu đề)
        lm.add_radiobutton(label="Tiếng Việt", variable=self.lang_var, value="vi", command=lambda: self.set_lang("vi"))
        lm.add_radiobutton(label="English", variable=self.lang_var, value="en", command=lambda: self.set_lang("en"))
        mb.add_cascade(label="Ngôn ngữ / Language", menu=lm)
        r.configure(menu=mb)
        r.bind("<Escape>", lambda e: r.attributes("-fullscreen", False))
        self.menu = tk.Menu(r, tearoff=0, font=(F, 10))
        items = [("Xem màn hình máy này", "eye", "#7c3aed", lambda: self.share_user(False)),
                 ("Quản lý máy này (ứng dụng, điều khiển)…", "manage", "#0f766e", self.manage),
                 ("Chiếu máy này cho cả lớp", "broadcast", "#0891b2", lambda: self.share_user(True)), None,
                 ("Khóa", "lock", "#ea580c", lambda: self.lock(True)), ("Mở khóa", "unlock", "#16a34a", lambda: self.lock(False)),
                 ("Tắt máy", "power", "#dc2626", self.shutdown), ("Khởi động lại máy", "restart", "#d97706", self.restart), None,
                 ("Gửi file…", "file", "#f59e0b", self.send_file), ("Thu bài", "inbox", "#0369a1", self.collect), ("Gửi link…", "link", "#0d9488", self.send_link), ("Gửi thông báo…", "info", "#2563eb", self.send_message), ("Chặn web xấu…", "block", "#b91c1c", self.web_dialog), ("Chặn cài đặt phần mềm…", "noinstall", "#9a3412", self.inst_dialog)]
        for it in items:
            if it is None: self.menu.add_separator()
            else: self.menu.add_command(label="  " + it[0], image=tkicon(it[1], 18, it[2]), compound="left", command=it[3])

        try:
            self.srv.start()
        except OSError as e:
            messagebox.showerror("Lỗi", f"Không mở được cổng {cfg['port']}: {e}\n(đã có admin khác đang chạy?)"); sys.exit(1)
        self.base = f"Chưa chọn máy nào = áp dụng cho TẤT CẢ máy đang hiện   •   Nhấp đúp để xem màn hình"
        self.refresh(); r.after(150, self.poll); r.protocol("WM_DELETE_WINDOW", self.quit)
        self._lic_busy = False; self.apply_license(); r.after(30000, self.lic_tick)

    # ---------- chuyển ngữ Anh - Việt (chỉ thanh công cụ) ----------
    def apply_lang(self):
        en = self.lang == "en"
        for b, vi in self.tb_btns: b.configure(text=TB_EN[vi] if en else vi)
        self.fit_toolbar_later()

    def fit_toolbar_later(self):
        if self._fit_job is None: self._fit_job = self.root.after(60, self.fit_toolbar)

    def fit_toolbar(self):
        """Cửa sổ hẹp / nhãn dài (tiếng Việt) thì thu nhỏ khoảng cách trong mỗi nút cho vừa 1 hàng, để không nút nào bị che."""
        self._fit_job = None
        w = self.bar.winfo_width()
        if w < 200: return
        for pad in (12, 9, 6, 3, 1):
            for b, _ in self.tb_btns: b.configure(padx=pad)
            self.bar.update_idletasks()
            if self.bar.winfo_reqwidth() <= w: break

    def set_lang(self, lang):
        self.lang = "en" if lang == "en" else "vi"; self.lang_var.set(self.lang); self.apply_lang()
        try:
            with open(LANG_FILE, "w", encoding="utf-8") as f: f.write(self.lang)
        except Exception: pass

    # ---------- chọn máy ----------
    def targets(self):
        cl = self.visible()
        return [c for c in cl if c.id in self.sel] if self.sel else cl

    def visible(self):
        """Máy đang hiển thị theo bộ lọc phòng (mọi lệnh 'tất cả' chỉ áp dụng cho các máy này)."""
        f = self.room_var.get()
        return [c for c in self.srv.snapshot() if f == "Tất cả" or getattr(c, "room", "") == f]

    def info_text(self):
        """IP admin và mã lớp của phòng đang chọn (Tất cả = phòng 1) – hiện trên thanh tiêu đề."""
        rs, f = room_secrets(self.cfg), self.room_var.get()
        ips = local_ips() or [local_ip()]
        code = next((sc for n, sc in rs if n == f), rs[0][1])
        return "IP: " + ", ".join(f"{i}:{self.cfg['port']}" for i in ips) + "   •   Mã lớp: " + code

    def set_title(self):
        s = unlock.status(); tail = f"   •   Còn {unlock.left_text(s['left'])}" if s["state"] == "ok" else "   •   CHƯA MỞ KHÓA (chức năng giới hạn)"
        self.root.title(f"Quản lý phòng máy – ADMIN  (bản {updater.RUN_VER})   •   " + self.info_text() + tail)

    # ---------- quản lý phòng (thêm / đổi tên / xóa, lưu vào config.json) ----------
    def show_room_filter(self):
        """Bộ lọc phòng chỉ hiện khi admin có từ 2 phòng trở lên."""
        self.room_cb.pack_forget(); self.room_lbl.pack_forget()
        if len(self.rooms) > 1:
            self.room_cb.configure(values=["Tất cả"] + self.rooms)
            self.room_cb.pack(side="right", padx=(0, 14)); self.room_lbl.pack(side="right", padx=(0, 4))

    def write_cfg(self, kv):
        """Ghi/đổi vài khóa trong config.json, giữ nguyên các khóa khác."""
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
        try:
            with open(p, encoding="utf-8") as f: disk = json.load(f)
        except FileNotFoundError: disk = {}
        disk.update(kv)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f: json.dump(disk, f, indent=2, ensure_ascii=False)
        os.replace(tmp, p)

    def save_rooms(self, rooms):
        """rooms = [(tên, mã lớp), ...]; phòng đầu tiên là phòng chính. Ghi config.json và áp dụng ngay (không cần mở lại admin)."""
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
        try:
            with open(p, encoding="utf-8") as f: disk = json.load(f)
        except FileNotFoundError: disk = {}
        disk["secret"], disk["room_name"] = rooms[0][1], rooms[0][0]
        disk["rooms"] = [{"name": n, "secret": sc} for n, sc in rooms[1:]]
        if not disk["rooms"]: disk.pop("rooms")
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f: json.dump(disk, f, indent=2, ensure_ascii=False)
        os.replace(tmp, p)
        self.cfg["secret"], self.cfg["room_name"] = disk["secret"], disk["room_name"]
        if disk.get("rooms"): self.cfg["rooms"] = disk["rooms"]
        else: self.cfg.pop("rooms", None)
        keep = {n for n, _ in room_secrets(self.cfg)}
        for c in self.srv.snapshot():                            # máy thuộc phòng đã xóa: ngắt kết nối (máy đó sẽ không nối lại được vì sai mã)
            if getattr(c, "room", "") not in keep:
                try: c.conn.close()
                except Exception: pass
        self.rooms = [n for n, _ in room_secrets(self.cfg) if n]
        if self.room_var.get() != "Tất cả" and self.room_var.get() not in self.rooms: self.room_var.set("Tất cả")
        self.show_room_filter(); self.sel = set(); self.set_title(); self.refresh()

    def rooms_dialog(self):
        rooms = [list(x) for x in room_secrets(self.cfg)]
        for i, rm in enumerate(rooms):
            if not rm[0]: rm[0] = f"Phòng {i + 1}"
        d = tk.Toplevel(self.root); d.title("Quản lý phòng"); d.transient(self.root); d.resizable(False, False); d.configure(bg=BG); d.grab_set()
        tk.Label(d, text="Danh sách phòng máy của admin", bg=BG, font=(self.F, 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(d, text="Mỗi phòng có 1 mã lớp riêng; máy học sinh dùng mã nào thì vào phòng đó. Phòng đầu tiên là phòng chính.", bg=BG, fg=MUTED, justify="left").pack(anchor="w", padx=16)
        tv = ttk.Treeview(d, columns=("name", "code", "n"), show="headings", height=8, selectmode="browse")
        for c, t, w in (("name", "Tên phòng", 190), ("code", "Mã lớp", 170), ("n", "Máy đang nối", 100)): tv.heading(c, text=t); tv.column(c, width=w, anchor="w" if c != "n" else "center")
        tv.pack(padx=16, pady=8)

        def count(name): return sum(1 for c in self.srv.snapshot() if getattr(c, "room", "") == name)
        def fill(sel=0):
            tv.delete(*tv.get_children())
            for i, (n, sc) in enumerate(rooms): tv.insert("", "end", iid=str(i), values=(n + ("  (chính)" if i == 0 else ""), sc, count(n)))
            if rooms: tv.selection_set(str(min(sel, len(rooms) - 1)))
        def cur():
            s = tv.selection(); return int(s[0]) if s else None
        def ask(title, name="", code=""):
            w = tk.Toplevel(d); w.title(title); w.transient(d); w.resizable(False, False); w.configure(bg=BG); w.grab_set()
            vn, vc, out = tk.StringVar(value=name), tk.StringVar(value=code), []
            tk.Label(w, text="Tên phòng:", bg=BG).grid(row=0, column=0, sticky="w", padx=14, pady=(14, 4)); en = tk.Entry(w, textvariable=vn, width=28); en.grid(row=0, column=1, padx=(0, 14), pady=(14, 4))
            tk.Label(w, text="Mã lớp (≥ 3 ký tự):", bg=BG).grid(row=1, column=0, sticky="w", padx=14, pady=4); ec = tk.Entry(w, textvariable=vc, width=28); ec.grid(row=1, column=1, padx=(0, 14), pady=4)
            def ok():
                n, sc = vn.get().strip(), vc.get().strip()
                if not n: return messagebox.showwarning(title, "Hãy nhập tên phòng.", parent=w)
                if len(sc) < 3: return messagebox.showwarning(title, "Mã lớp quá ngắn (cần ≥ 3 ký tự).", parent=w)
                out.extend((n, sc)); w.destroy()
            bf = tk.Frame(w, bg=BG); bf.grid(row=2, column=0, columnspan=2, sticky="e", padx=14, pady=12)
            tk.Button(bf, text="OK", width=8, command=ok).pack(side="right"); tk.Button(bf, text="Hủy", width=8, command=w.destroy).pack(side="right", padx=8)
            w.bind("<Return>", lambda e: ok()); w.bind("<Escape>", lambda e: w.destroy()); en.focus_set(); w.wait_window()
            return tuple(out) or None
        def dup(n, sc, skip=None):
            for i, (a, b) in enumerate(rooms):
                if i == skip: continue
                if a.lower() == n.lower(): return f"Đã có phòng tên \"{a}\"."
                if b == sc: return f"Mã lớp này đang dùng cho phòng \"{a}\"."
        def commit(sel):
            try: self.save_rooms([tuple(x) for x in rooms])
            except Exception as e: return messagebox.showerror("Quản lý phòng", f"Không lưu được config.json:\n{e}", parent=d)
            fill(sel); self.msg = "Đã cập nhật danh sách phòng"; self.refresh()
        def add():
            r = ask("Thêm phòng", f"Phòng {len(rooms) + 1}")
            if not r: return
            e = dup(*r)
            if e: return messagebox.showwarning("Thêm phòng", e, parent=d)
            rooms.append(list(r)); commit(len(rooms) - 1)
        def edit():
            i = cur()
            if i is None: return
            r = ask("Sửa phòng", *rooms[i])
            if not r: return
            e = dup(*r, skip=i)
            if e: return messagebox.showwarning("Sửa phòng", e, parent=d)
            if r[1] != rooms[i][1] and count(rooms[i][0]) and not messagebox.askyesno("Đổi mã lớp", "Đổi mã lớp thì các máy học sinh đang dùng mã cũ sẽ bị ngắt và không nối lại được cho tới khi đổi mã trên máy đó. Tiếp tục?", parent=d): return
            rooms[i] = list(r); commit(i)
        def delete():
            i = cur()
            if i is None: return
            if len(rooms) <= 1: return messagebox.showinfo("Xóa phòng", "Phải còn ít nhất 1 phòng.", parent=d)
            n = count(rooms[i][0])
            msg = f"Xóa phòng \"{rooms[i][0]}\" (mã {rooms[i][1]})?" + (f"\n\nĐang có {n} máy kết nối, các máy này sẽ bị ngắt." if n else "") + ("\n\nĐây là phòng chính; phòng kế tiếp sẽ thành phòng chính." if i == 0 else "")
            if not messagebox.askyesno("Xóa phòng", msg, icon="warning", parent=d): return
            rooms.pop(i); commit(i)
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=(0, 12))
        tk.Button(bf, text="Đóng", width=8, command=d.destroy).pack(side="right")
        tk.Button(bf, text="Xóa phòng", width=11, bg="#b91c1c", fg="white", command=delete).pack(side="left")
        tk.Button(bf, text="Sửa…", width=8, command=edit).pack(side="left", padx=8); tk.Button(bf, text="Thêm…", width=8, command=add).pack(side="left")
        tv.bind("<Double-1>", lambda e: edit()); d.bind("<Delete>", lambda e: delete()); d.bind("<Escape>", lambda e: d.destroy())
        fill()

    def on_room(self):
        self.sel = set(); self.set_title(); self.refresh()

    def rescan(self):
        """Làm tươi: quét lại mạng ngay, bỏ máy mất kết nối, cập nhật danh sách."""
        if getattr(self, "_scanning", False): return
        self._scanning = True; self.msg = "Đang làm tươi: quét lại mạng LAN…"; self.refresh()
        def job():
            try:
                new, now = self.srv.rescan(); n_ip, n_open = self.srv.last_scan
                self.msg = f"Đã làm tươi: {now} máy đang kết nối" + (f" (mới tìm thấy {new})" if new else "") + f"   •   đã quét {n_ip} địa chỉ, {n_open} máy mở cổng {self.cfg.get('agent_port', 5003)}"
                if not now: self.msg += "  → máy user chưa chạy / tường lửa chặn cổng / khác dải mạng"
            except Exception as e: self.msg = f"Làm tươi lỗi: {e}"
            self._scanning = False; self.srv.events.put("list")
        threading.Thread(target=job, daemon=True).start()

    def select_all(self): self.sel = set(self.tiles); self.paint()
    def clear_sel(self, e=None): self.sel = set(); self.paint()

    def click(self, e, cid):
        if e.state & 0x5: self.sel ^= {cid}            # Ctrl / Shift = chọn thêm
        else: self.sel = {cid}
        self.paint()

    def rclick(self, e, cid):
        if cid not in self.sel: self.sel = {cid}; self.paint()
        self.menu.tk_popup(e.x_root, e.y_root)

    # ---------- vẽ lưới ----------
    def blank_img(self, w, h):
        if (w, h) not in self.blank:
            im = tk.PhotoImage(width=w, height=h); im.put("#dfe5f0", to=(0, 0, w, h)); self.blank[(w, h)] = im
        return self.blank[(w, h)]

    def make_tile(self, c):
        t = Tile(c.id); F = self.F; w, h = self.wh()
        t.frame = tk.Frame(self.grid_f, bg=CARD, highlightthickness=3, highlightbackground=BORDER, highlightcolor=BORDER, padx=6, pady=6)
        t.lbl = tk.Label(t.frame, bg=CARD, fg=TEXT, font=(F, 12, "bold"), anchor="w"); t.lbl.pack(fill="x", pady=(0, 5))      # số máy + tên: ở trên cùng
        t.img = tk.Label(t.frame, image=self.blank_img(w, h), bg="#dfe5f0", fg=MUTED, font=(F, 10), compound="center", text="đang chờ ảnh…")
        t.img.pack()
        t.ib = tk.Frame(t.frame, bg=CARD); t.ib.pack(fill="x", pady=(6, 0))                                                    # hàng icon: rê chuột để xem chi tiết
        isz = max(16, int(20 * self.sc))
        t.icons = {}
        for key in ("st", "user", "pc", "app"):
            lb = tk.Label(t.ib, bg=CARD, cursor="hand2", padx=3); lb.pack(side="left", padx=(0, 6)); lb.tip = ""; t.icons[key] = lb
            lb.bind("<Enter>", lambda e, w_=lb: self.tip_show(w_)); lb.bind("<Leave>", lambda e: self.tip_hide())
        t.isz = isz; t.tips = {}
        for w_ in (t.frame, t.img, t.lbl, t.ib, *t.icons.values()):
            w_.bind("<Button-1>", lambda e, i=c.id: self.click(e, i))
            w_.bind("<Double-Button-1>", lambda e, i=c.id: (self.click(e, i), self.share_user(False)))
            w_.bind("<Button-3>", lambda e, i=c.id: self.rclick(e, i)); w_.bind("<Button-2>", lambda e, i=c.id: self.rclick(e, i))
        return t

    # ---------- chú thích khi rê chuột lên icon ----------
    def tip_show(self, w):
        self.tip_hide()
        if not getattr(w, "tip", ""): return
        def pop():
            self._tipw = tw = tk.Toplevel(self.root); tw.overrideredirect(True); tw.attributes("-topmost", True)
            tk.Label(tw, text=w.tip, bg="#111827", fg="white", font=(self.F, 10), justify="left", wraplength=360, padx=10, pady=6).pack()
            tw.geometry(f"+{w.winfo_rootx()}+{w.winfo_rooty() + w.winfo_height() + 4}")
        self._tipj = self.root.after(250, pop)

    def tip_hide(self):
        j, self._tipj = getattr(self, "_tipj", None), None
        if j: self.root.after_cancel(j)
        tw, self._tipw = getattr(self, "_tipw", None), None
        if tw:
            try: tw.destroy()
            except Exception: pass

    def set_icon(self, t, key, name, color, tip):
        lb = t.icons[key]; lb.tip = tip
        k = (name, color)
        if getattr(lb, "ikey", None) != k: lb.ikey = k; lb.configure(image=tkicon(name, t.isz, color))

    @staticmethod
    def tile_text(t):
        return f"{t.no:02d}. {t.name}" if t.no else t.name

    def disp(self, c):
        """Tên hiển thị của máy trong hộp thoại: 'số thứ tự. tên máy'."""
        t = self.tiles.get(c.id)
        return self.tile_text(t) if t and t.no else c.name

    @staticmethod
    def meta_text(c):
        info = (f"[{c.room}]   " if getattr(c, "room", "") else "") + f"{c.ip}   •   {c.os}"
        return f"Tài khoản: {c.user}\n{info}" if getattr(c, "user", "") else info

    @staticmethod
    def state(c):
        return "locked" if c.locked else "share" if c.sharing else "present" if c.presenting else "ready"

    def refresh(self):
        cl = {c.id: c for c in self.visible()}; changed = False
        for i in list(self.tiles):
            if i not in cl: self.tiles.pop(i).frame.destroy(); self.sel.discard(i); changed = True
        for c in cl.values():
            if c.id not in self.tiles: self.tiles[c.id] = self.make_tile(c); changed = True
            t = self.tiles[c.id]
            if t.name != c.name: t.name = c.name; changed = True
            bg, fg, txt = STATUS[self.state(c)]
            t.user = getattr(c, "user", "")
            t.lbl.configure(text=self.tile_text(t))
            icon = {"ready": "dot", "locked": "lock", "present": "present", "share": "eye"}[self.state(c)]
            self.set_icon(t, "st", icon, fg, txt.replace("●", "").strip())
            self.set_icon(t, "user", "user", "#475569", ("Tài khoản: " + c.user) if getattr(c, "user", "") else "Chưa có thông tin tài khoản")
            self.set_icon(t, "pc", "pc", "#475569", ((f"[{c.room}]\n" if getattr(c, "room", "") else "") + f"IP: {c.ip}\nHệ điều hành: {c.os}"))
        if changed: self.layout()
        if cl: self.empty.place_forget()
        else:
            self.empty.configure(text="Chưa có máy nào kết nối.\nHãy mở ứng dụng trên máy học sinh (cùng mã lớp)." if self.room_var.get() == "Tất cả"
                                 else f"Chưa có máy nào của {self.room_var.get()} kết nối.")
            self.empty.place(relx=.5, rely=.4, anchor="center")
        self.paint()
        box = self.srv.inbox
        extra = f"   |   Đang nhận bài vào: {box['dir']} — đã nhận {box['count']} file từ {len(box['machines'])} máy" if box else ""
        bad = self.srv.bad_list()
        warn = f"   |   ⚠ SAI MÃ LỚP: {', '.join(bad[:4])}{'…' if len(bad) > 4 else ''} (cài lại máy đó bằng đúng gói của admin)" if bad else ""
        self.status.set((self.msg or self.base) + extra + warn)

    def paint(self):
        for i, t in self.tiles.items():
            on = i in self.sel
            col, bg = (PRIMARY, SEL_BG) if on else (BORDER, CARD)
            t.frame.configure(highlightbackground=col, highlightcolor=col, bg=bg)
            for w in (t.lbl, t.ib, *t.icons.values()): w.configure(bg=bg)

    # ---------- cỡ ô máy ----------
    def wh(self):
        i = self.tsize.get()
        return (self.fw, self.fh) if i == FIT else (SIZES[i][1], SIZES[i][2])

    def fit_plan(self):
        """Tính số cột + cỡ ảnh để TẤT CẢ máy vừa 1 khung hình (không cuộn). Ưu tiên hiển thị đủ thông tin, máy nhiều thì rút gọn."""
        n = max(1, len(self.tiles)); W = max(300, self.canvas.winfo_width()); H = max(200, self.canvas.winfo_height())
        for lv, extra, minw in (("full", 105, 150), ("compact", 85, 100), ("mini", 40, 40)):
            best = None
            for cols in range(1, n + 1):
                rows = -(-n // cols)
                w = min(W // cols - 34, int((H // rows - extra) / ASPECT))
                if w >= minw and (best is None or w > best[0]): best = (w, cols)
            if best: return best[0], int(best[0] * ASPECT), best[1], lv
        return 40, 25, max(1, min(n, W // 74)), "mini"

    def apply_level(self, t, lv):
        if getattr(t, "lv", None) == lv: return
        t.lv = lv
        t.lbl.configure(font=(self.F, 9 if lv == "mini" else 12, "bold"))
        t.ib.pack_forget()
        if lv != "mini": t.ib.pack(fill="x", pady=(6, 0))

    def req_thumb_width(self, w):
        """Ô máy lớn thì xin máy học sinh gửi ảnh rõ hơn (tối đa 640px)."""
        want = min(640, ((w + 79) // 80) * 80)
        base = self.cfg["thumb_width"]
        want = want if want > base else None
        if want != self.srv.thumb_w:
            self.srv.thumb_w = want
            for c in self.srv.snapshot(): self.srv.thumb_cmd(c)

    def layout(self):
        i = self.tsize.get()
        if i == FIT:
            w, h, self.cols, lv = self.fit_plan()
            changed = (w, h) != (self.fw, self.fh); self.fw, self.fh = w, h
        else:
            w, h = SIZES[i][1], SIZES[i][2]; lv = "full"; changed = False
            self.cols = max(1, self.canvas.winfo_width() // (w + 44))
        for t in self.tiles.values():
            self.apply_level(t, lv)
            if changed:
                t.key = None
                if not t.photo: t.img.configure(image=self.blank_img(w, h))
        self.req_thumb_width(w)
        for n, t in enumerate(sorted(self.tiles.values(), key=lambda t: (nat_key(t.name), t.cid))):
            t.no = n + 1; t.lbl.configure(text=self.tile_text(t))
            t.frame.grid(row=n // self.cols, column=n % self.cols, padx=8, pady=8, sticky="n")

    def on_resize(self, e):
        self.canvas.itemconfigure(self.win, width=e.width)
        if self.tsize.get() == FIT:                 # chờ kéo xong cửa sổ rồi mới tính lại
            if self._rl: self.root.after_cancel(self._rl)
            self._rl = self.root.after(120, self.layout)
        elif max(1, e.width // (SIZES[self.tsize.get()][1] + 44)) != self.cols: self.layout()

    def reset_thumbs(self, text="đang chờ ảnh…"):
        for t in self.tiles.values():
            t.key = None; t.photo = None; t.img.configure(image=self.blank_img(*self.wh()), text=text)

    def resize(self):
        self.layout(); self.reset_thumbs()

    def update_wins(self):
        """Hiện chương trình / web học sinh đang mở dưới mỗi máy; đổi màu đỏ nếu chứa từ khóa trong config 'watch_words'."""
        words = [str(x).lower() for x in self.cfg.get("watch_words", [])]
        for c in self.srv.snapshot():
            t = self.tiles.get(c.id)
            if not t: continue
            txt = (c.app + (" – " + c.title if c.title else "")).strip()
            txt = txt if len(txt) <= 70 else txt[:67] + "…"
            bad = any(x in (c.app + " " + c.title).lower() for x in words)
            key = (txt, bad, c.url)
            if getattr(t, "wkey", None) != key:
                t.wkey = key
                full = (c.app + (" – " + c.title if c.title else "")).strip() + (("\n" + c.url) if c.url else "")
                self.set_icon(t, "app", "app", "#dc2626" if bad else "#475569", (full[:300] + ("\n⚠ Chứa từ khóa cần chú ý" if bad else "")) if full else "Chưa có thông tin cửa sổ đang mở")

    def toggle_thumbs(self):
        self.srv.thumbs_on = self.thumbs.get()
        for c in self.srv.snapshot(): self.srv.thumb_cmd(c)
        if not self.thumbs.get(): self.reset_thumbs("đã tắt ảnh thu nhỏ")

    def compose(self, c, w, h):
        im = Image.open(io.BytesIO(c.thumb)).convert("RGB"); im.thumbnail((w, h)); st = self.state(c)
        if st == "locked":                         # tối ảnh + biểu tượng khóa lớn
            im = Image.blend(im, Image.new("RGB", im.size, (15, 23, 42)), 0.62)
            s = max(24, min(im.size) // 2); ic = render("lock", s, "#f8fafc")
            im.paste(ic, ((im.width - s) // 2, (im.height - s) // 2), ic)
        elif st in ("present", "share"):          # huy hiệu góc phải trên
            s = max(22, min(im.size) // 5); bd = badge("present" if st == "present" else "eye", s, "#ffffff", "#2563eb" if st == "present" else "#7c3aed")
            im.paste(bd, (im.width - s - 6, 6), bd)
        return im

    def update_thumbs(self):
        w, h = self.wh()
        for c in self.srv.snapshot():
            t = self.tiles.get(c.id)
            if not t or not c.thumb or not self.thumbs.get(): continue
            key = (c.thumb_ts, self.state(c), w)
            if key != t.key:
                t.key = key
                try:
                    t.photo = ImageTk.PhotoImage(self.compose(c, w, h)); t.img.configure(image=t.photo, width=w, height=h, text="")
                except Exception: pass

    def poll(self):
        try:
            while True: self.srv.events.get_nowait(); self.refresh()
        except Exception: pass
        self.update_thumbs(); self.update_wins()
        fin, self.collect_done = getattr(self, "collect_done", None), None
        if fin: self.collect_report(fin)
        rd, self.list_ready = getattr(self, "list_ready", None), None
        if rd: self.pick_files(*rd)
        ud, self.upd_done = getattr(self, "upd_done", None), None
        if ud: self.update_finished(*ud)
        pd, self.proc_data = self.proc_data, None
        if pd: self.fill_procs(*pd)
        lt = self.srv.latest
        if self.prev and lt and lt[0] == self.prev_id and lt[1] is not self.prev_last:
            self.prev_last = lt[1]; self.render(lt[1])
        self.root.after(200, self.poll)

    def render(self, data):
        w, h = max(100, self.prev_lbl.winfo_width()), max(100, self.prev_lbl.winfo_height())
        img = Image.open(io.BytesIO(data)); self.prev_img = (img.width, img.height); k = min(w / img.width, h / img.height)
        self.prev_photo = ImageTk.PhotoImage(img.resize((max(1, int(img.width * k)), max(1, int(img.height * k)))))
        self.prev_lbl.configure(image=self.prev_photo)

    # ---------- chức năng ----------
    def lock(self, on):
        for c in self.targets(): c.send(cmd="lock" if on else "unlock"); c.locked = on
        self.refresh()

    def shutdown(self):
        tg = self.targets()
        if tg and messagebox.askyesno("Tắt máy", f"Tắt NGAY {len(tg)} máy?\nMáy học sinh sẽ mất dữ liệu chưa lưu."):
            for c in tg: c.send(cmd="shutdown", delay=0)
            self.msg = f"Đã gửi lệnh tắt máy tới {len(tg)} máy"; self.refresh()

    def restart(self):
        tg = self.targets()
        if tg and messagebox.askyesno("Khởi động lại", f"Khởi động lại NGAY {len(tg)} máy?\nMáy học sinh sẽ mất dữ liệu chưa lưu."):
            for c in tg: c.send(cmd="restart", delay=0)
            self.msg = f"Đã gửi lệnh khởi động lại tới {len(tg)} máy"; self.refresh()

    def send_message(self):
        tg = self.targets()
        if not tg: return
        d = tk.Toplevel(self.root); d.title("Gửi thông báo"); d.transient(self.root); d.resizable(False, False); d.configure(bg=BG)
        tk.Label(d, text=f"Gửi thông báo tới {len(tg)} máy", bg=BG, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        t = tk.Text(d, width=52, height=4, wrap="word"); t.pack(padx=16, pady=6); t.focus_set()
        quick = tk.Frame(d, bg=BG); quick.pack(anchor="w", padx=16)
        for txt in ("Hãy tập trung làm bài.", "Dừng chơi game, quay lại bài học.", "Còn 5 phút nữa."):
            tk.Button(quick, text=txt, command=lambda x=txt: (t.delete("1.0", "end"), t.insert("1.0", x))).pack(side="left", padx=(0, 4))

        def go():
            m = t.get("1.0", "end").strip()[:300]
            if not m: return
            for c in self.targets(): c.send(cmd="message", text=m)
            self.msg = f"Đã gửi thông báo tới {len(tg)} máy"; d.destroy(); self.refresh()
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=12)
        tk.Button(bf, text="Gửi", width=10, command=go).pack(side="right")
        tk.Button(bf, text="Hủy", width=8, command=d.destroy).pack(side="right", padx=8)
        d.bind("<Escape>", lambda ev: d.destroy())

    def send_link(self):
        tg = self.targets()
        if not tg: return
        d = tk.Toplevel(self.root); d.title("Gửi link / mở web"); d.transient(self.root); d.resizable(False, False); d.configure(bg=BG)
        tk.Label(d, text=f"Gửi tới {len(tg)} máy", bg=BG, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(d, text="Địa chỉ web:", bg=BG).pack(anchor="w", padx=16)
        v_url = tk.StringVar(); e = tk.Entry(d, textvariable=v_url, width=56); e.pack(padx=16, pady=(2, 8)); e.focus_set()
        v_mode = tk.StringVar(value="auto")
        tk.Radiobutton(d, text="Mở ngay trên máy học sinh (web tự chạy luôn)", variable=v_mode, value="auto", bg=BG).pack(anchor="w", padx=16)
        tk.Radiobutton(d, text="Chỉ gửi link – học sinh tự nhấp vào để mở", variable=v_mode, value="click", bg=BG).pack(anchor="w", padx=16)
        v_here = tk.BooleanVar(value=False)
        tk.Checkbutton(d, text="Mở luôn trang này trên máy admin", variable=v_here, bg=BG).pack(anchor="w", padx=16, pady=(6, 0))

        def go(ev=None):
            u = v_url.get().strip()
            if not u: return
            if "://" not in u: u = "https://" + u
            p = urlparse(u)
            if p.scheme not in ("http", "https") or not p.netloc:
                return messagebox.showwarning("Link", "Chỉ hỗ trợ link http/https hợp lệ.", parent=d)
            auto = v_mode.get() == "auto"
            for c in self.targets(): c.send(cmd="open_url" if auto else "show_link", url=u)
            if v_here.get(): webbrowser.open(u)
            self.msg = f"Đã {'mở web trên' if auto else 'gửi link tới'} {len(tg)} máy"; d.destroy(); self.refresh()
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=12)
        tk.Button(bf, text="Gửi", width=10, command=go).pack(side="right")
        tk.Button(bf, text="Hủy", width=8, command=d.destroy).pack(side="right", padx=8)
        d.bind("<Return>", go); d.bind("<Escape>", lambda ev: d.destroy())

    def web_dialog(self):
        tg = self.targets()
        if not tg: return
        pol = self.srv.web
        d = tk.Toplevel(self.root); d.title("Chặn web xấu / không an toàn"); d.transient(self.root); d.resizable(False, False); d.configure(bg=BG)
        tk.Label(d, text=f"Áp dụng cho {len(tg)} máy", bg=BG, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(d, text="Chọn nhóm trang web cần chặn:", bg=BG).pack(anchor="w", padx=16)
        vc = {}
        for k, (label, doms, _) in webblock.CATEGORIES.items():
            vc[k] = tk.BooleanVar(value=k in pol["cats"])
            tk.Checkbutton(d, text=f"{label}  ({len(doms)} trang)", variable=vc[k], bg=BG).pack(anchor="w", padx=26)
        vh = tk.BooleanVar(value=pol["https"])
        tk.Checkbutton(d, text="Chặn / cảnh báo trang http không an toàn (Chrome, Edge, Brave)", variable=vh, bg=BG).pack(anchor="w", padx=16, pady=(8, 0))
        # --- trang học sinh đang xem: sao chép link / đưa thẳng vào danh sách chặn ---
        tk.Label(d, text="Trang học sinh đang mở / vừa mở (tự cập nhật) – chọn dòng rồi sao chép hoặc thêm vào danh sách chặn:", bg=BG).pack(anchor="w", padx=16, pady=(8, 0))
        lf = tk.Frame(d, bg=BG); lf.pack(padx=16, pady=(2, 2), fill="x")
        lb = tk.Listbox(lf, width=92, height=7, selectmode="extended", exportselection=False, activestyle="none")
        lsb = tk.Scrollbar(lf, command=lb.yview); lb.configure(yscrollcommand=lsb.set); lb.pack(side="left", fill="x", expand=True); lsb.pack(side="left", fill="y")
        rows = []                                                    # [(máy, tiêu đề, link)] đang hiện trong lb

        def pages_now():
            out, seen = [], set()
            for c in tg:
                for _, ttl, u in reversed(list(c.pages)):
                    if (c.id, u) not in seen: seen.add((c.id, u)); out.append((c.name, ttl, u))
            return out[:80]

        def fill():
            if not lb.winfo_exists(): return
            new = pages_now()
            if new != rows:
                keep = {rows[i][2] for i in lb.curselection() if i < len(rows)}
                rows[:] = new; lb.delete(0, "end")
                for n, ttl, u in rows: lb.insert("end", f"{n}  •  {(ttl[:34] + '…') if len(ttl) > 35 else ttl}  •  {u[:90]}")
                for i, r in enumerate(rows):
                    if r[2] in keep: lb.selection_set(i)
                if not rows: lb.insert("end", "(chưa có trang nào – cần máy học sinh đã dùng trình duyệt Chrome / Edge / Brave / Firefox)")
            d.after(2000, fill)

        def picked():
            return [rows[i] for i in lb.curselection() if i < len(rows)]

        def copy_links():
            ps = picked()
            if not ps: return messagebox.showinfo("Sao chép link", "Hãy chọn một hoặc nhiều dòng trong danh sách.", parent=d)
            d.clipboard_clear(); d.clipboard_append("\n".join(dict.fromkeys(r[2] for r in ps))); d.update()
            self.msg = f"Đã sao chép {len(set(r[2] for r in ps))} link"; self.refresh()

        def add_black(whole=False):
            ps = picked()
            if not ps: return messagebox.showinfo("Thêm vào danh sách chặn", "Hãy chọn một hoặc nhiều dòng trong danh sách.", parent=d)
            have = {x.strip().lower() for x in tx.get("1.0", "end").splitlines()}
            add = []
            for _, _, u in ps:
                e = u if whole else webblock.url_host(u)
                if e and e.lower() not in have and e not in add: add.append(e)
            if add:
                cur = tx.get("1.0", "end").strip()
                tx.insert("end", ("\n" if cur else "") + "\n".join(add)); tx.see("end")
            self.msg = (f"Đã thêm {len(add)} mục vào danh sách chặn – bấm Bật chặn để áp dụng" if add else "Các mục này đã có trong danh sách chặn"); self.refresh()
        bl = tk.Frame(d, bg=BG); bl.pack(anchor="w", padx=16, pady=(0, 2))
        tk.Button(bl, text="Sao chép link", command=copy_links).pack(side="left")
        tk.Button(bl, text="Thêm trang vào danh sách chặn", command=lambda: add_black(False)).pack(side="left", padx=6)
        tk.Button(bl, text="Thêm đúng link này", command=lambda: add_black(True)).pack(side="left")
        lb.bind("<Double-Button-1>", lambda ev: copy_links())
        fill()
        tk.Label(d, text="Chặn thêm – mỗi dòng 1 tên miền hoặc từ khóa (vd: tiktok.com, cờ bạc):", bg=BG).pack(anchor="w", padx=16, pady=(8, 0))
        tx = tk.Text(d, width=56, height=5); tx.pack(padx=16, pady=(2, 6)); tx.insert("1.0", "\n".join(pol["custom"]))
        tk.Label(d, text="Máy học sinh sẽ đóng tab trang bị chặn. Chặn tận gốc (trình duyệt / hosts) khi máy cho phép.\nMất kết nối với admin hoặc bấm Tắt chặn thì gỡ hết.",
                 bg=BG, fg=MUTED, justify="left").pack(anchor="w", padx=16)

        def apply(on):
            p = webblock.clean_policy({"on": on, "cats": [k for k, v in vc.items() if v.get()], "https": vh.get(),
                                       "custom": [x.strip() for x in tx.get("1.0", "end").splitlines() if x.strip()]})
            if on and not (p["cats"] or p["custom"]):
                return messagebox.showwarning("Chặn web", "Hãy chọn ít nhất một nhóm hoặc nhập trang cần chặn.", parent=d)
            self.srv.web = p; webblock.save(p)
            for c in self.targets(): c.send(cmd="webblock", policy=p)
            self.msg = f"Đã {'bật chặn web trên' if on else 'tắt chặn web trên'} {len(tg)} máy"; d.destroy(); self.refresh()
            self.root.after(3000, lambda: self.web_report(tg, on))
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=12)
        tk.Button(bf, text="Bật chặn", width=11, bg="#b91c1c", fg="white", command=lambda: apply(True)).pack(side="right")
        tk.Button(bf, text="Tắt chặn", width=10, command=lambda: apply(False)).pack(side="right", padx=8)
        tk.Button(bf, text="Đóng", width=8, command=d.destroy).pack(side="right")
        d.bind("<Escape>", lambda ev: d.destroy())

    def inst_dialog(self):
        """Chặn học sinh chạy file cài đặt (setup, install, .msi, bộ cài đổi tên...). Mặc định BẬT trên mọi máy; không cần mã mở khóa."""
        tg = self.targets()
        if not tg: return
        pol, whole = self.srv.inst, not self.sel
        d = tk.Toplevel(self.root); d.title("Chặn cài đặt phần mềm"); d.transient(self.root); d.resizable(False, False); d.configure(bg=BG)
        tk.Label(d, text=f"Áp dụng cho {len(tg)} máy", bg=BG, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        on_n = sum(1 for c in tg if c.inst and c.inst[0])
        tk.Label(d, text=f"Chính sách đang lưu: {'BẬT' if pol['on'] else 'TẮT'}   •   {on_n}/{len(tg)} máy đang chặn", bg=BG, fg="#b91c1c" if pol["on"] else MUTED,
                 font=("TkDefaultFont", 10, "bold")).pack(anchor="w", padx=16)
        tk.Label(d, text="Khi BẬT, học sinh không chạy được file cài đặt (setup, install, unins, .msi, bộ cài đã đổi tên…).\nMáy học sinh tự đóng bộ cài ngay khi mở và báo học sinh; vẫn chặn khi mất kết nối admin.",
                 bg=BG, justify="left").pack(anchor="w", padx=16, pady=(6, 4))
        tk.Label(d, text="Cho phép riêng – mỗi dòng 1 tên file (vd: setup-phanmem-truong.exe):", bg=BG).pack(anchor="w", padx=16, pady=(4, 0))
        tx = tk.Text(d, width=64, height=3); tx.pack(padx=16, pady=(2, 6)); tx.insert("1.0", "\n".join(pol["allow"]))
        tk.Label(d, text="Nhật ký các lần cố cài đặt gần đây (mới nhất ở trên):", bg=BG).pack(anchor="w", padx=16)
        fr = tk.Frame(d, bg=BG); fr.pack(padx=16, pady=(2, 4))
        lg = tk.Text(fr, width=64, height=8, wrap="none"); sb = tk.Scrollbar(fr, command=lg.yview); lg.configure(yscrollcommand=sb.set)
        lg.pack(side="left"); sb.pack(side="left", fill="y")
        rows = [f"{time.strftime('%H:%M:%S', time.localtime(t))}  {n}{(' (' + u + ')') if u else ''}  →  {f}  {'[đã đóng]' if ok else '[KHÔNG đóng được]'}"
                for t, n, u, f, ok in reversed(list(self.srv.inst_log))]
        lg.insert("1.0", "\n".join(rows) if rows else "(chưa có lần nào)"); lg.configure(state="disabled")
        tk.Label(d, text="Bỏ chọn máy (áp dụng tất cả) thì chính sách được lưu và máy nối lại sau cũng nhận.\nChỉ chọn một số máy thì chỉ áp dụng cho các máy đó, không đổi chính sách đã lưu.",
                 bg=BG, fg=MUTED, justify="left").pack(anchor="w", padx=16, pady=(2, 0))

        def apply(on):
            p = webblock.clean_inst({"on": on, "allow": [x.strip() for x in tx.get("1.0", "end").splitlines() if x.strip()]})
            if whole: self.srv.inst = p; webblock.inst_save(p)
            for c in tg: c.send(cmd="installblock", policy=p)
            self.msg = f"Đã {'bật chặn cài đặt trên' if on else 'tắt chặn cài đặt trên'} {len(tg)} máy"; d.destroy(); self.refresh()
            self.root.after(3000, lambda: self.inst_report(tg, on))
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=12)
        tk.Button(bf, text="Bật chặn", width=11, bg="#b91c1c", fg="white", command=lambda: apply(True)).pack(side="right")
        tk.Button(bf, text="Tắt chặn", width=10, command=lambda: apply(False)).pack(side="right", padx=8)
        tk.Button(bf, text="Đóng", width=8, command=d.destroy).pack(side="right")
        d.bind("<Escape>", lambda ev: d.destroy())

    def inst_report(self, tg, on):
        """Sau vài giây báo máy nào đã xác nhận; máy không trả lời thường đang chạy bản cũ; máy có \"install_block\": false trong config thì không chặn được."""
        miss = [c.name for c in tg if c.inst is None or c.inst[0] != on]
        off = [c.name for c in tg if c.inst and c.inst[2] and on]
        txt = f"Chặn cài đặt: {len(tg) - len(miss)}/{len(tg)} máy đã {'bật' if on else 'tắt'}"
        if miss: txt += " • CHƯA xác nhận: " + ", ".join(miss[:6]) + ("…" if len(miss) > 6 else "") + " (chạy bản cũ? bấm Cập nhật)"
        if off: txt += " • Đã tắt trong config.json của máy: " + ", ".join(off[:6])
        self.msg = txt; self.refresh()

    def web_report(self, tg, on):
        """Sau vài giây báo máy nào đã xác nhận bật/tắt chặn web; máy không trả lời thường đang chạy bản cũ (chưa có tính năng này)."""
        miss = [c.name for c in tg if c.web is None or c.web[0] != on]
        txt = f"Chặn web: {len(tg) - len(miss)}/{len(tg)} máy đã {'bật' if on else 'tắt'}"
        if miss: txt += " • CHƯA xác nhận: " + ", ".join(miss[:6]) + ("…" if len(miss) > 6 else "") + " (chạy bản cũ? bấm Cập nhật)"
        self.msg = txt; self.refresh()

    def send_file(self):
        paths = filedialog.askopenfilenames(title="Chọn file gửi xuống máy user"); tg = self.targets()
        if not paths or not tg: return
        d = tk.Toplevel(self.root); d.title("Gửi file"); d.transient(self.root); d.resizable(False, False); d.configure(bg=BG)
        tk.Label(d, text=f"Gửi {len(paths)} file tới {len(tg)} máy", bg=BG, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(d, text="Lưu vào thư mục (trên máy học sinh):", bg=BG).pack(anchor="w", padx=16)
        vd = tk.StringVar(value=DEFAULT_FOLDER)
        for k, txt in FOLDERS.items(): tk.Radiobutton(d, text=txt, variable=vd, value=k, bg=BG).pack(anchor="w", padx=26)

        def go(ev=None):
            dest = vd.get(); d.destroy()
            done = {"ok": 0, "bad": 0}; lk = threading.Lock()
            def report(ok, c):
                with lk:
                    done["ok" if ok else "bad"] += 1
                    self.msg = f"Gửi file: xong {done['ok']}/{len(tg)} máy" + (f", lỗi {done['bad']}" if done["bad"] else "")
                    self.srv.events.put("list")
            self.msg = f"Đang gửi {len(paths)} file tới {len(tg)} máy…"; self.refresh()
            for c in tg: threading.Thread(target=Server.send_files, args=(c, paths, report, dest), daemon=True).start()
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=12)
        tk.Button(bf, text="Gửi", width=10, command=go).pack(side="right")
        tk.Button(bf, text="Hủy", width=8, command=d.destroy).pack(side="right", padx=8)
        d.bind("<Return>", go); d.bind("<Escape>", lambda ev: d.destroy())

    def collect(self):
        if not self.sel:
            return messagebox.showinfo("Thu bài", "Hãy bấm chọn máy học sinh cần thu bài (giữ Ctrl để chọn nhiều máy).")
        tg = self.targets()
        if not tg: return
        d = tk.Toplevel(self.root); d.title("Thu bài làm"); d.transient(self.root); d.resizable(False, False); d.configure(bg=BG)
        tk.Label(d, text=f"Thu bài của {len(tg)} máy", bg=BG, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(d, text="Loại file cần thu:", bg=BG).pack(anchor="w", padx=16)
        vk = {k: tk.BooleanVar(value=True) for k in KINDS}
        for k, (name, ex) in KINDS.items():
            tk.Checkbutton(d, text=f"{name}  ({', '.join(e[1:] for e in ex[:5])}…)", variable=vk[k], bg=BG).pack(anchor="w", padx=26)
        tk.Label(d, text="Thu bài trong thư mục (trên máy học sinh):", bg=BG).pack(anchor="w", padx=16, pady=(8, 0))
        vf = {k: tk.BooleanVar(value=(k == DEFAULT_FOLDER)) for k in FOLDERS}
        for k, txt in FOLDERS.items(): tk.Checkbutton(d, text=txt, variable=vf[k], bg=BG).pack(anchor="w", padx=26)
        tk.Label(d, text="Chỉ thu file được lưu trong:", bg=BG).pack(anchor="w", padx=16, pady=(8, 0))
        vh = tk.DoubleVar(value=2)
        for txt, h in (("1 giờ qua", 1), ("2 giờ qua", 2), ("4 giờ qua", 4), ("24 giờ qua", 24), ("Tất cả file (không giới hạn thời gian)", 0)):
            tk.Radiobutton(d, text=txt, variable=vh, value=h, bg=BG).pack(anchor="w", padx=26)
        tk.Label(d, text="Bước sau: xem danh sách file và tick đúng file cần thu.\nHọc sinh sẽ thấy thông báo \"Giáo viên đang thu bài\".",
                 bg=BG, fg=MUTED, justify="left").pack(anchor="w", padx=16, pady=(8, 0))

        def go(ev=None):
            kinds = [k for k, v in vk.items() if v.get()]
            if not kinds: return messagebox.showwarning("Thu bài", "Hãy chọn ít nhất một loại file.", parent=d)
            folders = [k for k, v in vf.items() if v.get()]
            if not folders: return messagebox.showwarning("Thu bài", "Hãy chọn ít nhất một thư mục.", parent=d)
            hours = vh.get(); d.destroy(); self.list_for_collect(tg, kinds, hours, folders)
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=12)
        tk.Button(bf, text="Xem file…", width=10, command=go).pack(side="right")
        tk.Button(bf, text="Hủy", width=8, command=d.destroy).pack(side="right", padx=8)
        d.bind("<Return>", go); d.bind("<Escape>", lambda ev: d.destroy())

    def open_folder(self, folder):
        try:
            if os.name == "nt": os.startfile(folder)
            else: subprocess.Popen(["xdg-open", folder])
        except Exception: pass

    # ---------- nhận bài: học sinh tự nộp file vào thư mục admin chọn ----------
    def inbox_dialog(self):
        box = self.srv.inbox
        d = tk.Toplevel(self.root); d.title("Nhận bài"); d.transient(self.root); d.resizable(False, False); d.configure(bg=BG)
        if box:
            tk.Label(d, text=f"Đang nhận bài: {box['title']}", bg=BG, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
            tk.Label(d, text=f"Thư mục: {box['dir']}\nĐã nhận {box['count']} file từ {len(box['machines'])} máy.\nMỗi máy có một thư mục con riêng (tên máy).", bg=BG, justify="left").pack(anchor="w", padx=16, pady=4)
            def stop():
                info = self.srv.close_inbox(); d.destroy()
                self.msg = f"Đã đóng nhận bài – nhận {info['count']} file từ {len(info['machines'])} máy"; self.refresh()
                if messagebox.askyesno("Nhận bài", f"Đã nhận {info['count']} file từ {len(info['machines'])} máy.\nMở thư mục bài nộp?"): self.open_folder(info["dir"])
            bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=12)
            tk.Button(bf, text="Đóng nhận bài", width=14, command=stop).pack(side="right")
            tk.Button(bf, text="Mở thư mục", width=12, command=lambda: self.open_folder(box["dir"])).pack(side="right", padx=8)
            tk.Button(bf, text="Thoát", width=8, command=d.destroy).pack(side="right")
            return
        tk.Label(d, text="Mở nhận bài", bg=BG, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(d, text="Học sinh trên các máy đang kết nối sẽ thấy cửa sổ “Nộp bài”\nvà gửi file thẳng vào thư mục dưới đây (không cần chia sẻ thư mục Windows).", bg=BG, justify="left", fg=MUTED).pack(anchor="w", padx=16)
        tk.Label(d, text="Tên bài nộp (học sinh thấy):", bg=BG).pack(anchor="w", padx=16, pady=(10, 0))
        vt = tk.StringVar(value="Nộp bài " + time.strftime("%d/%m")); e1 = tk.Entry(d, textvariable=vt, width=56); e1.pack(padx=16, pady=2); e1.focus_set()
        tk.Label(d, text="Thư mục lưu bài nộp (trên máy admin):", bg=BG).pack(anchor="w", padx=16, pady=(8, 0))
        vd = tk.StringVar(value=os.path.join(os.path.expanduser("~"), "NopBai", time.strftime("%Y-%m-%d_%H%M")))
        row = tk.Frame(d, bg=BG); row.pack(fill="x", padx=16, pady=2)
        tk.Entry(row, textvariable=vd, width=48).pack(side="left")
        def pick():
            p = filedialog.askdirectory(parent=d, title="Chọn hoặc tạo thư mục nhận bài", initialdir=os.path.expanduser("~"))
            if p: vd.set(os.path.normpath(p))
        tk.Button(row, text="Chọn…", command=pick).pack(side="left", padx=6)
        tk.Label(d, text="Thư mục chưa có sẽ được tạo tự động. Bài nộp trùng tên không bị ghi đè.", bg=BG, fg=MUTED).pack(anchor="w", padx=16)
        def go(ev=None):
            folder, title = vd.get().strip(), vt.get().strip() or "Nộp bài"
            if not folder: return messagebox.showwarning("Nhận bài", "Hãy nhập thư mục lưu bài.", parent=d)
            try: self.srv.open_inbox(folder, title)
            except OSError as e: return messagebox.showerror("Nhận bài", f"Không tạo được thư mục:\n{e}", parent=d)
            n = len(self.srv.snapshot()); d.destroy()
            self.msg = f"Đã mở nhận bài cho {n} máy: {title}"; self.refresh()
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=12)
        tk.Button(bf, text="Mở nhận bài", width=14, command=go).pack(side="right")
        tk.Button(bf, text="Hủy", width=8, command=d.destroy).pack(side="right", padx=8)
        d.bind("<Return>", go); d.bind("<Escape>", lambda ev: d.destroy())

    def list_for_collect(self, tg, kinds, hours, folders):
        """Bước 1: hỏi từng máy danh sách file phù hợp (chưa tải nội dung)."""
        res, lk, st, n = {}, threading.Lock(), {"done": False}, len(tg)
        def fin():
            if not st["done"]: st["done"] = True; self.list_ready = (list(res.values()), n, kinds, hours, folders)
        def cb(c, files):
            with lk:
                res[c.id] = (c, files)
                if len(res) >= n: fin()
        def timeout():
            with lk: fin()
        self.msg = f"Đang lấy danh sách file của {n} máy…"; self.refresh()
        for c in tg: c.list_cb = cb; c.send(cmd="collect_list", kinds=kinds, hours=hours, folders=folders)
        t = threading.Timer(20, timeout); t.daemon = True; t.start()

    def pick_files(self, results, n, kinds, hours, folders):
        """Bước 2: admin tick từng file cần thu, chỉ những file đó mới được tải về."""
        results = [(c, f) for c, f in results if f]
        self.msg = ""; self.refresh()
        if not results:
            return messagebox.showinfo("Thu bài", "Không có file phù hợp trên các máy đã chọn.\n(Thử chọn thêm thư mục / loại file / kéo dài thời gian.)")
        d = tk.Toplevel(self.root); d.title("Chọn file cần thu"); d.geometry("700x540"); d.transient(self.root); d.configure(bg=BG)
        tk.Label(d, text="Tick đúng những file cần thu (mặc định chưa chọn file nào):", bg=BG, font=("TkDefaultFont", 10, "bold")).pack(anchor="w", padx=14, pady=(12, 4))
        bf = tk.Frame(d, bg=BG); bf.pack(side="bottom", fill="x", padx=14, pady=10)
        wrap = tk.Frame(d, bg=BG); wrap.pack(fill="both", expand=True, padx=14)
        cv = tk.Canvas(wrap, bg=BG, highlightthickness=0); sb = tk.Scrollbar(wrap, command=cv.yview); cv.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); cv.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(cv, bg=BG); cv.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        d.bind("<MouseWheel>", lambda e: cv.yview_scroll(int(-e.delta / 120) if e.delta else 0, "units"))
        d.bind("<Button-4>", lambda e: cv.yview_scroll(-1, "units")); d.bind("<Button-5>", lambda e: cv.yview_scroll(1, "units"))
        def human(b): return f"{b / 1048576:.1f} MB" if b >= 1048576 else f"{max(1, b // 1024)} KB"
        vs, cnt = {}, tk.StringVar()
        def recount(*_): cnt.set(f"Đã chọn {sum(v.get() for v in vs.values())} file")
        for c, files in sorted(results, key=lambda r: nat_key(r[0].name)):
            lf = tk.LabelFrame(inner, text=f" {self.disp(c)}  ({c.ip}) – {len(files)} file ", bg=BG); lf.pack(fill="x", pady=4, padx=2)
            mine = []
            row = tk.Frame(lf, bg=BG); row.pack(anchor="w")
            for arc, size, mt in files:
                v = tk.BooleanVar(value=False); v.trace_add("write", recount); vs[(c.id, arc)] = v; mine.append(v)
                tk.Checkbutton(lf, text=f"{arc}    ({human(int(size))} • {time.strftime('%H:%M %d/%m', time.localtime(mt))})", variable=v, bg=BG, anchor="w").pack(anchor="w", padx=6)
            tk.Button(row, text="Chọn hết máy này", command=lambda m=mine: [x.set(True) for x in m]).pack(side="left", padx=6, pady=2)
            tk.Button(row, text="Bỏ chọn", command=lambda m=mine: [x.set(False) for x in m]).pack(side="left")
        recount()
        miss = n - len(results)
        tk.Label(bf, textvariable=cnt, bg=BG, fg=MUTED).pack(side="left")
        def go(ev=None):
            by = {}
            for (cid, arc), v in vs.items():
                if v.get(): by.setdefault(cid, []).append(arc)
            if not by: return messagebox.showwarning("Thu bài", "Hãy tick ít nhất một file.", parent=d)
            d.destroy()
            tg = [c for c, _ in results if c.id in by]
            self.start_collect(tg, kinds, hours, folders, by)
        tk.Button(bf, text="Thu file đã chọn", width=16, command=go).pack(side="right")
        tk.Button(bf, text="Hủy", width=8, command=d.destroy).pack(side="right", padx=8)
        if miss > 0: messagebox.showinfo("Thu bài", f"{miss} máy không có file phù hợp hoặc không phản hồi.", parent=d)

    def start_collect(self, tg, kinds, hours, folders=None, files=None):
        base = os.path.expanduser(self.cfg.get("collect_dir", "~/ThuBai"))
        folder = os.path.join(base, time.strftime("%Y-%m-%d_%H%M%S")); os.makedirs(folder, exist_ok=True)
        st = {"ok": 0, "bad": 0, "empty": 0, "skipped": 0, "files": 0, "done": False}; lk = threading.Lock(); n = len(tg)
        def finish():
            if not st["done"]: st["done"] = True; self.collect_done = (folder, dict(st), n)
        def cb(status, c, info=""):
            with lk:
                st[status] += 1
                if status == "ok":
                    try: st["skipped"] += int(info.split("|")[0] or 0); st["files"] += int(info.split("|")[1] or 0)
                    except (ValueError, IndexError): pass
                self.msg = f"Thu bài: nhận {st['ok']}/{n} máy" + (f", trống {st['empty']}" if st["empty"] else "") + (f", lỗi {st['bad']}" if st["bad"] else "")
                if st["ok"] + st["empty"] + st["bad"] >= n: finish()
            self.srv.events.put("list")
        def timeout():
            with lk:
                st["bad"] += n - st["ok"] - st["empty"] - st["bad"]; finish()
            self.srv.events.put("list")
        self.msg = f"Đang thu bài của {n} máy…"; self.refresh()
        for c in tg: c.sub = {"dir": folder, "cb": cb}; c.send(cmd="collect", kinds=kinds, hours=hours, folders=folders, files=(files or {}).get(c.id))
        t = threading.Timer(300, timeout); t.daemon = True; t.start()

    def collect_report(self, fin):
        folder, st, n = fin
        txt = f"Đã nhận {st['files']} file từ {st['ok']}/{n} máy."
        if st["empty"]: txt += f"\n{st['empty']} máy không có file phù hợp."
        if st["bad"]: txt += f"\n{st['bad']} máy lỗi hoặc không phản hồi."
        if st["skipped"]: txt += f"\n{st['skipped']} file bị bỏ qua (đang mở/khóa hoặc vượt dung lượng)."
        if st["ok"] and messagebox.askyesno("Thu bài xong", txt + f"\n\nLưu tại:\n{folder}\n\nMở thư mục này?"):
            try:
                if os.name == "nt": os.startfile(folder)
                else: subprocess.Popen(["xdg-open", folder])
            except Exception: pass
        elif not st["ok"]: messagebox.showinfo("Thu bài", txt)

    def present_admin(self):
        tg = self.targets()
        if not tg: return
        self.stop_all(); ids = [c.id for c in tg]
        for c in tg: c.send(cmd="present_start"); c.presenting = True
        def send(d):
            for i in ids:
                c = self.srv.clients.get(i)
                if c: c.conn.send_frame(T_FRAME, d)
        self.stop_ev = threading.Event()
        threading.Thread(target=stream_loop, args=(send, self.stop_ev, self.cfg["fps"], self.cfg["present_width"], self.cfg["quality"]), daemon=True).start()   # độ rộng ảnh chiếu (giảm nếu mạng yếu)
        self.msg = f"Đang chiếu màn hình admin tới {len(tg)} máy"; self.refresh()

    def share_user(self, relay):
        if len(self.sel) != 1: return messagebox.showinfo("Chọn máy", "Hãy bấm chọn đúng 1 máy.")
        cid = next(iter(self.sel)); self.stop_all()
        cl = {c.id: c for c in self.srv.snapshot()}; c = cl.get(cid)
        if not c: return
        c.send(cmd="share_start", fps=self.cfg["fps"], width=self.cfg["width"], quality=self.cfg["quality"]); c.sharing = True
        if relay:
            others = [o for o in cl.values() if o.id != c.id]
            for o in others: o.send(cmd="present_start"); o.presenting = True
            self.srv.relay_dst = [o.id for o in others]; self.srv.relay_src = c.id
            self.msg = f"Đang chiếu màn hình '{self.disp(c)}' tới {len(others)} máy"
        else:
            self.msg = f"Đang xem màn hình '{self.disp(c)}'"
        self.prev_id, self.prev_last = c.id, None
        self.prev = tk.Toplevel(self.root); self.prev.title(f"Màn hình: {self.disp(c)}"); self.prev.geometry("960x600")
        if not relay:
            bar = tk.Frame(self.prev, bg=CARD); bar.pack(fill="x")
            self.rc_btn = tk.Button(bar, text="Điều khiển chuột / bàn phím: TẮT", command=self.toggle_rc, relief="groove", padx=10)
            self.rc_btn.pack(side="left", padx=6, pady=4)
            tk.Button(bar, text="Ứng dụng đang chạy…", command=lambda: self.manage(c.id), relief="groove", padx=10).pack(side="left", pady=4)
            tk.Label(bar, text="Bật điều khiển rồi dùng chuột / bàn phím ngay trong khung ảnh. F11: toàn màn hình", bg=CARD, fg=MUTED).pack(side="left", padx=10)
        self.prev_lbl = tk.Label(self.prev, bg="black"); self.prev_lbl.pack(fill="both", expand=True)
        pv, L = self.prev, self.prev_lbl
        def tog(e=None):
            if not self.rc_on: pv.attributes("-fullscreen", not pv.attributes("-fullscreen"))
        pv.bind("<F11>", lambda e: pv.attributes("-fullscreen", not pv.attributes("-fullscreen"))); L.bind("<Double-Button-1>", tog)
        pv.bind("<Escape>", lambda e: self.rc_key(e) if self.rc_on else pv.attributes("-fullscreen", False))
        L.bind("<Motion>", lambda e: self.rc_mouse(e, "move"))
        for n, b in ((1, "l"), (2, "m"), (3, "r")):
            L.bind(f"<ButtonPress-{n}>", lambda e, b=b: self.rc_mouse(e, "down", b)); L.bind(f"<ButtonRelease-{n}>", lambda e, b=b: self.rc_mouse(e, "up", b))
        L.bind("<MouseWheel>", lambda e: self.rc_mouse(e, "wheel", d=1 if e.delta > 0 else -1))
        L.bind("<Button-4>", lambda e: self.rc_mouse(e, "wheel", d=1)); L.bind("<Button-5>", lambda e: self.rc_mouse(e, "wheel", d=-1))
        pv.bind("<KeyPress>", self.rc_key)
        self.prev.protocol("WM_DELETE_WINDOW", self.stop_all); self.refresh()

    # ---------- điều khiển chuột / bàn phím máy đang xem ----------
    def prev_client(self):
        return {x.id: x for x in self.srv.snapshot()}.get(self.prev_id)

    def toggle_rc(self):
        c = self.prev_client()
        if not c or not self.prev: return
        self.rc_on = not self.rc_on
        if self.rc_on:
            c.send(cmd="rc_start")
            c.send(cmd="share_start", fps=max(self.cfg["fps"], 8), width=max(self.cfg["width"], 1280), quality=self.cfg["quality"])   # ảnh mượt hơn khi điều khiển
            self.rc_btn.configure(text="Điều khiển chuột / bàn phím: BẬT", bg="#fde68a"); self.prev.focus_force()
        else:
            c.send(cmd="rc_stop")
            c.send(cmd="share_start", fps=self.cfg["fps"], width=self.cfg["width"], quality=self.cfg["quality"])
            self.rc_btn.configure(text="Điều khiển chuột / bàn phím: TẮT", bg=self.prev.cget("bg"))

    def rc_send(self, move=False, **kw):
        c = self.prev_client()
        if c and self.rc_on: (c.conn.try_json if move else c.conn.send_json)({"cmd": "rc", **kw})

    def rc_mouse(self, e, t, b=None, d=0):
        if not self.rc_on or not self.prev_lbl: return
        iw, ih = self.prev_img
        if not iw: return
        w, h = max(1, self.prev_lbl.winfo_width()), max(1, self.prev_lbl.winfo_height()); k = min(w / iw, h / ih); nw, nh = iw * k, ih * k
        fx, fy = (e.x - (w - nw) / 2) / nw, (e.y - (h - nh) / 2) / nh
        if not (0 <= fx <= 1 and 0 <= fy <= 1): return
        if t == "move":
            if time.time() - self.rc_t < 0.04: return                  # tối đa ~25 lần/giây
            self.rc_t = time.time()
        self.rc_send(move=t in ("move", "wheel"), t=t, x=round(fx, 4), y=round(fy, 4), b=b, d=d)

    def rc_key(self, e):
        if not self.rc_on: return
        ks, st = e.keysym, e.state
        ctrl, shift, alt = bool(st & 0x4), bool(st & 0x1), bool(st & (0x20000 if os.name == "nt" else 0x8))
        vk = {"BackSpace": 8, "Tab": 9, "Return": 13, "Escape": 27, "Prior": 33, "Next": 34, "End": 35, "Home": 36, "Left": 37, "Up": 38,
              "Right": 39, "Down": 40, "Insert": 45, "Delete": 46}.get(ks)
        if vk is None and ks[0] == "F" and ks[1:].isdigit() and 1 <= int(ks[1:]) <= 12: vk = 0x6F + int(ks[1:])
        if vk is None and (ctrl or alt) and len(ks) == 1 and ks.isalnum(): vk = ord(ks.upper())
        if vk is not None: self.rc_send(t="key", vk=vk, c=ctrl, a=alt, s=shift)
        elif e.char and e.char.isprintable() and not ctrl and not alt: self.rc_send(t="text", s=e.char)
        return "break"

    # ---------- quản lý 1 máy: ứng dụng đang chạy ----------
    def manage(self, cid=None):
        cid = cid or (next(iter(self.sel)) if len(self.sel) == 1 else None)
        c = {x.id: x for x in self.srv.snapshot()}.get(cid)
        if not c: return messagebox.showinfo("Quản lý máy", "Hãy bấm chọn đúng 1 máy.")
        if self.mg and self.mg.winfo_exists():
            if self.mg_cid == cid: self.mg.lift(); return
            self.close_manage()
        d = self.mg = tk.Toplevel(self.root); self.mg_cid, self.mg_items = cid, {}
        d.title(f"Quản lý máy: {self.disp(c)} ({c.ip})"); d.geometry("700x460"); d.transient(self.root); d.configure(bg=BG)
        tk.Label(d, text=f"{self.disp(c)}  ({c.ip})" + (f"  –  tài khoản: {c.user}" if getattr(c, "user", "") else ""), bg=BG, font=("TkDefaultFont", 12, "bold")).pack(anchor="w", padx=14, pady=(12, 0))
        tk.Label(d, text="Ứng dụng học sinh đang mở (tự cập nhật mỗi 5 giây). Học sinh sẽ thấy thông báo khi ứng dụng bị đóng.", bg=BG, fg=MUTED).pack(anchor="w", padx=14, pady=(0, 6))
        bf = tk.Frame(d, bg=BG); bf.pack(side="bottom", fill="x", padx=14, pady=10)
        fr = tk.Frame(d, bg=BG); fr.pack(fill="both", expand=True, padx=14)
        tr = self.mg_tree = ttk.Treeview(fr, columns=("app", "title"), show="headings", selectmode="extended")
        tr.heading("app", text="Chương trình"); tr.heading("title", text="Tiêu đề cửa sổ"); tr.column("app", width=170, stretch=False); tr.column("title", width=460)
        sb = tk.Scrollbar(fr, command=tr.yview); tr.configure(yscrollcommand=sb.set); sb.pack(side="right", fill="y"); tr.pack(side="left", fill="both", expand=True)
        c.proc_cb = lambda cl, items: setattr(self, "proc_data", (cl.id, items))
        def ask():
            cc = {x.id: x for x in self.srv.snapshot()}.get(cid)
            if cc: cc.send(cmd="proc_list")
        def act(force):
            sel = tr.selection()
            if not sel: return messagebox.showinfo("Quản lý máy", "Hãy chọn ứng dụng cần đóng.", parent=d)
            if force and not messagebox.askyesno("Buộc tắt", "Buộc tắt có thể làm mất dữ liệu chưa lưu của học sinh.\nTiếp tục?", parent=d): return
            cc = {x.id: x for x in self.srv.snapshot()}.get(cid)
            if cc:
                for iid in sel: cc.send(cmd="proc_close", id=self.mg_items[iid]["id"], force=force)
            d.after(1800, ask)
        def watch():
            self.sel = {cid}; self.paint(); d.destroy(); self.share_user(False)
        tk.Button(bf, text="Đóng ứng dụng", width=14, command=lambda: act(False)).pack(side="left")
        tk.Button(bf, text="Buộc tắt", width=10, command=lambda: act(True)).pack(side="left", padx=6)
        tk.Button(bf, text="Làm mới", width=9, command=ask).pack(side="left")
        tk.Button(bf, text="Xem / điều khiển màn hình", command=watch).pack(side="right")
        d.protocol("WM_DELETE_WINDOW", self.close_manage)
        def tick():
            if d.winfo_exists(): ask(); d.after(5000, tick)
        tick()

    def close_manage(self):
        if self.mg and self.mg.winfo_exists():
            c = {x.id: x for x in self.srv.snapshot()}.get(self.mg_cid)
            if c: c.proc_cb = None
            self.mg.destroy()
        self.mg = None

    def fill_procs(self, cid, items):
        if not (self.mg and self.mg.winfo_exists()) or cid != self.mg_cid: return
        keep, tr = set(self.mg_tree.selection()), self.mg_tree
        tr.delete(*tr.get_children()); self.mg_items = {}
        for it in items:
            iid = str(it.get("id")); self.mg_items[iid] = it
            tr.insert("", "end", iid=iid, values=(str(it.get("app", ""))[:40], str(it.get("title", ""))[:200]))
        tr.selection_set([i for i in keep if i in self.mg_items])

    def stop_all(self):
        if self.stop_ev: self.stop_ev.set(); self.stop_ev = None
        if self.rc_on:
            c = self.prev_client()
            if c: c.send(cmd="rc_stop")
            self.rc_on = False
        for c in self.srv.snapshot():
            if c.presenting: c.send(cmd="present_stop"); c.presenting = False
            if c.sharing: c.send(cmd="share_stop"); c.sharing = False
        self.srv.relay_src, self.srv.relay_dst = None, []
        if self.prev: self.prev.destroy(); self.prev = None
        self.msg = "Đã dừng chiếu"; self.refresh()

    # ---------- cập nhật / vá lỗi phần mềm ----------
    def update_dialog(self):
        """Cập nhật không cần cài lại: chọn gói mới -> vá máy admin -> các máy user hiện thông báo, học sinh bấm 'Cập nhật ngay'."""
        w = getattr(self, "upd_win", None)
        if w is not None and w.winfo_exists(): w.lift(); w.focus_force(); return
        F = self.F
        d = self.upd_win = tk.Toplevel(self.root); d.title("Cập nhật (Update)"); d.geometry("860x660"); d.configure(bg=BG); d.transient(self.root)
        tk.Label(d, text="Cập nhật (Update)", bg=BG, fg=TEXT, font=(F, 15, "bold")).pack(anchor="w", padx=16, pady=(14, 8))
        info = tk.StringVar(); tk.Label(d, textvariable=info, bg=BG, fg=TEXT, font=(F, 11, "bold"), justify="left").pack(anchor="w", padx=16)
        # --- cập nhật qua Internet (link gắn chết trong updater.py); không có mạng thì dùng nút chọn file ---
        nf = tk.LabelFrame(d, text=" Cập nhật từ Internet ", bg=BG, fg=TEXT, font=(F, 10, "bold")); nf.pack(fill="x", padx=16, pady=(4, 0))
        net_btn = tk.Button(nf, text="Cập nhật từ Internet", bg="#2563eb", fg="white", font=(F, 10, "bold"), padx=12, command=lambda: self.online_update(d, net_btn, net_msg)); net_btn.pack(side="left", padx=10, pady=8)
        net_msg = tk.Label(nf, text="Tải bản mới nhất từ máy chủ cập nhật. Không có mạng: dùng \"Chọn file .zip…\" bên dưới.", bg=BG, fg=MUTED, justify="left", anchor="w"); net_msg.pack(side="left", padx=(0, 10))
        bf = tk.Frame(d, bg=BG); bf.pack(fill="x", padx=16, pady=8)
        tk.Button(bf, text="Chọn file .zip…", command=lambda: self.pick_update(d, False), bg="#16a34a", fg="white", font=(F, 10, "bold"), padx=10).pack(side="left")
        tk.Button(bf, text="Chọn thư mục…", command=lambda: self.pick_update(d, True)).pack(side="left", padx=6)
        tk.Button(bf, text="Nhắc lại các máy chưa cập nhật", command=lambda: self.nudge_update(d)).pack(side="left", padx=6)
        tk.Button(bf, text="Khôi phục bản trước", command=lambda: self.rollback_update(d)).pack(side="right")
        tk.Button(bf, text="Mở lại admin", command=lambda: (updater.relaunch("admin.py"), self.quit())).pack(side="right", padx=6)
        cols = ("name", "ip", "ver", "state")
        tv = ttk.Treeview(d, columns=cols, show="headings", height=14)
        for c, t, wd in (("name", "Máy", 150), ("ip", "IP", 120), ("ver", "Phiên bản", 90), ("state", "Trạng thái", 340)): tv.heading(c, text=t); tv.column(c, width=wd, anchor="w")
        tv.tag_configure("ok", foreground="#15803d"); tv.tag_configure("wait", foreground="#b45309"); tv.tag_configure("old", foreground="#b91c1c")
        tv.pack(fill="both", expand=True, padx=16, pady=(0, 8))

        def tick():
            if not d.winfo_exists(): return
            u = self.srv.upd; cur_b = u["build"] if u else ""
            run, disk = updater.RUN_BUILD, (u["build"] if u else "?")
            txt = f"Admin đang chạy: bản {updater.RUN_VER} ({run})"
            if updater.stale(): txt += f"\n⚠ File trên đĩa đã là bản {updater.version()} nhưng chương trình đang chạy là bản cũ – hãy MỞ LẠI admin (bấm nút “Mở lại admin”)."
            n_ok, n_wait, n_old = self.srv.update_stats()
            info.set(txt + f"\nMáy user: {n_ok} đã mới nhất • {n_wait} chờ cập nhật • {n_old} bản cũ")
            tv.delete(*tv.get_children())
            for c in sorted(self.srv.snapshot(), key=lambda c: nat_key(c.name)):
                if not c.build: st, tag = "Bản cũ – cần cài lại 1 lần bằng CAI-USER", "old"
                elif c.build == cur_b: st, tag = "✔ Mới nhất", "ok"
                else: st, tag = "Chờ học sinh bấm “Cập nhật ngay”" + (f" — {c.upd_note}" if c.upd_note else ""), "wait"
                tv.insert("", "end", values=(c.name, c.ip, c.ver or "?", st), tags=(tag,))
            d.after(2000, tick)
        tick(); d.bind("<Escape>", lambda e: d.destroy()); d.focus_force()

    def pick_update(self, d, folder):
        from tkinter import filedialog as fd
        path = fd.askdirectory(parent=d, title="Chọn thư mục gói cập nhật") if folder else fd.askopenfilename(parent=d, title="Chọn gói cập nhật (.zip)", filetypes=[("Gói cập nhật", "*.zip"), ("Tất cả", "*.*")])
        if not path: return
        try: pkg = updater.read_package(path)
        except Exception as e: return messagebox.showerror("Cập nhật", str(e), parent=d)
        self.review_update(d, pkg)

    def online_update(self, d, btn, msg):
        btn.configure(state="disabled"); msg.configure(text="Đang tải gói cập nhật…", fg=MUTED)
        res = []
        def job():
            try: res.append((updater.fetch_default(), None))
            except Exception as e: res.append((None, str(e)))
        threading.Thread(target=job, daemon=True).start()
        def wait():
            if not d.winfo_exists(): return
            if not res: return d.after(200, wait)
            btn.configure(state="normal"); pkg, err = res[0]
            if err: msg.configure(text="Không tải được: " + err.splitlines()[0], fg="#b91c1c"); return messagebox.showerror("Cập nhật từ Internet", err, parent=d)
            msg.configure(text="Đã tải xong gói cập nhật.", fg="#15803d"); self.review_update(d, pkg, "Internet")
        wait()

    def review_update(self, d, pkg, src=""):
        """Xem gói đã đọc (từ file hoặc Internet): so với bản đang cài, hỏi xác nhận rồi vá admin + báo các máy user."""
        try: p = updater.plan(pkg)
        except Exception as e:
            return messagebox.showerror("Cập nhật", str(e), parent=d)
        if not p["changed"]:
            if updater.stale():
                if messagebox.askyesno("Cập nhật", f"File trên đĩa đã là bản {updater.version()} (giống gói này) nhưng chương trình đang chạy vẫn là bản cũ ({updater.RUN_VER}).\n\nMở lại admin ngay để dùng bản mới?", parent=d):
                    updater.relaunch("admin.py"); self.quit()
                return
            return messagebox.showinfo("Cập nhật", ("Đã là bản mới nhất – " if src else "") + "Gói này giống hệt bản đang cài – không có gì để cập nhật.", parent=d)
        lst = "\n".join("  • " + n + ("  (mới)" if n in p["added"] else "") for n in p["changed"][:14]) + (f"\n  … và {len(p['changed']) - 14} file nữa" if len(p["changed"]) > 14 else "")
        nt = updater.notes(pkg)
        if not messagebox.askyesno("Cập nhật", f"Bản đang cài: {p['ver_old']}\nBản trong gói: {p['ver_new']}\n\n" + (f"Nội dung cập nhật:\n{nt}\n\n" if nt else "") + f"Sẽ thay {len(p['changed'])} file:\n{lst}\n\n"
                                   "• Admin được vá ngay (có sao lưu, lỗi tự quay về bản cũ).\n• Các máy user hiện thông báo để học sinh bấm cập nhật.\n"
                                   "• Mã lớp / config không bị đổi.\n\nTiếp tục?", parent=d): return
        self.msg = "Đang cập nhật admin…"; self.refresh()
        def job():
            try:
                done = updater.apply(pkg, role="admin", log=print); self.srv.refresh_update(); n = self.srv.offer_all()
                self.upd_done = (True, f"Đã cập nhật admin ({len(done)} file).\nĐã báo {n} máy user – học sinh bấm “Cập nhật ngay” là xong.", True)
            except Exception as e:
                self.upd_done = (False, "Cập nhật thất bại, admin vẫn giữ bản cũ.\n\n" + str(e), False)
        threading.Thread(target=job, daemon=True).start()

    def rollback_update(self, d):
        info = updater.last_backup()
        if not info: return messagebox.showinfo("Khôi phục", "Chưa có bản sao lưu nào để khôi phục.", parent=d)
        if not messagebox.askyesno("Khôi phục", f"Quay lại bản {info.get('ver', '?')} (trước lần cập nhật gần nhất)?\nCác máy user sẽ được báo để cập nhật theo.", parent=d): return
        def job():
            try:
                i = updater.rollback(role="admin", log=print); self.srv.refresh_update(); n = self.srv.offer_all()
                self.upd_done = (True, f"Đã khôi phục bản {i.get('ver', '?')} trên admin.\nĐã báo {n} máy user.", True)
            except Exception as e:
                self.upd_done = (False, "Khôi phục thất bại.\n\n" + str(e), False)
        threading.Thread(target=job, daemon=True).start()

    def nudge_update(self, d):
        n = self.srv.offer_all(); self.msg = f"Đã nhắc {n} máy cập nhật" if n else "Không có máy nào cần cập nhật"; self.refresh()
        messagebox.showinfo("Cập nhật", self.msg, parent=d)

    def update_finished(self, ok, text, ask_restart):
        self.msg = text.splitlines()[0]; self.refresh()
        parent = self.upd_win if getattr(self, "upd_win", None) is not None and self.upd_win.winfo_exists() else self.root
        if not ok: return messagebox.showerror("Cập nhật", text, parent=parent)
        if ask_restart and messagebox.askyesno("Cập nhật", text + "\n\nKhởi động lại admin ngay để dùng bản mới?\n(Các máy user tự nối lại sau vài giây; máy đang khóa sẽ tự mở khóa.)", parent=parent):
            updater.relaunch("admin.py"); self.quit()
        else: messagebox.showinfo("Cập nhật", text + ("\n\nNhớ khởi động lại admin khi tiện để dùng bản mới." if ask_restart else ""), parent=parent)

    # ---------- mở khóa phần mềm (nhập mã, 7 / 30 / 365 ngày kể từ lúc mở khóa) ----------
    def lic_text(self):
        s = unlock.status()
        if s["state"] == "ok": return f"Còn {unlock.left_text(s['left'])} (hết hạn {unlock.date_text(s['exp'])})"
        return {"expired": "Đã hết hạn", "clock": "Đồng hồ máy bị chỉnh lùi"}.get(s["state"], "Chưa mở khóa")

    def apply_license(self):
        """Chưa mở khóa / hết hạn: chỉ làm mờ + chặn nhóm chức năng PREMIUM; có mã còn hạn thì mở đủ."""
        on = unlock.status()["state"] == "ok"
        self._lic_on = on
        for b, img_on, img_off in self.lic_btns:
            b.configure(state="normal" if on else "disabled", image=img_on if on else img_off, fg=TEXT if on else "#94a3b8", cursor="hand2" if on else "arrow")
        for i in range(self.menu.index("end") + 1):
            try:
                lab = self.menu.entrycget(i, "label").strip()
                if lab in MENU_PREMIUM: self.menu.entryconfigure(i, state="normal" if on else "disabled")
            except Exception: pass
        self.set_title()

    def unlock_dialog(self):
        """Nhập mã mở khóa (còn hạn thì cộng nối tiếp)."""
        if self._lic_busy: return
        self._lic_busy = True
        try: unlock.dialog(self.root, self.F)
        finally: self._lic_busy = False
        self.apply_license(); self.msg = "Mở khóa: " + self.lic_text(); self.refresh()

    def lic_expired(self, why):
        """Hết hạn / chỉnh đồng hồ: TẮT NGAY mọi chức năng nâng cao đang chạy, đóng cửa sổ của chúng rồi báo cho giáo viên."""
        self.apply_license()
        try:
            w = dict(self.srv.web or {}); stopped = []
            if w.get("on"):
                w["on"] = False; self.srv.web = w; webblock.save(w)
                for c in self.srv.snapshot(): c.send(cmd="webblock", policy=w)
                stopped.append("Chặn web")
            if self.srv.inbox: self.srv.close_inbox(); stopped.append("Nhận bài")
        except Exception: stopped = []
        for t in self.root.winfo_children():
            try:
                if isinstance(t, tk.Toplevel) and any(k in t.title() for k in ("Gửi thông báo", "Gửi link", "Chặn web", "Gửi file", "Thu bài", "Nhận bài", "Chọn file cần thu")): t.destroy()
            except Exception: pass
        self.msg = "Đã hết hạn – các chức năng nâng cao đã tắt. Nhập mã để mở lại."; self.refresh()
        txt = why + "\n\nCác chức năng Gửi file, Thu bài, Nhận bài, Gửi link, Thông báo, Chặn web đã bị tắt" + (f" (đang chạy và đã dừng: {', '.join(stopped)})" if stopped else "") + ".\nCác chức năng cơ bản vẫn dùng được. Vào menu Mở khóa → Nhập mã để dùng lại đầy đủ."
        messagebox.showwarning("Hết hạn mở khóa", txt, parent=self.root)

    def lic_tick(self):
        """Kiểm tra hạn đúng thời điểm hết hạn (tối đa mỗi 30 giây). Hết hạn là tắt ngay và báo."""
        s = unlock.status(); on = s["state"] == "ok"; was, delay = self._lic_on, 30000
        if on:
            delay = int(max(500, min(30000, s["left"] * 1000 + 300)))
            if not was: self.apply_license(); self.msg = "Đã mở khóa: " + self.lic_text(); self.refresh()
            else: self.set_title()
        elif was:
            why = "Đồng hồ máy bị chỉnh lùi nên phần mềm bị khóa lại." if s["state"] == "clock" else "Mã mở khóa đã hết hạn."
            self.lic_expired(why)
        self.root.after(delay, self.lic_tick)

    def show_help(self, idx=0):
        """Cửa sổ Hướng dẫn (F1): danh sách chủ đề bên trái, nội dung bên phải."""
        h = getattr(self, "help_win", None)
        if h is not None and h.winfo_exists():
            h.lift(); h.focus_force(); h.select(idx); return
        F = self.F
        w = tk.Toplevel(self.root); w.title("Hướng dẫn – Quản lý phòng máy"); w.geometry("980x620"); w.configure(bg=BG); w.transient(self.root)
        lb = tk.Listbox(w, width=32, exportselection=False, font=(F, 11), activestyle="none", bd=0, highlightthickness=1, highlightbackground=BORDER,
                        selectbackground=PRIMARY, selectforeground="white")
        lb.pack(side="left", fill="y", padx=(10, 0), pady=10)
        body = tk.Frame(w, bg=CARD, highlightthickness=1, highlightbackground=BORDER); body.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        sb = tk.Scrollbar(body); sb.pack(side="right", fill="y")
        tx = tk.Text(body, wrap="word", font=(F, 11), bg=CARD, fg=TEXT, bd=0, padx=16, pady=12, yscrollcommand=sb.set, spacing3=2)
        tx.pack(side="left", fill="both", expand=True); sb.configure(command=tx.yview)
        for t, _ in TOPICS: lb.insert("end", "  " + t)
        def select(i):
            i = max(0, min(i, len(TOPICS) - 1))
            lb.selection_clear(0, "end"); lb.selection_set(i)
            tx.configure(state="normal"); tx.delete("1.0", "end"); tx.insert("1.0", TOPICS[i][1]); tx.configure(state="disabled")
        lb.bind("<<ListboxSelect>>", lambda e: select(lb.curselection()[0]) if lb.curselection() else None)
        w.select = select; w.bind("<Escape>", lambda e: w.destroy()); w.bind("<F1>", lambda e: "break")
        self.help_win = w; select(idx); w.focus_force()

    def quit(self):
        self.close_manage(); self.stop_all(); self.root.after(300, self.exit_now)

    def exit_now(self):
        """Đóng cửa sổ và THOÁT HẲN tiến trình (đóng mọi kết nối), để lần mở sau không bị vướng bản cũ còn chạy ngầm."""
        try: self.root.destroy()
        finally: os._exit(0)


for _n in LIC_GUARDED: setattr(App, _n, _needs_license(getattr(App, _n)))


if __name__ == "__main__":
    dpi_aware(); App(load_config()).root.mainloop(); os._exit(0)
