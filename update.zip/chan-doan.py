"""CHẨN ĐOÁN KẾT NỐI – chạy được trên máy ADMIN lẫn máy USER (chỉ cần Python, không cần giao diện).

  Máy ADMIN :  python chan-doan.py            (quét dải mạng, thử bắt tay với từng máy học sinh tìm thấy)
  Máy USER  :  python chan-doan.py --admin IP_ADMIN   (thử nối tới admin)
Kết quả in ra màn hình và lưu vào chan-doan.txt – gửi file này để được hỗ trợ."""
import hashlib, hmac, ipaddress, json, os, platform, socket, struct, subprocess, sys, threading, time
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_config, local_ips, read_msg, write_msg, sign, room_secrets, T_JSON

OUT = []
def say(s=""):
    print(s); OUT.append(s)


def can_bind(kind, port):
    s = socket.socket(socket.AF_INET, kind)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("", port)); return True
    except OSError:
        return False
    finally:
        s.close()


def probe_user(ip, port, secret):
    """Nối tới máy học sinh (đóng vai admin), thử bắt tay. Trả về (kết quả, ghi chú)."""
    try:
        s = socket.create_connection((ip, port), timeout=1.5)
    except OSError:
        return None, ""
    try:
        s.settimeout(6)
        nonce = os.urandom(8).hex()
        write_msg(s, T_JSON, {"cmd": "challenge", "nonce": nonce})
        t, m = read_msg(s)
        if m.get("cmd") != "hello":
            return "lạ", "phản hồi không đúng giao thức"
        ok = any(hmac.compare_digest(sign(sc, b"c", nonce, str(m.get("cn", ""))), str(m.get("resp"))) for sc in (secret if isinstance(secret, (list, tuple)) else [secret]))
        who = f"{m.get('name', '?')} (tài khoản: {m.get('user') or 'bản cũ, không gửi'})"
        return ("ĐÚNG mã lớp" if ok else "SAI mã lớp"), who
    except Exception as e:
        return "lỗi", f"{type(e).__name__}: {e}"
    finally:
        try: s.close()
        except OSError: pass


def main():
    cfg = load_config()
    secret, port, aport, dport = str(cfg["secret"]), int(cfg["port"]), int(cfg.get("agent_port", 5003)), int(cfg.get("discovery_port", 5001))
    say("=== CHẨN ĐOÁN LABMANAGER ===  " + time.strftime("%d/%m/%Y %H:%M:%S"))
    say(f"Máy: {socket.gethostname()}   HĐH: {platform.platform()}   Python: {platform.python_version()}")
    ips = local_ips()
    say("IP của máy này: " + (", ".join(ips) if ips else "KHÔNG TÌM THẤY IP LAN (máy chưa có mạng?)"))
    for rn, sc in room_secrets(cfg):
        say(f"Mã lớp{(' – ' + rn) if rn else ''} (dấu vân tay, phải GIỐNG NHAU trên các máy của phòng đó): {hashlib.sha256(sc.encode()).hexdigest()[:8]}")
    say(f"Cổng: admin TCP {port}, máy user TCP {aport}, tự tìm UDP {dport}   |   scan: {cfg.get('scan') or 'tự động (dải /24 của máy này)'}")
    say(f"Thư mục: {os.path.dirname(os.path.abspath(__file__))}")
    say()

    say("--- 1. Chương trình nào đang giữ các cổng ---")
    for label, kind, p in ((f"TCP {port} (admin lắng nghe)", socket.SOCK_STREAM, port), (f"TCP {aport} (máy user lắng nghe)", socket.SOCK_STREAM, aport), (f"UDP {dport} (tự tìm admin)", socket.SOCK_DGRAM, dport)):
        say(f"  {label}: " + ("TRỐNG (chưa có app nào dùng)" if can_bind(kind, p) else "ĐANG CÓ APP DÙNG (bình thường nếu LabManager đang chạy trên máy này)"))
    say()

    if "--admin" in sys.argv:
        ip = sys.argv[sys.argv.index("--admin") + 1]
        say(f"--- 2. Máy USER nối tới admin {ip}:{port} ---")
        try:
            s = socket.create_connection((ip, port), timeout=4); s.settimeout(5)
            t, m = read_msg(s); s.close()
            say("  KẾT NỐI ĐƯỢC và admin phản hồi đúng." if m.get("cmd") == "challenge" else "  Nối được nhưng phản hồi lạ (cổng này có thể là chương trình khác).")
        except Exception as e:
            say(f"  KHÔNG nối được ({type(e).__name__}: {e}).")
            say("  -> Nếu admin đang mở: tường lửa / phần mềm diệt virus trên MÁY ADMIN đang chặn TCP " + str(port) + " (xem Hướng dẫn F1, mục 13), hoặc sai IP, hoặc khác mạng.")
    else:
        nets = cfg.get("scan") or [i + "/24" for i in ips]
        targets = []
        for n in nets:
            try:
                net = ipaddress.ip_network(str(n), strict=False)
                targets += [str(h) for h in net.hosts()] if net.num_addresses > 1 else [str(net.network_address)]
            except ValueError:
                say(f"  (bỏ qua dải không hợp lệ trong config: {n})")
        targets = [t for t in dict.fromkeys(targets) if t not in ips]
        say(f"--- 2. Máy ADMIN quét {len(targets)} địa chỉ ({', '.join(map(str, nets)) or 'không có dải nào'}) tìm máy học sinh trên TCP {aport} ---")
        if not targets:
            say("  Không có dải mạng để quét. Máy admin chưa có IP LAN? Hoặc khai \"scan\" trong config.json.")
        res, lock = [], threading.Lock()
        def one(ip):
            r, note = probe_user(ip, aport, [sc for _, sc in room_secrets(cfg)])
            if r:
                with lock: res.append((ip, r, note))
        with ThreadPoolExecutor(max_workers=64) as ex: list(ex.map(one, targets))
        res.sort(key=lambda x: tuple(int(p) for p in x[0].split(".")))
        for ip, r, note in res: say(f"  {ip:15} {r:14} {note}")
        good, bad = [x for x in res if x[1] == "ĐÚNG mã lớp"], [x for x in res if x[1] != "ĐÚNG mã lớp"]
        say(f"  => Tìm thấy {len(res)} máy có LabManager User đang chạy và mở cổng; {len(good)} máy đúng mã lớp.")
        say()
        say("--- 3. Kết luận ---")
        if not ips: say("  * Máy admin không có IP LAN: kiểm tra dây mạng / Wi-Fi.")
        elif not res: say("  * Không máy học sinh nào trả lời trên TCP " + str(aport) + ". Thường do: (a) máy học sinh chưa chạy LabManager User, (b) tường lửa / diệt virus trên MÁY HỌC SINH chặn TCP " + str(aport) + " (xem F1 mục 13), (c) khác dải mạng (khai \"scan\"), (d) Wi-Fi bật cách ly thiết bị. Chạy tool này với  --admin IP_ADMIN  trên 1 máy học sinh để thử chiều ngược lại.")
        if bad: say("  * Máy SAI mã lớp: config.json của máy đó khác admin. Chép cùng 1 file config.json cho mọi máy rồi chạy lại CAI-USER.")
        if good: say("  * Có máy đúng mã lớp mà admin vẫn không hiện: có thể admin đang bị bản cũ chạy ngầm giữ cổng (tắt python.exe / pythonw.exe trong Task Manager rồi mở lại), hoặc máy học sinh đang bận phục vụ admin khác.")
    try:
        open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "chan-doan.txt"), "w", encoding="utf-8").write("\n".join(OUT) + "\n")
        say(); say("(Đã lưu báo cáo vào chan-doan.txt)")
    except OSError:
        pass


if __name__ == "__main__":
    main()
