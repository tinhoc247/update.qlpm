"""MÁY USER (học sinh) – chạy:  python client.py   (hoặc: python client.py --server 192.168.1.10)"""
import hashlib, io, json, os, platform, queue, re, socket, subprocess, sys, tempfile, threading, time, webbrowser, zipfile
import tkinter as tk
from tkinter import filedialog, messagebox
from urllib.parse import urlparse
from PIL import Image, ImageTk
from common import *
from theme import pick_font, tkicon
import updater, webblock

WEB = webblock.Enforcer()      # chặn web xấu do admin bật (xem webblock.py)
GUARD = webblock.InstallGuard()    # chặn học sinh chạy file cài đặt (xem webblock.py); chạy độc lập với kết nối admin


_SYS = r"Software\Microsoft\Windows\CurrentVersion\Policies\System"
_EXP = r"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
_POL = [(_SYS, "DisableTaskMgr"), (_SYS, "DisableLockWorkstation"), (_SYS, "DisableChangePassword"), (_EXP, "NoLogoff"), (_EXP, "NoClose")]
_BACKUP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "policy_backup.json")


def policy(on):
    """Windows: khi bị khóa/đang chiếu, tắt các lựa chọn trên màn hình Ctrl+Alt+Del (Task Manager, khóa, đăng xuất,
    tắt máy, đổi mật khẩu) của tài khoản đang dùng. Giá trị cũ được lưu lại và trả về khi hết khóa / khi app khởi động lại."""
    if os.name != "nt": return
    try:
        import winreg
        H = winreg.HKEY_CURRENT_USER
        if on:
            if os.path.exists(_BACKUP): return
            bak = {}
            for path, name in _POL:
                try:
                    with winreg.OpenKey(H, path) as k: bak[path + "|" + name] = winreg.QueryValueEx(k, name)[0]
                except OSError: bak[path + "|" + name] = None
            with open(_BACKUP, "w", encoding="utf-8") as f: json.dump(bak, f)
            for path, name in _POL:
                with winreg.CreateKey(H, path) as k: winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, 1)
        else:
            if not os.path.exists(_BACKUP): return
            with open(_BACKUP, encoding="utf-8") as f: bak = json.load(f)
            for key, val in bak.items():
                path, name = key.split("|")
                with winreg.CreateKey(H, path) as k:
                    if val is None:
                        try: winreg.DeleteValue(k, name)
                        except OSError: pass
                    else: winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, val)
            os.remove(_BACKUP)
    except Exception as e:
        print("policy:", e)


_APPS = {"chrome": "Chrome", "msedge": "Edge", "firefox": "Firefox", "brave": "Brave", "opera": "Opera", "winword": "Word",
         "excel": "Excel", "powerpnt": "PowerPoint", "notepad": "Notepad", "code": "VS Code", "explorer": "File Explorer",
         "chromium": "Chromium", "chromium-browser": "Chromium", "firefox-esr": "Firefox", "zalo": "Zalo"}


def active_window():
    """(chương trình, tiêu đề cửa sổ) đang ở phía trước. Tiêu đề trình duyệt thường chứa tên trang web đang xem."""
    app = title = ""
    try:
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes
            u, k = ctypes.windll.user32, ctypes.windll.kernel32
            k.OpenProcess.restype = wintypes.HANDLE
            h = u.GetForegroundWindow()
            if h:
                n = u.GetWindowTextLengthW(h); buf = ctypes.create_unicode_buffer(n + 1); u.GetWindowTextW(h, buf, n + 1); title = buf.value
                pid = wintypes.DWORD(); u.GetWindowThreadProcessId(h, ctypes.byref(pid))
                ph = k.OpenProcess(0x1000, False, pid.value)
                if ph:
                    sz = wintypes.DWORD(520); b = ctypes.create_unicode_buffer(520)
                    if k.QueryFullProcessImageNameW(ph, 0, b, ctypes.byref(sz)): app = os.path.basename(b.value)
                    k.CloseHandle(ph)
        else:
            out = subprocess.run(["xprop", "-root", "_NET_ACTIVE_WINDOW"], capture_output=True, text=True, timeout=2).stdout.split()
            wid = out[-1] if out else ""
            if wid.startswith("0x") and wid != "0x0":
                for line in subprocess.run(["xprop", "-id", wid, "_NET_WM_PID", "_NET_WM_NAME"], capture_output=True, text=True, timeout=2).stdout.splitlines():
                    if line.startswith("_NET_WM_PID") and "=" in line:
                        try: app = open("/proc/%s/comm" % line.split("=")[1].strip()).read().strip()
                        except OSError: pass
                    elif line.startswith("_NET_WM_NAME") and "=" in line: title = line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    a = app[:-4] if app.lower().endswith(".exe") else app
    return _APPS.get(a.lower(), a), title.strip()


PRESENT_FIT = False      # đặt lại từ config.json ("present_fit") khi khởi động


class InputBlocker:
    """Windows: hook cấp thấp nuốt MỌI phím (kể cả Win, Alt+Tab, Ctrl+Esc) và MỌI thao tác chuột.
    Ctrl+Alt+Del do hệ điều hành xử lý nên không chặn được. Hook tự gỡ khi tiến trình thoát."""
    def __init__(self): self.on = False; self.th = None; self.retry = 0

    def start(self):
        if os.name != "nt" or self.on or time.time() < self.retry: return
        self.on = True; policy(True)
        self.th = threading.Thread(target=self._loop, daemon=True); self.th.start()

    def stop(self):
        if self.on: self.on = False
        policy(False)

    def _loop(self):
        try:
            import ctypes
            from ctypes import wintypes
            u = ctypes.windll.user32; k = ctypes.windll.kernel32
            L = ctypes.c_ssize_t
            HOOKPROC = ctypes.WINFUNCTYPE(L, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
            u.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
            u.SetWindowsHookExW.restype = wintypes.HHOOK
            u.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
            u.CallNextHookEx.restype = L
            u.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
            k.GetModuleHandleW.restype = wintypes.HMODULE

            def swallow(n, w, l): return 1 if n >= 0 else 0
            proc = HOOKPROC(swallow)            # giữ tham chiếu để không bị thu hồi
            hm = k.GetModuleHandleW(None)
            hooks = [u.SetWindowsHookExW(13, proc, hm, 0), u.SetWindowsHookExW(14, proc, hm, 0)]   # KEYBOARD_LL, MOUSE_LL
            msg = wintypes.MSG()
            while self.on:
                while u.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                    u.TranslateMessage(ctypes.byref(msg)); u.DispatchMessageW(ctypes.byref(msg))
                time.sleep(0.01)
            for h in hooks:
                if h: u.UnhookWindowsHookEx(h)
        except Exception as e:
            print("blocker:", e); self.retry = time.time() + 5
        finally:
            self.on = False


class UI:
    """Mọi thao tác Tk nằm ở luồng chính; luồng mạng chỉ gửi sự kiện vào self.q."""
    def __init__(self):
        self.root = tk.Tk(); self.root.withdraw(); self.F = pick_font(self.root); set_window_icon(self.root, "user")
        self.q, self.fl = queue.Queue(), threading.Lock()
        self.frame = self.photo = self.lockw = self.presw = self.lbl = None
        self.locked = self.presenting = False; self.n = 0
        self.blocker = InputBlocker(); self.pending_link = None; self.linkw = None; self.pending_msgs = []; self.msgw = None
        self.subw = self.sub_status = self.sub_lb = None; self.sub_files = []; self.submit_sender = None
        self.upd_offer = self.updw = self.upd_status = self.upd_btn = self.update_requester = None; self.upd_snooze = 0   # thông báo cập nhật
        self.root.after(40, self.tick)

    def set_frame(self, d):
        with self.fl: self.frame = d

    def tick(self):
        try:
            while True:
                k, *a = self.q.get_nowait()
                if k == "lock": self.locked = a[0]
                elif k == "present": self.presenting = a[0]; self.set_frame(None)
                elif k == "reset": self.locked = self.presenting = False; self.close_submit(); self.close_update(clear=True)
                elif k == "notice": self.notice(a[0])
                elif k == "link": self.pending_link = a[0]
                elif k == "message": self.pending_msgs.append(a[0])
                elif k == "update_offer": self.upd_offer = a[0]; self.upd_snooze = 0
                elif k == "update_status": self.update_status(a[0], a[1])
                elif k == "submit_open": self.open_submit(a[0])
                elif k == "submit_status":
                    if self.sub_status: self.sub_status.set(a[0])
                elif k == "submit_done": self.sub_done(a[0])
                elif k == "submit_close": self.close_submit()
        except queue.Empty: pass
        try: self.update()
        except Exception as e: print("ui:", e)
        try: self.show_link(); self.show_message(); self.show_update()
        except Exception as e: print("link:", e)
        self.root.after(40, self.tick)

    def fs(self):
        w = tk.Toplevel(self.root); w.configure(bg="black")
        w.geometry(f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0")   # phòng khi trình quản lý cửa sổ bỏ qua fullscreen
        w.attributes("-fullscreen", True); w.attributes("-topmost", True)
        w.protocol("WM_DELETE_WINDOW", lambda: None); w.bind("<Key>", lambda e: "break"); w.focus_force()
        w.bind("<Unmap>", lambda e: w.after(5, lambda: self._restore(w)))   # bị thu nhỏ/ẩn → hiện lại ngay
        return w

    def _restore(self, w):
        try:
            if w.winfo_exists(): w.deiconify(); w.attributes("-fullscreen", True); w.attributes("-topmost", True); w.lift(); w.focus_force()
        except tk.TclError: pass

    def _grab(self, w):
        """Linux/X11: chiếm toàn bộ chuột + bàn phím cho cửa sổ phủ (Windows dùng InputBlocker)."""
        if os.name == "nt" or not w: return
        try:
            if w.grab_status() != "global": w.update_idletasks(); w.grab_set_global()
        except tk.TclError: pass

    def update(self):
        self.n += 1; keep = self.n % 3 == 0           # giữ cửa sổ luôn ở trên cùng (~0,12 giây/lần)
        (self.blocker.start if (self.locked or self.presenting) else self.blocker.stop)()   # khóa chuột + phím khi bị khóa / đang chiếu
        if self.locked:
            if self.presw: self.presw.destroy(); self.presw = None
            if not self.lockw:
                self.lockw = self.fs(); self.lockw.configure(bg="#0f172a")
                box = tk.Frame(self.lockw, bg="#0f172a"); box.place(relx=.5, rely=.5, anchor="center")
                tk.Label(box, image=tkicon("lock", 150, "#f8fafc"), bg="#0f172a").pack()
                tk.Label(box, text="Máy đã bị khóa", fg="#f8fafc", bg="#0f172a", font=(self.F, 44, "bold")).pack(pady=(18, 4))
                tk.Label(box, text="Vui lòng chờ giáo viên mở khóa", fg="#94a3b8", bg="#0f172a", font=(self.F, 22)).pack()
                tk.Label(self.lockw, text=COPYRIGHT, fg="#475569", bg="#0f172a", font=(self.F, 11)).place(relx=.5, rely=.97, anchor="s")
            if keep: self.lockw.lift(); self.lockw.attributes("-topmost", True); self.lockw.focus_force(); self._grab(self.lockw)
            return
        if self.lockw: self.lockw.destroy(); self.lockw = None
        if self.presenting:
            if not self.presw:
                self.presw = self.fs(); self.lbl = tk.Label(self.presw, bg="black"); self.lbl.place(relx=.5, rely=.5, anchor="center")
            if keep: self.presw.lift(); self.presw.attributes("-topmost", True); self.presw.focus_force(); self._grab(self.presw)
            with self.fl: d, self.frame = self.frame, None
            if d: self.show(d)
        elif self.presw: self.presw.destroy(); self.presw = None

    # ---------- nộp bài: học sinh chọn file gửi vào thư mục giáo viên mở ----------
    def open_submit(self, title):
        self.close_submit(); self.sub_files = []
        w = self.subw = tk.Toplevel(self.root); w.title("Nộp bài"); w.configure(bg="#f1f5f9"); w.geometry("480x420")
        w.attributes("-topmost", True); w.after(2500, lambda: w.winfo_exists() and w.attributes("-topmost", False))
        def on_close():                                                  # học sinh KHÔNG tự đóng được: chỉ admin (Đóng nhận bài) hoặc mất kết nối admin mới đóng cửa sổ này
            self.notice("Bạn không được đóng cửa sổ Nộp bài")
        w.protocol("WM_DELETE_WINDOW", on_close)
        F = self.F
        tk.Label(w, text="Nộp bài", bg="#f1f5f9", fg="#0369a1", font=(F, 16, "bold")).pack(anchor="w", padx=18, pady=(14, 0))
        tk.Label(w, text=title, bg="#f1f5f9", fg="#1f2937", font=(F, 12), wraplength=440, justify="left").pack(anchor="w", padx=18)
        tk.Label(w, text="Bấm “Chọn file…”, chọn bài làm của em rồi bấm “Nộp bài”.", bg="#f1f5f9", fg="#64748b", font=(F, 10)).pack(anchor="w", padx=18, pady=(2, 6))
        fr = tk.Frame(w, bg="#f1f5f9"); fr.pack(fill="both", expand=True, padx=18)
        lb = self.sub_lb = tk.Listbox(fr, selectmode="extended", font=(F, 10), activestyle="none"); sb = tk.Scrollbar(fr, command=lb.yview); lb.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); lb.pack(side="left", fill="both", expand=True)
        st = self.sub_status = tk.StringVar(value="Chưa chọn file nào")
        tk.Label(w, textvariable=st, bg="#f1f5f9", fg="#0f766e", font=(F, 11, "bold"), wraplength=440, justify="left").pack(anchor="w", padx=18, pady=6)
        bf = tk.Frame(w, bg="#f1f5f9"); bf.pack(fill="x", padx=18, pady=(0, 14))
        def show():
            lb.delete(0, "end")
            for p in self.sub_files:
                try: kb = max(1, os.path.getsize(p) // 1024)
                except OSError: kb = 0
                lb.insert("end", f"{os.path.basename(p)}    ({kb} KB)")
        def choose():
            home = os.path.expanduser("~"); init = os.path.join(home, "Desktop")
            ps = filedialog.askopenfilenames(parent=w, title="Chọn file bài làm", initialdir=init if os.path.isdir(init) else home)
            for p in ps:
                if p not in self.sub_files: self.sub_files.append(p)
            show(); st.set(f"Đã chọn {len(self.sub_files)} file" if self.sub_files else "Chưa chọn file nào")
        def remove():
            for i in reversed(lb.curselection()): del self.sub_files[i]
            show()
        def send():
            if not self.sub_files: return st.set("Hãy chọn ít nhất một file")
            if not self.submit_sender: return st.set("Chưa kết nối giáo viên")
            btn.configure(state="disabled"); st.set("Đang nộp…")
            threading.Thread(target=self.submit_sender, args=(list(self.sub_files),), daemon=True).start()
        btn = tk.Button(bf, text="Nộp bài", width=12, bg="#0369a1", fg="white", font=(F, 11, "bold"), command=send); btn.pack(side="right")
        self.sub_btn = btn
        tk.Button(bf, text="Chọn file…", width=12, command=choose).pack(side="left")
        tk.Button(bf, text="Bỏ file chọn", command=remove).pack(side="left", padx=6)
        w.lift(); w.focus_force()

    def sub_done(self, info):
        """info = (danh sách file đã nộp, danh sách lỗi)"""
        ok, bad = info
        if not (self.subw and self.subw.winfo_exists()): return
        self.sub_files = [p for p in self.sub_files if os.path.basename(p) not in ok]
        self.sub_lb.delete(0, "end")
        for p in self.sub_files: self.sub_lb.insert("end", os.path.basename(p))
        self.sub_btn.configure(state="normal")
        self.sub_status.set(("✔ Đã nộp %d file" % len(ok) if ok else "") + (("\n✘ " + "; ".join(bad[:3])) if bad else ""))

    def close_submit(self):
        if self.subw:
            try: self.subw.destroy()
            except Exception: pass
        self.subw = self.sub_lb = self.sub_status = None

    def show_message(self):
        """Thông báo của giáo viên: hộp lớn giữa màn hình, ở trên cùng cho tới khi học sinh bấm 'Đã hiểu'."""
        if not self.pending_msgs or self.msgw or self.locked or self.presenting: return
        text = self.pending_msgs.pop(0)
        w = self.msgw = tk.Toplevel(self.root); w.overrideredirect(True); w.attributes("-topmost", True); w.configure(bg="#0f172a")
        tk.Frame(w, bg="#f59e0b", height=6).pack(fill="x")
        tk.Label(w, text="Thông báo từ giáo viên", bg="#0f172a", fg="#fbbf24", font=(self.F, 13, "bold")).pack(padx=28, pady=(16, 6))
        tk.Label(w, text=text, bg="#0f172a", fg="#f8fafc", font=(self.F, 18, "bold"), wraplength=560, justify="center").pack(padx=28, pady=6)
        def done():
            self.msgw = None; w.destroy()
        tk.Button(w, text="Đã hiểu", width=12, command=done).pack(pady=(10, 18))
        w.update_idletasks()
        w.geometry(f"+{(self.root.winfo_screenwidth() - w.winfo_width()) // 2}+{(self.root.winfo_screenheight() - w.winfo_height()) // 3}")
        w.lift(); w.focus_force()

    # ---------- cập nhật phần mềm: thông báo có nút, học sinh bấm mới cập nhật ----------
    def show_update(self):
        """Hộp thông báo ở góc phải dưới: 'Cập nhật ngay' / 'Để sau' (hiện lại sau 10 phút nếu chưa cập nhật). Chờ hết khóa / chiếu mới hiện."""
        if not self.upd_offer or self.updw or self.locked or self.presenting or time.time() < self.upd_snooze: return
        o, F = self.upd_offer, self.F
        w = self.updw = tk.Toplevel(self.root); w.overrideredirect(True); w.attributes("-topmost", True); w.configure(bg="#0f172a")
        tk.Frame(w, bg="#16a34a", width=7).pack(side="left", fill="y")
        col = tk.Frame(w, bg="#0f172a"); col.pack(side="left", padx=(16, 18), pady=14)
        tk.Label(col, text="Có bản cập nhật mới", bg="#0f172a", fg="#f8fafc", font=(F, 14, "bold")).pack(anchor="w")
        tk.Label(col, text=f"Giáo viên vừa cập nhật phần mềm (bản {o.get('ver', '?')}).\nBấm “Cập nhật ngay”: máy tự cài và mở lại ứng dụng trong vài giây,\nkhông mất bài làm của em.",
                 bg="#0f172a", fg="#94a3b8", font=(F, 11), justify="left").pack(anchor="w", pady=(4, 6))
        if o.get("notes"):
            tk.Label(col, text="Nội dung cập nhật:\n" + o["notes"], bg="#0f172a", fg="#e2e8f0", font=(F, 11), justify="left", wraplength=420).pack(anchor="w", pady=(0, 6))
        st = self.upd_status = tk.StringVar(value="")
        tk.Label(col, textvariable=st, bg="#0f172a", fg="#5eead4", font=(F, 11, "bold"), wraplength=380, justify="left").pack(anchor="w")
        row = tk.Frame(col, bg="#0f172a"); row.pack(anchor="w", pady=(8, 0))
        def go():
            if not self.update_requester: return st.set("Chưa kết nối giáo viên")
            btn.configure(state="disabled"); later.configure(state="disabled"); st.set("Đang tải bản cập nhật…")
            threading.Thread(target=self.update_requester, daemon=True).start()
        def snooze():
            self.upd_snooze = time.time() + 600; self.close_update()
        btn = self.upd_btn = tk.Button(row, text="Cập nhật ngay", command=go, width=14, bg="#16a34a", fg="white", font=(F, 10, "bold")); btn.pack(side="left")
        later = tk.Button(row, text="Để sau", command=snooze, width=8); later.pack(side="left", padx=8)
        self.upd_later = later
        w.update_idletasks()
        y = self.root.winfo_screenheight() - w.winfo_height() - 70 - (170 if self.linkw and self.linkw.winfo_exists() else 0)
        w.geometry(f"+{self.root.winfo_screenwidth() - w.winfo_width() - 20}+{max(0, y)}")

    def update_status(self, text, failed):
        if self.upd_status: self.upd_status.set(text)
        if failed and self.upd_btn:
            try: self.upd_btn.configure(state="normal", text="Thử lại"); self.upd_later.configure(state="normal")
            except tk.TclError: pass

    def close_update(self, clear=False):
        if self.updw:
            try: self.updw.destroy()
            except Exception: pass
        self.updw = self.upd_status = self.upd_btn = None
        if clear: self.upd_offer = None; self.update_requester = None

    def show_link(self):
        """Link giáo viên gửi: hiện hộp có thể nhấp; chờ đến khi máy hết bị khóa/chiếu mới hiện."""
        if not self.pending_link or self.locked or self.presenting: return
        u, self.pending_link = self.pending_link, None
        if self.linkw: self.linkw.destroy()
        w = self.linkw = tk.Toplevel(self.root); w.overrideredirect(True); w.attributes("-topmost", True); w.configure(bg="#0f172a")
        tk.Frame(w, bg="#0d9488", width=7).pack(side="left", fill="y")
        col = tk.Frame(w, bg="#0f172a"); col.pack(side="left", padx=(16, 18), pady=14)
        tk.Label(col, text="Giáo viên gửi một liên kết", bg="#0f172a", fg="#f8fafc", font=(self.F, 14, "bold")).pack(anchor="w")
        shown = u if len(u) <= 60 else u[:57] + "…"
        lk = tk.Label(col, text=shown, bg="#0f172a", fg="#5eead4", font=(self.F, 12, "underline"), cursor="hand2"); lk.pack(anchor="w", pady=(6, 10))
        def go(ev=None): webbrowser.open(u); w.destroy()
        lk.bind("<Button-1>", go)
        row = tk.Frame(col, bg="#0f172a"); row.pack(anchor="w")
        tk.Button(row, text="Mở", command=go, width=8).pack(side="left")
        tk.Button(row, text="Đóng", command=w.destroy, width=8).pack(side="left", padx=8)
        w.update_idletasks()
        w.geometry(f"+{self.root.winfo_screenwidth() - w.winfo_width() - 20}+{self.root.winfo_screenheight() - w.winfo_height() - 70}")

    def show(self, data):
        img = Image.open(io.BytesIO(data)); sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        if PRESENT_FIT:                      # giữ đúng tỉ lệ, có thể còn viền đen
            k = min(sw / img.width, sh / img.height); size = (max(1, int(img.width * k)), max(1, int(img.height * k)))
        else:                                # mặc định: phủ kín toàn bộ màn hình user, không viền đen
            size = (sw, sh)
        self.photo = ImageTk.PhotoImage(img.resize(size, Image.BILINEAR))
        self.lbl.configure(image=self.photo)

    def notice(self, text):
        w = tk.Toplevel(self.root); w.overrideredirect(True); w.attributes("-topmost", True); w.configure(bg="#0f172a")
        tk.Frame(w, bg="#3b82f6", width=7).pack(side="left", fill="y")
        tk.Label(w, image=tkicon("info", 34, "#60a5fa"), bg="#0f172a").pack(side="left", padx=(14, 4), pady=14)
        head, _, body = text.partition("\n")
        col = tk.Frame(w, bg="#0f172a"); col.pack(side="left", padx=(6, 22), pady=12)
        tk.Label(col, text=head, bg="#0f172a", fg="#f8fafc", font=(self.F, 14, "bold"), anchor="w", justify="left").pack(anchor="w")
        if body: tk.Label(col, text=body, bg="#0f172a", fg="#94a3b8", font=(self.F, 11), anchor="w", justify="left").pack(anchor="w")
        w.update_idletasks()
        w.geometry(f"+{self.root.winfo_screenwidth() - w.winfo_width() - 20}+{self.root.winfo_screenheight() - w.winfo_height() - 70}")
        w.after(5000, w.destroy)


def work_folders(cfg, only=None):
    """Các thư mục học sinh thường lưu bài: BaiLam, Desktop, Documents, Pictures, Downloads (hoặc submit_dirs trong config)."""
    custom = cfg.get("submit_dirs") or []
    if custom and not only:
        out = [(os.path.basename(os.path.normpath(p)) or "thumuc", os.path.abspath(os.path.expanduser(p))) for p in custom]
    else:
        home = os.path.expanduser("~")
        paths = {"BaiLam": os.path.join(home, "BaiLam")}
        names = {"Desktop": "Desktop", "Documents": "Documents", "Pictures": "Pictures", "Downloads": "Downloads"}
        if os.name == "nt":
            try:
                import winreg
                k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders")
                reg = {"Desktop": "Desktop", "Documents": "Personal", "Pictures": "My Pictures",
                       "Downloads": "{374DE290-123F-4565-9164-39C4925E467B}"}
                for lbl, val in reg.items():
                    try: paths[lbl] = os.path.expandvars(winreg.QueryValueEx(k, val)[0])
                    except OSError: paths[lbl] = os.path.join(home, names[lbl])
            except Exception:
                for lbl in names: paths[lbl] = os.path.join(home, names[lbl])
        else:
            for lbl, key in (("Desktop", "DESKTOP"), ("Documents", "DOCUMENTS"), ("Pictures", "PICTURES"), ("Downloads", "DOWNLOAD")):
                p = ""
                try: p = subprocess.run(["xdg-user-dir", key], capture_output=True, text=True, timeout=3).stdout.strip()
                except Exception: pass
                paths[lbl] = p or os.path.join(home, names[lbl])
        out = [(l, p) for l, p in paths.items() if not only or l in only]
    return [(l, p) for l, p in out if os.path.isdir(p)]


_BADCH = re.compile(r'[<>:"|?*\x00-\x1f]')
SKIP_FILES = ("thumbs.db", "desktop.ini", ".ds_store")
SKIP_DIRS = ("appdata", "node_modules", "__pycache__")


def safe_part(s):
    return _BADCH.sub("_", str(s)).strip(" .")


def safe_join(root, rel):
    """Ghép đường dẫn tương đối admin gửi vào thư mục gốc, KHÔNG cho thoát ra ngoài: bỏ '..', '.', rỗng, ổ đĩa, ký tự cấm."""
    parts = [x for x in (safe_part(p) for p in str(rel).replace("\\", "/").split("/")) if x]
    if not parts: return None
    p = os.path.abspath(os.path.join(root, *parts))
    return p if p.startswith(os.path.abspath(root) + os.sep) else None


def walk_files(root, cap=20000, deadline=None):
    """Duyệt mọi file trong 1 thư mục bài làm: (đường dẫn đầy đủ, đường dẫn tương đối, os.stat). Bỏ symlink, file ẩn / file tạm."""
    n = 0
    for dp, dns, fns in os.walk(root):
        dns[:] = [x for x in dns if not x.startswith(".") and x.lower() not in SKIP_DIRS and not os.path.islink(os.path.join(dp, x))]
        for fn in fns:
            if fn.startswith(("~$", ".")) or fn.lower() in SKIP_FILES: continue
            p = os.path.join(dp, fn)
            try:
                if os.path.islink(p): continue
                st = os.stat(p)
            except OSError: continue
            yield p, os.path.relpath(p, root), st
            n += 1
            if n >= cap or (deadline and time.time() > deadline): return


def folder_for(cfg, label, fallback):
    """Thư mục đích khi admin gửi file (mặc định Desktop). Không có thì dùng save_dir."""
    if label in FOLDERS:
        got = work_folders(cfg, [label])
        if got: return got[0][1]
        if label == "BaiLam":
            p = os.path.join(os.path.expanduser("~"), "BaiLam")
            try: os.makedirs(p, exist_ok=True); return p
            except OSError: pass
    return fallback


# ---------------- quản lý 1 máy: ứng dụng đang chạy + điều khiển chuột / bàn phím ----------------
PROTECTED = {"explorer.exe", "applicationframehost.exe", "csrss.exe", "winlogon.exe", "dwm.exe", "lockapp.exe", "searchhost.exe",
             "startmenuexperiencehost.exe", "shellexperiencehost.exe", "textinputhost.exe", "svchost.exe", "services.exe"}
HIDDEN_APPS = {"textinputhost.exe", "searchhost.exe", "startmenuexperiencehost.exe", "shellexperiencehost.exe", "lockapp.exe"}
EXT_KEYS = {0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E}     # phím mở rộng (mũi tên, Home, End, Del…)


def apps_list():
    """Các cửa sổ ứng dụng đang mở (giống danh sách Alt+Tab): [{id, pid, app, title}]."""
    out, me = [], os.getpid()
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        u, k = ctypes.windll.user32, ctypes.windll.kernel32
        k.OpenProcess.restype = wintypes.HANDLE
        EP = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        def cb(h, _):
            try:
                if not u.IsWindowVisible(h) or u.GetWindow(h, 4) or (u.GetWindowLongW(h, -20) & 0x80): return True   # ẩn / có cửa sổ cha / tool window
                n = u.GetWindowTextLengthW(h)
                if not n: return True
                buf = ctypes.create_unicode_buffer(n + 1); u.GetWindowTextW(h, buf, n + 1); title = buf.value
                cloaked = wintypes.DWORD(0); ctypes.windll.dwmapi.DwmGetWindowAttribute(h, 14, ctypes.byref(cloaked), 4)
                if cloaked.value or title == "Program Manager": return True
                pid = wintypes.DWORD(); u.GetWindowThreadProcessId(h, ctypes.byref(pid))
                if pid.value == me: return True
                name, ph = "", k.OpenProcess(0x1000, False, pid.value)
                if ph:
                    sz = wintypes.DWORD(520); b = ctypes.create_unicode_buffer(520)
                    if k.QueryFullProcessImageNameW(ph, 0, b, ctypes.byref(sz)): name = os.path.basename(b.value)
                    k.CloseHandle(ph)
                if name.lower() in HIDDEN_APPS: return True
                out.append({"id": int(h), "pid": int(pid.value), "app": name, "title": title[:120]})
            except Exception:
                pass
            return True
        u.EnumWindows(EP(cb), 0)
    else:
        try:
            for line in subprocess.run(["wmctrl", "-lp"], capture_output=True, text=True, timeout=3).stdout.splitlines():
                p = line.split(None, 4)
                if len(p) >= 5 and p[1] != "-1" and int(p[2]) != me:
                    try: nm = open("/proc/%s/comm" % p[2]).read().strip()
                    except OSError: nm = ""
                    out.append({"id": p[0], "pid": int(p[2]), "app": nm, "title": p[4][:120]})
        except Exception:
            pass
    return out[:80]


_SI = {}
def _win_structs():
    if not _SI:
        import ctypes
        from ctypes import wintypes
        class KI(ctypes.Structure): _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]
        class MI(ctypes.Structure): _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]
        class IU(ctypes.Union): _fields_ = [("ki", KI), ("mi", MI)]
        class INP(ctypes.Structure): _fields_ = [("type", wintypes.DWORD), ("u", IU)]
        _SI["INP"] = INP
    return _SI["INP"]


def _win_key(vk, up, ch=None):
    import ctypes
    INP = _win_structs(); i = INP(); i.type = 1
    if ch is not None: i.u.ki.wScan, i.u.ki.dwFlags = ch, 0x4 | (2 if up else 0)      # KEYEVENTF_UNICODE
    else: i.u.ki.wVk, i.u.ki.dwFlags = vk, (2 if up else 0) | (1 if vk in EXT_KEYS else 0)
    ctypes.windll.user32.SendInput(1, ctypes.byref(i), ctypes.sizeof(i))


def _rc_win(m, t):
    import ctypes
    u = ctypes.windll.user32
    if t in ("move", "down", "up", "wheel"):
        x = int(min(1.0, max(0.0, float(m.get("x", 0)))) * (u.GetSystemMetrics(0) - 1))
        y = int(min(1.0, max(0.0, float(m.get("y", 0)))) * (u.GetSystemMetrics(1) - 1))
        u.SetCursorPos(x, y)
    if t == "down": u.mouse_event({"l": 0x2, "r": 0x8, "m": 0x20}.get(m.get("b"), 0x2), 0, 0, 0, 0)
    elif t == "up": u.mouse_event({"l": 0x4, "r": 0x10, "m": 0x40}.get(m.get("b"), 0x4), 0, 0, 0, 0)
    elif t == "wheel": u.mouse_event(0x800, 0, 0, (int(m.get("d", 0)) * 120) & 0xFFFFFFFF, 0)
    elif t == "text":
        data = str(m.get("s", ""))[:64].encode("utf-16-le")
        for j in range(0, len(data), 2):
            ch = data[j] | (data[j + 1] << 8); _win_key(0, False, ch); _win_key(0, True, ch)
    elif t == "key":
        vk = int(m.get("vk", 0))
        mods = [v for f, v in (("c", 0x11), ("a", 0x12), ("s", 0x10)) if m.get(f)]
        for v in mods: _win_key(v, False)
        _win_key(vk, False); _win_key(vk, True)
        for v in reversed(mods): _win_key(v, True)


_XSIZE = {}
def _rc_x11(m, t):
    def xd(*a): subprocess.run(["xdotool", *map(str, a)], timeout=3, capture_output=True)
    if t in ("move", "down", "up", "wheel"):
        if not _XSIZE:
            try: w, h = subprocess.run(["xdotool", "getdisplaygeometry"], capture_output=True, text=True, timeout=3).stdout.split(); _XSIZE["s"] = (int(w), int(h))
            except Exception: _XSIZE["s"] = (1920, 1080)
        w, h = _XSIZE["s"]
        xd("mousemove", int(min(1.0, max(0.0, float(m.get("x", 0)))) * (w - 1)), int(min(1.0, max(0.0, float(m.get("y", 0)))) * (h - 1)))
    btn = {"l": 1, "m": 2, "r": 3}.get(m.get("b"), 1)
    if t == "down": xd("mousedown", btn)
    elif t == "up": xd("mouseup", btn)
    elif t == "wheel":
        d = int(m.get("d", 0))
        for _ in range(min(abs(d), 10)): xd("click", 4 if d > 0 else 5)
    elif t == "text": xd("type", "--delay", 0, "--", str(m.get("s", ""))[:64])
    elif t == "key":
        vk = int(m.get("vk", 0))
        names = {8: "BackSpace", 9: "Tab", 13: "Return", 27: "Escape", 32: "space", 33: "Prior", 34: "Next", 35: "End", 36: "Home",
                 37: "Left", 38: "Up", 39: "Right", 40: "Down", 45: "Insert", 46: "Delete"}
        nm = names.get(vk) or ("F%d" % (vk - 0x6F) if 0x70 <= vk <= 0x7B else chr(vk).lower())
        xd("key", "+".join([x for f, x in (("c", "ctrl"), ("a", "alt"), ("s", "shift")) if m.get(f)] + [nm]))


def rc_input(m):
    t = m.get("t")
    try: (_rc_win if os.name == "nt" else _rc_x11)(m, t)
    except Exception: pass


def _win_mute(on=None):
    """Windows: đọc / đặt tắt tiếng loa mặc định bằng Core Audio (ctypes, không cần cài thêm thư viện). Trả về True/False = đang tắt tiếng."""
    import ctypes
    from ctypes import POINTER, byref, c_void_p, c_int, c_ulong, c_ushort, c_ubyte, WINFUNCTYPE, HRESULT

    class GUID(ctypes.Structure):
        _fields_ = [("a", c_ulong), ("b", c_ushort), ("c", c_ushort), ("d", c_ubyte * 8)]
    ole = ctypes.windll.ole32

    def guid(txt):
        g = GUID(); ole.CLSIDFromString(ctypes.c_wchar_p(txt), byref(g)); return g

    def vcall(p, idx, argtypes, *args):
        vt = ctypes.cast(ctypes.cast(p, POINTER(c_void_p))[0], POINTER(c_void_p))
        return WINFUNCTYPE(HRESULT, c_void_p, *argtypes)(vt[idx])(p, *args)

    def rel(p):
        try:
            if p and p.value: vcall(p, 2, ())
        except Exception: pass
    hr = ole.CoInitializeEx(None, 0); inited = hr in (0, 1)
    enum, dev, vol = c_void_p(), c_void_p(), c_void_p()
    try:
        if ole.CoCreateInstance(byref(guid("{BCDE0395-E52F-467C-8E3D-C4579291692E}")), None, 23, byref(guid("{A95664D2-9614-4F35-A746-DE8DB63617E6}")), byref(enum)) != 0 or not enum.value:
            raise OSError("không có thiết bị âm thanh")                                       # tránh gọi con trỏ rỗng làm sập app
        vcall(enum, 4, (c_int, c_int, POINTER(c_void_p)), 0, 0, byref(dev))                       # loa mặc định (eRender, eConsole)
        vcall(dev, 3, (POINTER(GUID), c_ulong, c_void_p, POINTER(c_void_p)), byref(guid("{5CDF2C82-841E-4546-9722-0CF74078229A}")), 23, None, byref(vol))
        if on is not None: vcall(vol, 14, (c_int, c_void_p), 1 if on else 0, None)               # SetMute
        m = c_int(0); vcall(vol, 15, (POINTER(c_int),), byref(m))                                 # GetMute
        return bool(m.value)
    finally:
        rel(vol); rel(dev); rel(enum)
        if inited: ole.CoUninitialize()


def _run_out(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=6).stdout or ""


def audio_mute(on=None):
    """on=True/False: tắt / mở tiếng loa máy này; on=None: chỉ đọc trạng thái.
    Trả về True = đang tắt tiếng, False = đang có tiếng, None = máy này không điều khiển được âm thanh."""
    try:
        if os.name == "nt":
            return _win_mute(on)
        if sys.platform == "darwin":
            if on is not None: subprocess.run(["osascript", "-e", f"set volume output muted {'true' if on else 'false'}"], timeout=6)
            return _run_out(["osascript", "-e", "output muted of (get volume settings)"]).strip().lower() == "true"
        try:                                                                # Linux: PulseAudio / PipeWire
            if on is not None: subprocess.run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1" if on else "0"], timeout=6)
            return "yes" in _run_out(["pactl", "get-sink-mute", "@DEFAULT_SINK@"]).lower()
        except FileNotFoundError:                                           # không có pactl: dùng ALSA
            if on is not None: subprocess.run(["amixer", "-q", "set", "Master", "mute" if on else "unmute"], timeout=6)
            return "[off]" in _run_out(["amixer", "get", "Master"]).lower()
    except Exception as e:
        print("audio error:", e)
        return None


def do_shutdown(delay):
    time.sleep(delay)
    try:
        if os.name == "nt":
            subprocess.run(["shutdown", "/s", "/f", "/t", "0"])
        else:
            try: ok = subprocess.run(["systemctl", "poweroff"]).returncode == 0
            except FileNotFoundError: ok = False
            if not ok: subprocess.run(["shutdown", "-h", "now"])
    except Exception as e:
        print("shutdown error:", e)


def do_restart(delay):
    time.sleep(delay)
    try:
        if os.name == "nt":
            subprocess.run(["shutdown", "/r", "/f", "/t", "0"])
        else:
            try: ok = subprocess.run(["systemctl", "reboot"]).returncode == 0
            except FileNotFoundError: ok = False
            if not ok: subprocess.run(["shutdown", "-r", "now"])
    except Exception as e:
        print("restart error:", e)


class Session:
    def __init__(self, cfg, ui, conn):
        self.cfg, self.ui, self.conn = cfg, ui, conn
        self.last_rx = time.time()               # lần cuối nhận được gì từ admin (admin ping mỗi 5 giây)
        self.fh = self.share_stop = self.thumb_stop = None
        self.dir_root, self.dir_n, self.dir_bad, self.dir_dest = None, 0, 0, ""      # đang nhận 1 thư mục từ admin
        self.listing_dirs = {}                  # {tên thư mục hiển thị: đường dẫn đầy đủ} của lần liệt kê thư mục gần nhất
        self.upd = None                          # gói cập nhật đang tải: {"buf","size","sha"}
        self.up_q = queue.Queue(); self.upload_lock = threading.Lock()   # trả lời của admin khi nộp bài
        self.web_set, self.web_note = False, 0            # phiên này đã bật chặn web? / lần cuối báo học sinh
        self.snd_force, self.snd_last = False, "?"      # admin đang giữ tắt tiếng? / trạng thái loa báo admin lần gần nhất
        self.rc, self.procs = False, {}             # đang được admin điều khiển? / danh sách ứng dụng lần gần nhất
        self.listing = {}                       # {đường dẫn tương đối: (đường dẫn đầy đủ, dung lượng)} của lần liệt kê gần nhất
        self.save = os.path.expanduser(cfg["save_dir"]); os.makedirs(self.save, exist_ok=True)

    def run(self):
        threading.Thread(target=self._ping, daemon=True).start()
        threading.Thread(target=self._winwatch, daemon=True).start()
        threading.Thread(target=self._webwatch, daemon=True).start()
        threading.Thread(target=self._soundwatch, daemon=True).start()
        GUARD.hook = self.inst_hit
        try:
            while True:
                t, m = read_msg(self.conn.sock); self.last_rx = time.time()
                if t == T_FRAME:
                    if self.ui.presenting: self.ui.set_frame(m)
                elif t == T_CHUNK:
                    if self.upd:
                        self.upd["buf"].write(m)
                        if self.upd["buf"].tell() > self.upd["size"]: self.upd = None; self.ui.q.put(("update_status", "✘ Gói cập nhật bị lỗi, hãy thử lại", True))
                    elif self.fh: self.fh.write(m)
                elif t == T_JSON:
                    self.cmd(m)
        finally:
            if GUARD.hook == self.inst_hit: GUARD.hook = None       # mất admin: vẫn tiếp tục chặn cài đặt (chính sách đã nhớ trên máy)
            self.rc = False; self.stop_share(); self.stop_thumb()
            if self.web_set: WEB.clear()                    # mất kết nối với admin: gỡ chặn web (giống tự mở khóa)
            if self.fh: self.fh.close()
            self.conn.close()

    # ---------- cập nhật phần mềm ----------
    def request_update(self):
        self.conn.send_json({"cmd": "upd_get"})

    def apply_update(self, u):
        ui = self.ui
        data = u["buf"].getvalue()
        if len(data) != u["size"] or hashlib.sha256(data).hexdigest() != u["sha"]:
            return ui.q.put(("update_status", "✘ Tải bị lỗi, bấm Thử lại", True))
        ui.q.put(("update_status", "Đang cài bản mới…", False))
        try:
            changed = updater.apply(updater.read_zip_bytes(data), role="user", log=print)
        except Exception as e:
            self.conn.send_json({"cmd": "upd_state", "note": "lỗi: " + str(e)[:80]})
            return ui.q.put(("update_status", "✘ " + str(e)[:150], True))
        ui.q.put(("update_status", "✔ Xong – đang mở lại ứng dụng…", False))
        time.sleep(1.2)
        updater.relaunch("client.py"); os._exit(0)

    def _scan(self, m, exts, since, one_max):
        found, seen = [], set()
        for label, root in work_folders(self.cfg, m.get("folders")):
            for dp, dirs, names in os.walk(root):
                dirs[:] = [x for x in dirs if not x.startswith(".") and x.lower() not in ("appdata", "node_modules", "__pycache__")]
                if dp[len(root):].count(os.sep) >= 6: dirs[:] = []
                for n in names:
                    if n.startswith(("~$", ".")) or not n.lower().endswith(exts): continue
                    p = os.path.join(dp, n)
                    try:
                        if os.path.islink(p): continue
                        st = os.stat(p); rp = os.path.realpath(p)
                    except OSError: continue
                    if rp in seen or st.st_size > one_max or (since and st.st_mtime < since): continue
                    seen.add(rp); found.append((st.st_mtime, st.st_size, p, os.path.join(label, os.path.relpath(p, root))))
        return found

    def _scan_dirs(self, m, since):
        """Thư mục con trực tiếp của các thư mục làm việc (vd Desktop\\BaiTap): (mtime mới nhất, tổng byte, số file, đường dẫn, tên hiển thị)."""
        out, deadline = [], time.time() + 15
        for label, root in work_folders(self.cfg, m.get("folders")):
            try: ents = sorted(os.scandir(root), key=lambda e: e.name.lower())
            except OSError: continue
            for e in ents:
                try:
                    if not e.is_dir(follow_symlinks=False) or e.name.startswith((".", "$")) or e.name.lower() in SKIP_DIRS: continue
                except OSError: continue
                cnt, size, newest = 0, 0, 0
                for _, _, st in walk_files(e.path, deadline=deadline):
                    cnt += 1; size += st.st_size; newest = max(newest, st.st_mtime)
                if cnt and not (since and newest < since): out.append((newest, size, cnt, e.path, os.path.join(label, e.name)))
                if time.time() > deadline: return out
        return out

    def upload_files(self, paths):
        """Nộp bài: gửi từng file vào thư mục nhận bài của admin (chạy trong luồng riêng)."""
        ok, bad = [], []
        with self.upload_lock:
            for p in paths:
                name = os.path.basename(p)
                try:
                    size = os.path.getsize(p)
                    while not self.up_q.empty(): self.up_q.get_nowait()
                    self.conn.send_json({"cmd": "up_start", "name": name, "size": size})
                    r = self.up_q.get(timeout=15)
                    if r.get("cmd") != "up_go": bad.append(f"{name}: {r.get('reason', 'bị từ chối')}"); continue
                    with open(p, "rb") as f:
                        while True:
                            b = f.read(CHUNK)
                            if not b: break
                            if not self.conn.send_chunk(b): raise ConnectionError
                    self.conn.send_json({"cmd": "up_end"})
                    r = self.up_q.get(timeout=30)
                    (ok if r.get("cmd") == "up_ok" else bad).append(name if r.get("cmd") == "up_ok" else f"{name}: {r.get('reason', 'lỗi')}")
                except queue.Empty: bad.append(f"{name}: admin không phản hồi")
                except OSError as e: bad.append(f"{name}: không đọc được file")
                except Exception: bad.append(f"{name}: mất kết nối"); break
        self.ui.q.put(("submit_done", (ok, bad)))

    def list_apps(self):
        items = apps_list()
        self.procs = {str(i["id"]): i for i in items}
        self.conn.send_json({"cmd": "proc_list", "items": items})

    def close_app(self, m):
        it = self.procs.get(str(m.get("id")))                  # chỉ thao tác trên ứng dụng có trong danh sách vừa gửi
        if not it: return
        try:
            if m.get("force"):
                if str(it["app"]).lower() in PROTECTED: return
                if os.name == "nt": subprocess.run(["taskkill", "/F", "/T", "/PID", str(it["pid"])], capture_output=True, creationflags=0x08000000)
                else: os.kill(int(it["pid"]), 9)
            elif os.name == "nt":
                import ctypes; ctypes.windll.user32.PostMessageW(int(it["id"]), 0x10, 0, 0)        # WM_CLOSE: đóng nhẹ nhàng, ứng dụng có thể hỏi lưu bài
            else: subprocess.run(["wmctrl", "-ic", str(it["id"])], timeout=3)
            self.ui.q.put(("notice", "Bạn không được phép dùng ứng dụng: " + str(it["app"] or it["title"])))
        except Exception:
            pass
        time.sleep(1.0); self.list_apps()

    def list_files(self, m):
        """Chỉ liệt kê file (chưa gửi nội dung) để admin chọn file cần thu."""
        try:
            kinds = [k for k in m.get("kinds", list(KINDS)) if k in KINDS] or list(KINDS)
            exts = tuple(e for k in kinds for e in KINDS[k][1])
            try: hours = max(0.0, float(m.get("hours", 2)))
            except (TypeError, ValueError): hours = 2.0
            since = time.time() - hours * 3600 if hours else 0
            one_max = int(self.cfg.get("submit_file_max_mb", 100)) * 1024 * 1024
            if m.get("mode") == "dirs":                                   # admin muốn thu cả thư mục: liệt kê thư mục con của các thư mục làm việc
                dirs = sorted(self._scan_dirs(m, since), reverse=True)[:500]
                self.listing_dirs = {arc: p for _, _, _, p, arc in dirs}
                self.conn.send_json({"cmd": "sub_list", "mode": "dirs", "files": [[arc, size, int(mt), cnt] for mt, size, cnt, _, arc in dirs]})
                return
            found = sorted(self._scan(m, exts, since, one_max), reverse=True)[:500]
            self.listing = {arc: (p, size) for _, size, p, arc in found}
            self.conn.send_json({"cmd": "sub_list", "files": [[arc, size, int(mt)] for mt, size, _, arc in found]})
        except Exception:
            self.conn.send_json({"cmd": "sub_list", "files": []})

    def collect(self, m):
        """Thu bài: gom file ảnh / tài liệu / bảng tính / trình chiếu học sinh đã lưu (trong các thư mục làm việc)."""
        ui, conn, cfg = self.ui, self.conn, self.cfg
        kinds = [k for k in m.get("kinds", list(KINDS)) if k in KINDS] or list(KINDS)
        exts = tuple(e for k in kinds for e in KINDS[k][1])
        try: hours = max(0.0, float(m.get("hours", 2)))
        except (TypeError, ValueError): hours = 2.0
        since = time.time() - hours * 3600 if hours else 0
        limit = int(cfg.get("submit_max_mb", 300)) * 1024 * 1024
        one_max = int(cfg.get("submit_file_max_mb", 100)) * 1024 * 1024
        try:
            dirs_mode, big = m.get("mode") == "dirs", 0
            ui.q.put(("notice", "Giáo viên đang thu bài…\n" + ("Thu thư mục bài làm" if dirs_mode else ("File lưu trong %g giờ qua" % hours if hours else "Tất cả file bài làm"))))
            if dirs_mode:                                 # thu nguyên thư mục (mọi loại file, giữ cấu trúc thư mục con); file quá lớn bị bỏ
                found = []
                if not isinstance(m.get("files"), list):  # admin chọn "Thu tất cả": tự quét mọi thư mục phù hợp, không cần tick
                    self.listing_dirs = {arc: p for _, _, _, p, arc in self._scan_dirs(m, since)}
                    m = dict(m, files=list(self.listing_dirs))
                for arc in m["files"]:
                    root = self.listing_dirs.get(arc)
                    if not root or not os.path.isdir(root): continue
                    for p, rel, st in walk_files(root):
                        if st.st_size > one_max: big += 1; continue
                        found.append((st.st_mtime, st.st_size, p, os.path.join(arc, rel)))
            elif isinstance(m.get("files"), list):          # admin đã chọn đúng từng file cần thu
                found = []
                for arc in m["files"]:
                    it = self.listing.get(arc)
                    if it and os.path.isfile(it[0]):
                        try: st = os.stat(it[0]); found.append((st.st_mtime, st.st_size, it[0], arc))
                        except OSError: pass
            else:
                found = self._scan(m, exts, since, one_max)
            if not found:
                conn.send_json({"cmd": "sub_empty"}); ui.q.put(("notice", "Không có file bài làm phù hợp để nộp")); return
            found.sort(reverse=True)                      # mới nhất trước; vượt dung lượng thì bỏ file cũ nhất
            skipped, total, keep = big, 0, []
            for it in found:
                if total + it[1] > limit: skipped += 1; continue
                total += it[1]; keep.append(it)
            with tempfile.TemporaryFile() as tmp:
                with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
                    for _, _, p, arc in keep:
                        try: z.write(p, arc)
                        except OSError: skipped += 1          # file đang bị khóa / không đọc được
                size = tmp.tell(); tmp.seek(0)
                conn.send_json({"cmd": "sub_start", "size": size})
                while True:
                    b = tmp.read(CHUNK)
                    if not b: break
                    if not conn.send_chunk(b): return
                conn.send_json({"cmd": "sub_end", "skipped": skipped, "files": len(keep)})
            ui.q.put(("notice", f"Đã nộp {len(keep)} file bài làm" + (f" (từ {len(m.get('files') or [])} thư mục)" if dirs_mode else "")))
        except Exception as e:
            conn.send_json({"cmd": "sub_err", "reason": str(e)[:100]})

    def _winwatch(self):
        """Báo cho admin chương trình / trang web học sinh đang mở (2 giây/lần, chỉ gửi khi đổi hoặc mỗi 10 giây)."""
        last, ts = None, 0
        while self.conn.alive:
            if self.ui.locked: cur = ("Đang bị khóa", "")
            elif self.ui.presenting: cur = ("Đang xem trình chiếu", "")
            else: cur = active_window()
            if cur != last or time.time() - ts > 10:
                url = ""
                if cur[0].lower() in webblock.BROWSERS or cur[0] in _APPS.values():
                    try: url = webblock.browser_url(cur[0], cur[1])         # link trang đang xem (đọc từ lịch sử trình duyệt) để admin sao chép / chặn
                    except Exception: url = ""
                self.conn.send_json({"cmd": "win", "app": cur[0], "title": cur[1], "url": url}); last, ts = cur, time.time()
            time.sleep(2)

    def set_webblock(self, policy):
        p = webblock.clean_policy(policy)
        if p["on"]:
            info = WEB.apply(p); self.web_set = True
            self.conn.send_json({"cmd": "web_state", "on": WEB.active, "browser": bool(info.get("browser")), "hosts": bool(info.get("hosts"))})
        else:
            WEB.clear(); self.web_set = False
            self.conn.send_json({"cmd": "web_state", "on": False})

    def set_installblock(self, policy):
        """Admin gửi chính sách chặn cài đặt: nhớ lại trên máy, báo học sinh khi có thay đổi, báo admin trạng thái thực tế."""
        changed = GUARD.apply(policy)
        self.conn.send_json({"cmd": "inst_state", "on": GUARD.active, "allowed": len(GUARD.policy["allow"]), "disabled": not GUARD.enabled})

    def inst_hit(self, name, ok):
        """Có học sinh vừa chạy file cài đặt: báo admin để ghi nhật ký."""
        self.conn.send_json({"cmd": "inst_hit", "name": str(name)[:80], "closed": bool(ok)})

    def _webwatch(self):
        """Trình duyệt đang hiện trang bị chặn (theo tiêu đề cửa sổ) thì đóng tab đó."""
        while self.conn.alive:
            time.sleep(1.0)
            if not WEB.active or self.ui.locked: continue
            app, title = active_window(); hit = WEB.check(app, title)
            if hit:
                webblock.close_tab()
                if time.time() - self.web_note > 5:
                    self.web_note = time.time(); self.ui.q.put(("notice", "Bạn không được phép truy cập trang web này")); time.sleep(1.0)

    def report_audio(self, st):
        self.snd_last = st; self.conn.send_json({"cmd": "audio_state", "muted": st})

    def set_mute(self, on):
        """Admin tắt / mở tiếng loa máy này. Tắt tiếng thì được GIỮ (học sinh bật lại sẽ bị tắt lại) cho tới khi admin bấm Mở tiếng."""
        self.snd_force = on
        st = audio_mute(on); self.report_audio(st)
        if st is None: self.ui.q.put(("notice", "Máy này không điều khiển được âm thanh"))
        else: self.ui.q.put(("notice", "Giáo viên đã tắt âm thanh máy" if on else "Giáo viên đã mở lại âm thanh máy"))

    def _soundwatch(self):
        """Mỗi 3 giây: giữ tắt tiếng nếu admin đang yêu cầu; báo admin khi trạng thái loa đổi."""
        while self.conn.alive:
            time.sleep(3)
            st = audio_mute(None)
            if self.snd_force and st is False: st = audio_mute(True)
            if st != self.snd_last: self.report_audio(st)

    def _ping(self):
        while self.conn.alive:
            self.conn.send_json({"cmd": "ping"}); time.sleep(5)

    def stop_thumb(self):
        if self.thumb_stop: self.thumb_stop.set(); self.thumb_stop = None

    def stop_share(self):
        if self.share_stop: self.share_stop.set(); self.share_stop = None

    def cmd(self, m):
        c, ui = m.get("cmd"), self.ui
        if c == "lock": ui.q.put(("lock", True))
        elif c == "unlock": ui.q.put(("lock", False))
        elif c == "present_start": ui.q.put(("present", True))
        elif c == "present_stop": ui.q.put(("present", False))
        elif c == "shutdown":
            threading.Thread(target=do_shutdown, args=(0,), daemon=True).start()        # tắt ngay, không chờ
        elif c == "submit_open":
            ui.submit_sender = self.upload_files; ui.q.put(("submit_open", str(m.get("title", "Nộp bài"))[:120])); ui.q.put(("notice", "Giáo viên mở nộp bài\nBấm cửa sổ “Nộp bài” để gửi file"))
        elif c == "submit_close":
            ui.submit_sender = None; ui.q.put(("submit_close",)); ui.q.put(("notice", "Giáo viên đã đóng nhận bài"))
        elif c in ("up_go", "up_ok", "up_no"): self.up_q.put(m)
        elif c == "update_offer":
            ui.update_requester = self.request_update
            ui.q.put(("update_offer", {"ver": str(m.get("ver", ""))[:20], "build": str(m.get("build", ""))[:16], "notes": str(m.get("notes", ""))[:800]}))
        elif c == "upd_start":
            try: size = int(m.get("size", 0))
            except (TypeError, ValueError): size = 0
            if 0 < size <= (30 << 20): self.upd = {"buf": io.BytesIO(), "size": size, "sha": str(m.get("sha", ""))}
            else: ui.q.put(("update_status", "✘ Gói cập nhật không hợp lệ", True))
        elif c == "upd_end" and self.upd:
            u, self.upd = self.upd, None
            threading.Thread(target=self.apply_update, args=(u,), daemon=True).start()
        elif c == "upd_no":
            self.upd = None; ui.q.put(("update_status", "✘ " + str(m.get("reason", "Không cập nhật được"))[:100], True))
        elif c == "proc_list": threading.Thread(target=self.list_apps, daemon=True).start()
        elif c == "proc_close": threading.Thread(target=self.close_app, args=(m,), daemon=True).start()
        elif c == "rc_start": self.rc = True
        elif c == "rc_stop": self.rc = False
        elif c == "rc":
            if self.rc: rc_input(m)
        elif c == "collect_list":
            threading.Thread(target=self.list_files, args=(m,), daemon=True).start()
        elif c == "collect":
            threading.Thread(target=self.collect, args=(m,), daemon=True).start()
        elif c == "mute": threading.Thread(target=self.set_mute, args=(bool(m.get("on")),), daemon=True).start()
        elif c == "restart":
            threading.Thread(target=do_restart, args=(0,), daemon=True).start()         # khởi động lại ngay, không chờ
        elif c == "open_url":
            u = str(m.get("url", "")); p = urlparse(u)
            if p.scheme in ("http", "https") and p.netloc:      # chỉ mở web, không mở file/lệnh
                webbrowser.open(u)
        elif c == "message":
            t = str(m.get("text", ""))[:300].strip()
            if t: ui.q.put(("message", t))
        elif c == "webblock": threading.Thread(target=self.set_webblock, args=(m.get("policy"),), daemon=True).start()
        elif c == "installblock": self.set_installblock(m.get("policy"))
        elif c == "show_link":
            u = str(m.get("url", "")); p = urlparse(u)
            if p.scheme in ("http", "https") and p.netloc: ui.q.put(("link", u))
        elif c == "share_start":
            self.stop_share(); self.share_stop = ev = threading.Event()
            send = lambda d: self.conn.send_frame(T_UP, d)
            threading.Thread(target=stream_loop, args=(send, ev, float(m.get("fps", 3)), int(m.get("width", 1024)), int(m.get("quality", 50))), daemon=True).start()
        elif c == "share_stop": self.stop_share()
        elif c == "thumb_start":
            self.stop_thumb(); self.thumb_stop = ev = threading.Event()
            send = lambda d: self.conn.send_frame(T_THUMB, d)
            threading.Thread(target=stream_loop, args=(send, ev, float(m.get("fps", .5)), int(m.get("width", 320)), int(m.get("quality", 40))), daemon=True).start()
        elif c == "thumb_stop": self.stop_thumb()
        elif c == "dir_start":                       # admin gửi cả thư mục: tạo thư mục gốc mới (không ghi đè thư mục trùng tên) + các thư mục con rỗng
            if self.fh: self.fh.close(); self.fh = None
            dest = folder_for(self.cfg, m.get("dest"), self.save)
            name = safe_part(os.path.basename(str(m.get("name", "")).replace("\\", "/"))) or "thumuc"
            root, i = os.path.join(dest, name), 1
            while os.path.exists(root): root = os.path.join(dest, f"{name}({i})"); i += 1
            self.dir_root, self.dir_n, self.dir_bad, self.dir_dest = None, 0, 0, dest
            try:
                os.makedirs(root)
                for d in (m.get("dirs") or [])[:5000]:
                    p = safe_join(root, d)
                    if p: os.makedirs(p, exist_ok=True)
                self.dir_root = root
                ui.q.put(("notice", f"Đang nhận thư mục: {os.path.basename(root)}\nLưu tại: {dest}"))
            except OSError:
                ui.q.put(("notice", "Không tạo được thư mục nhận từ giáo viên"))
        elif c == "dir_end":
            if self.fh: self.fh.close(); self.fh = None
            if self.dir_root:
                ui.q.put(("notice", f"Đã nhận thư mục: {os.path.basename(self.dir_root)} ({self.dir_n} file" + (f", {self.dir_bad} file lỗi" if self.dir_bad else "") + f")\nLưu tại: {self.dir_dest}"))
            self.dir_root = None
        elif c == "file_start":
            if self.fh: self.fh.close(); self.fh = None
            if m.get("rel") and self.dir_root:       # file nằm trong thư mục đang nhận: giữ đúng đường dẫn con, chặn '..' / đường dẫn tuyệt đối
                self.path = safe_join(self.dir_root, m.get("rel"))
                try:
                    os.makedirs(os.path.dirname(self.path), exist_ok=True); self.fh = open(self.path, "wb")
                except (OSError, TypeError): self.fh = None; self.dir_bad += 1
            else:
                name = os.path.basename(str(m.get("name", "")).replace("\\", "/")) or "file"
                self.dest = folder_for(self.cfg, m.get("dest"), self.save)
                base, ext = os.path.splitext(name); self.path, i = os.path.join(self.dest, name), 1
                while os.path.exists(self.path): self.path = os.path.join(self.dest, f"{base}({i}){ext}"); i += 1
                self.fh = open(self.path, "wb")
        elif c == "file_end" and self.fh:
            self.fh.close(); self.fh = None
            if self.dir_root: self.dir_n += 1                  # trong thư mục: chỉ báo 1 lần ở dir_end
            else: ui.q.put(("notice", f"Đã nhận file: {os.path.basename(self.path)}\nLưu tại: {self.dest}"))


def discover(port, timeout=5):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("", port)); s.settimeout(timeout)
        data, addr = s.recvfrom(512); j = json.loads(data)
        if j.get("magic") == "LABMGR": return addr[0], int(j["port"])
    except Exception: pass
    finally: s.close()
    return None


def login_name():
    """Tên tài khoản đang đăng nhập trên máy user (hiện trên ô máy ở admin)."""
    try:
        import getpass; return getpass.getuser()[:40]
    except Exception:
        return os.environ.get("USERNAME") or os.environ.get("USER") or ""


SESSION = threading.Lock()     # mỗi máy user chỉ phục vụ 1 admin tại một thời điểm
CURRENT = None                 # phiên đang chạy (để nhường cho admin mới nếu phiên cũ đã 'chết')


def run_session(cfg, ui, sock):
    """Bắt tay (xác thực mã lớp) rồi chạy phiên làm việc với admin. Dùng cho cả 2 hướng kết nối."""
    sock.settimeout(10)
    client_handshake(sock, cfg["secret"], socket.gethostname(), platform.system(), login_name(), {"ver": updater.RUN_VER, "build": updater.RUN_BUILD})
    global CURRENT
    if not SESSION.acquire(blocking=False):      # đang có admin khác
        # Phiên cũ im lặng quá 15 giây (admin ping mỗi 5 giây) = admin cũ đã tắt đột ngột / mất mạng: nhường cho admin mới
        cur = CURRENT
        if not (cur and time.time() - cur.last_rx > 15 and (cur.conn.close() or True) and SESSION.acquire(timeout=5)):
            sock.close(); return
    try:
        sock.settimeout(30)
        print("Đã kết nối admin", sock.getpeername()[0]); CURRENT = sess = Session(cfg, ui, Conn(sock)); sess.run()
    finally:
        CURRENT = None
        SESSION.release()
        ui.q.put(("reset",))        # mất admin -> tự mở khóa / tắt trình chiếu


def listen_loop(cfg, ui):
    """Chờ admin kết nối vào (admin tự quét mạng LAN và nối ra)."""
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try: s.bind(("", int(cfg.get("agent_port", 5003)))); s.listen(5)
    except OSError as e:
        print("không mở được cổng nhận kết nối:", e); return
    def one(sock):
        try: run_session(cfg, ui, sock)
        except Exception as e: print("admin vào:", e)
        finally:
            try: sock.close()
            except OSError: pass
    while True:
        try: sock, _ = s.accept()
        except OSError: return
        threading.Thread(target=one, args=(sock,), daemon=True).start()


def discover(port, timeout=5):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("", port)); s.settimeout(timeout)
        data, addr = s.recvfrom(512); j = json.loads(data)
        if j.get("magic") == "LABMGR": return addr[0], int(j["port"])
    except Exception: pass
    finally: s.close()
    return None


def agent_loop(cfg, ui, server_arg):
    """Hướng dự phòng: máy user tự kết nối tới admin (tự tìm bằng broadcast hoặc theo IP trong config)."""
    while True:
        try:
            if SESSION.locked():
                time.sleep(3); continue
            srv = server_arg or cfg["server"]
            if srv == "auto":
                found = discover(cfg["discovery_port"]); host, port = found if found else (None, cfg["port"])
            else:
                host, port = srv, cfg["port"]
            if host:
                sock = socket.create_connection((host, port), timeout=8)
                run_session(cfg, ui, sock)
        except Exception as e:
            print("kết nối:", e)
        time.sleep(3)


def start_tray(cfg):
    """Biểu tượng ở khay hệ thống (góc đồng hồ): luôn hiện để biết ứng dụng đang chạy.
    Di chuột vào xem mã lớp / phiên bản / trạng thái kết nối; bấm chuột phải cũng thấy. Không có nút thoát (học sinh không tắt được)."""
    try:
        import pystray
        img = Image.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon-user.png")).convert("RGBA").resize((64, 64), Image.LANCZOS)
    except Exception as e:
        print("khay hệ thống:", e); return
    status = lambda: "Đã kết nối giáo viên" if CURRENT else "Chưa kết nối giáo viên"
    title = lambda: f"Quản lý phòng máy • Mã lớp: {cfg['secret']} • Bản {updater.RUN_VER} • {status()}"[:120]
    items = [pystray.MenuItem(lambda i: "Quản lý phòng máy – máy học sinh", lambda: None, enabled=False),
             pystray.MenuItem(lambda i: "Mã lớp: " + str(cfg["secret"]), lambda: None, enabled=False),
             pystray.MenuItem(lambda i: "Phiên bản: " + updater.RUN_VER, lambda: None, enabled=False),
             pystray.MenuItem(lambda i: status(), lambda: None, enabled=False)]
    try:
        icon = pystray.Icon("LabManagerUser", img, title(), pystray.Menu(*items)); icon.run_detached()
    except Exception as e:
        print("khay hệ thống:", e); return
    def upd():
        last = None
        while True:
            time.sleep(3)
            cur = title()
            if cur != last:
                try: icon.title = cur; icon.update_menu()
                except Exception: pass
                last = cur
    threading.Thread(target=upd, daemon=True).start()


if __name__ == "__main__":
    import json
    _lock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)      # chỉ cho chạy 1 bản trên mỗi máy
    try: _lock.bind(("127.0.0.1", 5002))
    except OSError: sys.exit(0)
    policy(False); WEB.clear(); dpi_aware(); cfg = load_config(); PRESENT_FIT = bool(cfg.get("present_fit", False))
    server = sys.argv[sys.argv.index("--server") + 1] if "--server" in sys.argv else None
    ui = UI(); start_tray(cfg)
    GUARD.enabled = bool(cfg.get("install_block", True)); GUARD.load(); GUARD.notify = lambda t: ui.q.put(("notice", t)); GUARD.start()   # chặn ngay từ lúc bật máy
    threading.Thread(target=listen_loop, args=(cfg, ui), daemon=True).start()
    threading.Thread(target=agent_loop, args=(cfg, ui, server), daemon=True).start()
    ui.root.mainloop()
